// Utilitários de DOM. Nunca usa innerHTML: todo texto vindo de usuários entra como nó de texto.
export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, String(v));
    }
  }
  append(el, kids);
  return el;
}
export function append(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return el;
}
export const svgUse = (id, cls) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('class', cls); s.setAttribute('viewBox', '0 0 45 45'); s.setAttribute('aria-hidden', 'true');
  const u = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  u.setAttribute('href', '#' + id);
  s.append(u);
  return s;
};

export const idLabel = (n) => '#' + String(n).padStart(3, '0');
export const fmtPts = (n) => (Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100).replace('.', ','));
export const fmtDate = (iso) => { try { return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }); } catch (_) { return iso || ''; } };
export function fmtClock(ms) {
  ms = Math.max(0, ms);
  if (ms < 10000) return (ms / 1000).toFixed(1);
  const s = Math.floor(ms / 1000), hh = Math.floor(s / 3600), mm = Math.floor((s % 3600) / 60), ss = s % 60;
  const p = (n) => String(n).padStart(2, '0');
  return hh ? `${hh}:${p(mm)}:${p(ss)}` : `${p(mm)}:${p(ss)}`;
}

export const LABELS = {
  modality: { presencial: 'Presencial', online: 'Online', hibrido: 'Híbrido' },
  system: { suico: 'Sistema Suíço', round_robin: 'Round Robin', eliminatoria_simples: 'Eliminatória simples', eliminatoria_dupla: 'Eliminatória dupla' },
  status: { setup: 'Aguardando início', running: 'Em andamento', finished: 'Finalizado' },
  registration: { open: 'Inscrições abertas', paused: 'Inscrições pausadas', closed: 'Inscrições encerradas' },
  gameState: { waiting: 'Aguardando', playing: 'Em andamento', finished: 'Finalizada', postponed: 'Adiada', cancelled: 'Cancelada' },
  reason: { checkmate: 'xeque-mate', stalemate: 'afogamento', repetition: 'repetição tripla', 'fifty-move': 'regra dos 50 lances', insufficient: 'material insuficiente', resign: 'abandono', timeout: 'tempo esgotado', agreement: 'acordo de empate', abandon: 'abandono', bye: 'bye (folga)', registrado: 'resultado registrado', 'correção': 'correção do organizador' },
  tiebreak: { buchholz: 'Buchholz', buchholz_cut1: 'Buchholz Cut-1', sonneborn_berger: 'Sonneborn-Berger', wins: 'Vitórias', progressive: 'Progressivo', rating: 'Rating Elo' },
};
export const resultText = (r) => (r === '1/2-1/2' ? '½-½' : r === 'bye' ? 'bye' : r || '—');

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* tenta o método antigo */ }
  try {
    const ta = h('textarea', { style: 'position:fixed;opacity:0' }); ta.value = text; document.body.append(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove(); return ok;
  } catch (_) { return false; }
}

export function toast(msg, kind = 'info', ms = 4500) {
  const root = document.getElementById('toasts');
  const t = h('div', { class: 'toast ' + kind }, msg);
  root.append(t);
  while (root.children.length > 3) root.firstChild.remove();
  setTimeout(() => t.remove(), ms);
}

/** Diálogo modal nativo. `build(body, close)` monta o conteúdo; retorna Promise resolvida ao fechar. */
export function openDialog({ title, build, actions = [], onClose }) {
  const dlg = h('dialog', { 'aria-labelledby': 'dlg-title' });
  const body = h('div', { class: 'dlg-b' });
  const close = (v) => { dlg.close(); dlg.remove(); if (onClose) onClose(v); };
  const closeBtn = h('button', { class: 'btn iconbtn ghost', type: 'button', 'aria-label': 'Fechar', onclick: () => close(null) }, '✕');
  dlg.append(h('div', { class: 'dlg-h' }, h('h2', { id: 'dlg-title' }, title), closeBtn), body);
  build(body, close);
  if (actions.length) dlg.append(h('div', { class: 'dlg-f' }, actions.map((a) => h('button', { class: 'btn ' + (a.class || ''), type: 'button', onclick: () => a.onClick(close) }, a.label))));
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); close(null); });
  dlg.addEventListener('click', (e) => { if (e.target === dlg) close(null); });
  document.body.append(dlg);
  dlg.showModal();
  return dlg;
}

/**
 * Formulário em diálogo. fields: [{name,label,type,value,options,hint,min,max,step,required,placeholder,rows}]
 * submit(values) pode lançar erro: a mensagem aparece no diálogo.
 */
export function openForm({ title, fields, submitLabel = 'Salvar', danger = false, intro = null, submit }) {
  return new Promise((resolve) => {
    const inputs = {};
    const errBox = h('div', { class: 'err hidden', role: 'alert' });
    const form = h('form', { novalidate: true });
    if (intro) form.append(h('p', { class: 'muted', style: 'margin-top:0' }, intro));
    form.append(errBox);
    for (const f of fields) {
      const id = 'f-' + f.name;
      let input;
      if (f.type === 'select') {
        input = h('select', { id, name: f.name }, f.options.map((o) => h('option', { value: o.value, selected: String(o.value) === String(f.value) }, o.label)));
      } else if (f.type === 'textarea') {
        input = h('textarea', { id, name: f.name, placeholder: f.placeholder, rows: f.rows || 6 }); input.value = f.value ?? '';
      } else if (f.type === 'checkbox') {
        input = h('input', { id, name: f.name, type: 'checkbox', checked: !!f.value });
      } else if (f.type === 'range') {
        input = h('input', { id, name: f.name, type: 'range', min: f.min, max: f.max, step: f.step || 1, value: f.value });
      } else {
        input = h('input', { id, name: f.name, type: f.type || 'text', value: f.value ?? '', placeholder: f.placeholder, min: f.min, max: f.max, step: f.step, maxlength: f.maxlength, autocomplete: 'off', inputmode: f.type === 'number' ? 'decimal' : null });
      }
      inputs[f.name] = input;
      if (f.type === 'checkbox') form.append(h('div', { class: 'field' }, h('label', { class: 'check', for: id }, input, f.label), f.hint && h('div', { class: 'hint' }, f.hint)));
      else if (f.type === 'range') {
        const out = h('b', null, String(f.value));
        input.addEventListener('input', () => { out.textContent = input.value; });
        form.append(h('div', { class: 'field' }, h('label', { for: id }, f.label, ': ', out), input, f.hint && h('div', { class: 'hint' }, f.hint)));
      } else form.append(h('div', { class: 'field' }, h('label', { for: id }, f.label), input, f.hint && h('div', { class: 'hint' }, f.hint)));
    }
    const submitBtn = h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), type: 'submit' }, submitLabel);
    const cancel = h('button', { class: 'btn', type: 'button' }, 'Cancelar');
    form.append(h('div', { class: 'dlg-f', style: 'padding:0;margin-top:6px' }, cancel, submitBtn));
    let dlg;
    const done = (v) => { dlg.close(); dlg.remove(); resolve(v); };
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const values = {};
      for (const f of fields) {
        const el = inputs[f.name];
        values[f.name] = f.type === 'checkbox' ? el.checked : f.type === 'number' || f.type === 'range' ? (el.value === '' ? null : Number(String(el.value).replace(',', '.'))) : el.value;
      }
      errBox.classList.add('hidden');
      submitBtn.disabled = true;
      try { await submit(values); done(true); }
      catch (err) { errBox.textContent = err.message || String(err); errBox.classList.remove('hidden'); submitBtn.disabled = false; }
    });
    cancel.addEventListener('click', () => done(false));
    dlg = h('dialog', { 'aria-labelledby': 'dlg-title' }, h('div', { class: 'dlg-h' }, h('h2', { id: 'dlg-title' }, title)), h('div', { class: 'dlg-b' }, form));
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); done(false); });
    document.body.append(dlg);
    dlg.showModal();
    const first = form.querySelector('input,select,textarea'); if (first) first.focus();
  });
}

export function confirmDialog({ title, message, confirmLabel = 'Confirmar', danger = false }) {
  return new Promise((resolve) => {
    openDialog({
      title, build: (b) => b.append(h('p', { style: 'margin:0' }, message)),
      actions: [{ label: 'Cancelar', onClick: (c) => { resolve(false); c(); } }, { label: confirmLabel, class: danger ? 'danger' : 'primary', onClick: (c) => { resolve(true); c(); } }],
      onClose: () => resolve(false),
    });
  });
}
