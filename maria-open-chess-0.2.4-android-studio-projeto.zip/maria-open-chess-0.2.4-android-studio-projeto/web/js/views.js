// Componentes de visualização compartilhados entre participantes e organizador.
import { h, idLabel, fmtPts, LABELS, resultText } from './dom.js';
import { S } from './net.js';

export const pname = (p, { id = true } = {}) => h('span', null, p ? p.name : '—', id && p ? h('span', { class: 'pid' }, idLabel(p.number)) : null);

export function emptyState(title, text) { return h('div', { class: 'empty-state' }, h('b', null, title), text); }

export function playersTable() {
  const meId = S.me && S.me.player.id;
  if (!S.players.length) return emptyState('Nenhum participante ainda', 'Quando alguém entrar, aparecerá aqui em tempo real.');
  const hasElo = S.players.some((p) => p.elo);
  return h('div', { class: 'tablewrap' }, h('table', null,
    h('thead', null, h('tr', null, h('th', { class: 'num' }, 'ID'), h('th', null, 'Nome'), hasElo && h('th', { class: 'num' }, 'Elo'), h('th', null, 'Situação'))),
    h('tbody', null, S.players.map((p) => h('tr', { class: p.id === meId ? 'me' : p.status === 'withdrawn' ? 'out' : '' },
      h('td', { class: 'num mono' }, String(p.number).padStart(3, '0')),
      h('td', null, p.name, p.id === meId ? h('span', { class: 'chip accent', style: 'margin-left:8px' }, 'você') : null),
      hasElo && h('td', { class: 'num' }, p.elo || '—'),
      h('td', null, p.status === 'withdrawn' ? h('span', { class: 'chip danger' }, 'desistiu') : p.connected ? h('span', { class: 'chip ok' }, 'conectado') : h('span', { class: 'chip' }, 'inscrito')))))));
}

export function standingsTable() {
  const t = S.t, rows = S.standings;
  if (!rows.length) return emptyState('Classificação indisponível', 'Ela aparece assim que houver participantes inscritos.');
  const elim = t.system === 'eliminatoria_simples' || t.system === 'eliminatoria_dupla';
  const meId = S.me && S.me.player.id;
  const hasElo = rows.some((r) => r.player.elo);
  const finished = t.status === 'finished';
  const medal = (pos) => (finished && pos <= 3 ? ` medal-${pos}` : '');
  return h('div', { class: 'tablewrap' }, h('table', null,
    h('thead', null, h('tr', null,
      h('th', { class: 'num' }, 'Pos.'), h('th', null, 'Jogador'), h('th', { class: 'num' }, 'ID'), h('th', { class: 'num' }, 'Pontos'),
      h('th', { class: 'num', title: 'Vitórias' }, 'V'), h('th', { class: 'num', title: 'Empates' }, 'E'), h('th', { class: 'num', title: 'Derrotas' }, 'D'),
      !elim && h('th', { class: 'num' }, 'Buchholz'), !elim && h('th', { class: 'num' }, 'S-B'), hasElo && h('th', { class: 'num' }, 'Elo'),
      elim && h('th', null, 'Situação'))),
    h('tbody', null, rows.map((r) => h('tr', { class: (r.id === meId ? 'me ' : '') + (elim && !r.alive ? 'out' : '') },
      h('td', { class: 'num pos' + medal(r.position) }, r.position + 'º'),
      h('td', null, r.player.name, r.player.status === 'withdrawn' ? h('span', { class: 'chip danger', style: 'margin-left:8px' }, 'desistiu') : null, r.id === meId ? h('span', { class: 'chip accent', style: 'margin-left:8px' }, 'você') : null),
      h('td', { class: 'num mono' }, String(r.player.number).padStart(3, '0')),
      h('td', { class: 'num' }, h('b', null, fmtPts(r.points))),
      h('td', { class: 'num' }, r.wins), h('td', { class: 'num' }, r.draws), h('td', { class: 'num' }, r.losses),
      !elim && h('td', { class: 'num' }, fmtPts(r.buchholz)), !elim && h('td', { class: 'num' }, fmtPts(r.sonneborn_berger)),
      hasElo && h('td', { class: 'num' }, r.player.elo || '—'),
      elim && h('td', null, r.champion ? h('span', { class: 'chip ok' }, 'Campeão') : r.runnerUp ? h('span', { class: 'chip accent' }, 'Vice') : r.alive ? h('span', { class: 'chip accent' }, 'Na disputa') : h('span', { class: 'chip' }, 'Eliminado' + (r.eliminatedRound ? ` (rodada ${r.eliminatedRound})` : ''))))))),
  );
}

export function statsView() {
  const s = S.stats;
  if (!s || !Object.keys(s).length) return emptyState('Sem estatísticas ainda', 'Elas aparecem conforme as partidas forem concluídas. Nada é inventado: só o que existe nos dados.');
  const names = (arr) => arr.map((x) => h('span', { style: 'margin-right:10px' }, x.name, h('span', { class: 'pid' }, idLabel(x.number))));
  const cards = [];
  const add = (icon, title, body) => cards.push(h('div', { class: 'award' }, h('div', { class: 'ic', 'aria-hidden': 'true' }, icon), h('div', null, h('b', null, title), h('small', null, body))));
  if (s.champion) add('🏆', 'Campeão', [names([s.champion]), ` — ${fmtPts(s.champion.points)} pts`]);
  if (s.runnerUp) add('🥈', 'Vice-campeão', [names([s.runnerUp]), ` — ${fmtPts(s.runnerUp.points)} pts`]);
  if (s.third) add('🥉', 'Terceiro colocado', [names([s.third]), ` — ${fmtPts(s.third.points)} pts`]);
  if (s.mostWins) add('⚔️', 'Mais vitórias', [names(s.mostWins), ` — ${s.mostWins[0].wins} vitória(s)`]);
  if (s.bestPerformance) add('📈', 'Melhor desempenho', [names(s.bestPerformance.players), ` — ${String(s.bestPerformance.value).replace('.', ',')}% de aproveitamento`, h('br'), h('span', { class: 'note' }, 'Critério: ' + s.bestPerformance.criterion)]);
  if (s.longestWinStreak) add('🔥', 'Maior sequência de vitórias', [names(s.longestWinStreak.players), ` — ${s.longestWinStreak.wins} seguidas`]);
  if (s.highestRating) add('⭐', 'Maior rating', [names(s.highestRating.players), ` — Elo ${s.highestRating.elo}`]);
  if (s.longestGame) add('⏱️', 'Partida mais longa', [`${s.longestGame.moves} lances — rodada ${s.longestGame.round}: `, s.longestGame.white && s.longestGame.white.name, ' × ', s.longestGame.black && s.longestGame.black.name, ' ', h('a', { href: `#/jogo/${s.longestGame.game_id}` }, 'ver partida')]);
  return h('div', { class: 'grid cols-2' }, cards);
}

const colorDot = (c) => h('span', { class: 'cdot ' + c, title: c === 'w' ? 'Brancas' : 'Pretas' });

/** Lista de confrontos de uma rodada. `actions(game)` devolve nós de ação adicionais. */
export function gameRows(games, { actions = null, meId = null } = {}) {
  if (!games.length) return emptyState('Sem confrontos', 'Esta rodada ainda não tem partidas.');
  return h('div', null, games.map((g) => {
    const mine = meId && (g.white_id === meId || g.black_id === meId);
    const bye = g.black_id == null;
    const stateChip = g.state === 'playing' ? h('span', { class: 'chip accent live' }, 'ao vivo')
      : g.state === 'finished' ? null
        : h('span', { class: 'chip ' + (g.state === 'cancelled' ? 'danger' : g.state === 'postponed' ? 'warn' : '') }, LABELS.gameState[g.state]);
    const res = bye ? h('span', { class: 'chip ok' }, 'bye') : g.state === 'finished' ? h('span', { class: 'res' }, resultText(g.result)) : stateChip;
    const view = !bye && h('a', { class: 'btn small', href: `#/jogo/${g.id}` }, mine && g.kind === 'online' && ['waiting', 'playing'].includes(g.state) ? 'Jogar' : 'Ver');
    return h('div', { class: 'game' + (mine ? ' mine' : ''), style: mine ? 'background:var(--accent-soft)' : null },
      h('div', { class: 'tb' }, `Tab. ${g.board}`, g.table_no ? [h('br'), `Mesa ${g.table_no}`] : null, h('br'), h('span', { style: 'font-size:.7rem' }, g.kind === 'online' ? 'online' : 'presencial')),
      h('div', { class: 'who w' }, colorDot('w'), pname(g.white)),
      h('div', { class: 'res' }, res),
      h('div', { class: 'who r b' }, bye ? h('span', { class: 'muted' }, 'folga (bye)') : [colorDot('b'), pname(g.black)]),
      h('div', { class: 'acts' }, view, actions ? actions(g) : null));
  }));
}

export function roundsView({ selected, onSelect, actions, meId }) {
  if (!S.rounds.length) return emptyState('Nenhuma rodada ainda', S.t.status === 'setup' ? 'As rodadas aparecem quando o organizador iniciar o torneio.' : 'Aguarde o organizador gerar a rodada.');
  const cur = selected || S.t.current_round || S.rounds[S.rounds.length - 1].number;
  const rd = S.rounds.find((r) => r.number === cur) || S.rounds[S.rounds.length - 1];
  const games = S.games.filter((g) => g.round === rd.number);
  const stChip = { pending: ['Aguardando início', 'warn'], running: ['Em andamento', 'accent live'], finished: ['Finalizada', 'ok'] }[rd.status];
  return h('div', { class: 'stack' },
    h('div', { class: 'row', role: 'tablist', 'aria-label': 'Rodadas' }, S.rounds.map((r) => h('button', { class: 'btn small' + (r.number === rd.number ? ' primary' : ''), role: 'tab', 'aria-selected': String(r.number === rd.number), onclick: () => onSelect(r.number) }, 'Rodada ' + r.number))),
    h('div', { class: 'row' }, h('h2', { style: 'margin:0' }, `Rodada ${rd.number}${S.t.rounds_total ? ' de ' + S.t.rounds_total : ''}`), h('span', { class: 'chip ' + stChip[1] }, stChip[0])),
    h('div', { class: 'card pad0' }, gameRows(games, { actions, meId })));
}
