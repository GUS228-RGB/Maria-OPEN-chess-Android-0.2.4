// Estado compartilhado, chamadas à API e WebSocket com reconexão automática.
export const S = {
  t: null, players: [], rounds: [], games: [], standings: [], tiebreaks: [], stats: null, imported: [],
  me: null, token: null, admin: false, adminStatus: null,
  conn: 'connecting', loaded: false, error: null, sig: '',
};

const listeners = new Set();
export const subscribe = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
export const notify = () => listeners.forEach((fn) => fn());

try { S.token = localStorage.getItem('oc.token'); } catch (_) { S.token = null; }
export function setToken(t) { S.token = t; try { t ? localStorage.setItem('oc.token', t) : localStorage.removeItem('oc.token'); } catch (_) { /* sem armazenamento */ } }

export class ApiError extends Error { constructor(message, code, status) { super(message); this.code = code; this.status = status; } }

export async function api(method, path, body) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (S.token) headers['X-Player-Token'] = S.token;
  let r;
  try { r = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), credentials: 'same-origin' }); }
  catch (_) { throw new ApiError('Sem conexão com o servidor do torneio. Verifique o Wi-Fi.', 'network', 0); }
  const ct = r.headers.get('content-type') || '';
  const data = ct.includes('json') ? await r.json().catch(() => ({})) : await r.text();
  if (!r.ok) throw new ApiError((data && data.error && data.error.message) || `Erro ${r.status}`, data && data.error && data.error.code, r.status);
  return data;
}
export const text = async (path) => { const r = await fetch(path, { credentials: 'same-origin' }); if (!r.ok) throw new ApiError('Não foi possível obter o arquivo.', 'http', r.status); return r.text(); };

// ---------------------------------------------------------------- carga de dados
let refreshing = null, again = false;
export function refresh() {
  if (refreshing) { again = true; return refreshing; }
  refreshing = (async () => {
    try {
      const [t, pl, rd, st] = await Promise.all([api('GET', '/api/tournament'), api('GET', '/api/players'), api('GET', '/api/rounds'), api('GET', '/api/standings')]);
      S.t = t; S.players = pl.players; S.rounds = rd.rounds; S.games = rd.games; S.standings = st.standings; S.tiebreaks = st.tiebreaks;
      if (S.token) {
        try { S.me = await api('GET', '/api/me'); }
        catch (e) { if (e.status === 401) { S.me = null; setToken(null); } }
      } else S.me = null;
      S.error = null; S.loaded = true;
      if (S.t.status === 'finished' || S.statsWanted) S.stats = await api('GET', '/api/stats').catch(() => S.stats);
      if (S.importedWanted) S.imported = (await api('GET', '/api/imported').catch(() => ({ games: [] }))).games;
      if (S.admin) S.adminStatus = (await api('GET', '/api/admin/session').catch(() => ({}))).status || S.adminStatus;
    } catch (e) { S.error = e.message; }
    notify();
  })().finally(() => { refreshing = null; if (again) { again = false; refresh(); } });
  return refreshing;
}

// ---------------------------------------------------------------- WebSocket
const gameHandlers = new Set();
export const onGameMessage = (fn) => { gameHandlers.add(fn); return () => gameHandlers.delete(fn); };
const watching = new Set();
let ws = null, retry = 0, timer = null, wantOpen = false, debounce = null;

function setConn(c) { if (S.conn !== c) { S.conn = c; notify(); } }

export function connectWs() {
  wantOpen = true;
  if (ws && (ws.readyState === 0 || ws.readyState === 1)) return;
  const url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
  ws = new WebSocket(url);
  ws.onopen = () => {
    retry = 0; S.closing = false; setConn('ok');
    if (S.token) wsSend({ type: 'auth', token: S.token });
    for (const g of watching) wsSend({ type: 'watch', game: g });
    refresh(); // recupera o que mudou enquanto estava desconectado
  };
  ws.onmessage = (e) => {
    let m; try { m = JSON.parse(e.data); } catch (_) { return; }
    if (m.type === 'closing') { S.closing = true; notify(); }
    else if (m.type === 'invalidate') { clearTimeout(debounce); debounce = setTimeout(refresh, 120); }
    else if (m.type === 'game' || m.type === 'error') gameHandlers.forEach((fn) => fn(m));
  };
  ws.onclose = () => {
    setConn('bad');
    if (!wantOpen) return;
    clearTimeout(timer);
    timer = setTimeout(connectWs, Math.min(5000, 400 * 2 ** retry++));
  };
  ws.onerror = () => { try { ws.close(); } catch (_) { /* já fechado */ } };
}
export function wsSend(obj) { if (ws && ws.readyState === 1) { ws.send(JSON.stringify(obj)); return true; } return false; }
export function authWs() { if (S.token) wsSend({ type: 'auth', token: S.token }); }
export function watchGame(id) { watching.add(id); wsSend({ type: 'watch', game: id }); }
export function unwatchGame(id) { watching.delete(id); wsSend({ type: 'unwatch', game: id }); }
