// Motor das animações de vitória: registro extensível, tela de sobreposição, laço de desenho e preferências.
// Para criar uma animação nova: registerAnimation('id', { title, duration, setup, draw, sound }) em effects.js
// e acrescentar o id ao catálogo do servidor (src/core/animations.js).
import { h } from '../dom.js';
import { makeAudio } from './audio.js';

const registry = new Map();
export const registerAnimation = (id, def) => registry.set(id, def);
export const hasAnimation = (id) => registry.has(id);

// ------------------------------------------------------------ preferências (por aparelho)
function read(k, d) { try { const v = localStorage.getItem('oc.anim.' + k); return v === null ? d : v === '1'; } catch (_) { return d; } }
function write(k, v) { try { localStorage.setItem('oc.anim.' + k, v ? '1' : '0'); } catch (_) { /* sem armazenamento */ } }
export const prefs = {
  get on() { return read('on', true); }, set on(v) { write('on', v); },
  get sound() { return read('sound', true); }, set sound(v) { write('sound', v); },
  get others() { return read('others', true); }, set others(v) { write('others', v); },   // espectador da partida vê a vitória
  get telao() { return read('telao', false); }, set telao(v) { write('telao', v); },      // modo telão: vitórias de todas as partidas
};

const reduced = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (_) { return false; } };
const lowEnd = () => { const n = navigator; return (n.hardwareConcurrency && n.hardwareConcurrency <= 4) || (n.deviceMemory && n.deviceMemory <= 2); };

// ------------------------------------------------------------ utilidades de desenho
const sprites = new Map();
/** Pequeno brilho radial pré-renderizado (muito mais barato que gradiente a cada partícula). */
export function glow(color) {
  let s = sprites.get(color);
  if (!s) {
    s = document.createElement('canvas'); s.width = s.height = 64;
    const g = s.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, color); gr.addColorStop(0.35, color.replace(/[\d.]+\)$/, '0.45)')); gr.addColorStop(1, color.replace(/[\d.]+\)$/, '0)'));
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    sprites.set(color, s);
  }
  return s;
}
export const rand = (a, b) => a + Math.random() * (b - a);
export const TAU = Math.PI * 2;
export const ease = { out: (t) => 1 - (1 - t) ** 3, inOut: (t) => (t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2), back: (t) => { const c = 1.70158; return 1 + (c + 1) * (t - 1) ** 3 + c * (t - 1) ** 2; } };
export const clamp01 = (x) => Math.max(0, Math.min(1, x));

// ------------------------------------------------------------ execução
let current = null;
export function stopVictory() { if (current) current.end(); }

/**
 * Toca a animação. `force` ignora a preferência "desativar animações" (usado só em pré-visualização pedida pelo usuário).
 * Nunca lança erro: uma falha visual jamais pode afetar a partida.
 */
export function playVictory({ animation = 'padrao', name = '', force = false, onEnd = null } = {}) {
  try {
    if (!force && !prefs.on) return null;
    stopVictory();
    const def = registry.get(animation) || registry.get('padrao');
    if (!def) return null;
    return run(def, registry.has(animation) ? animation : 'padrao', String(name), onEnd);
  } catch (e) { console.warn('animação de vitória falhou:', e); return null; }
}

function run(def, id, name, onEnd) {
  const still = reduced();
  const title = h('div', { class: 'vic-title' }, def.title || 'VITÓRIA!');
  title.dataset.text = def.title || 'VITÓRIA!';
  const who = h('div', { class: 'vic-name' }, name);
  const canvas = still ? null : h('canvas', { class: 'vic-canvas', 'aria-hidden': 'true' });
  const closeBtn = h('button', { class: 'btn small vic-close', type: 'button', 'aria-label': 'Fechar animação' }, '✕');
  const root = h('div', { class: `vic t-${id}${still ? ' still' : ''}`, role: 'status', 'aria-live': 'polite' }, canvas, h('div', { class: 'vic-text' }, title, who), closeBtn);
  const bars = def.cinematic && !still ? [h('i', { class: 'vic-bar top' }), h('i', { class: 'vic-bar bot' })] : [];
  root.prepend(...bars);
  document.body.append(root);

  const duration = still ? 2800 : def.duration || 4200;
  let raf = 0, ended = false, audio = null, state = null;
  const q0 = lowEnd() ? 0.55 : 1;
  const env = { ctx: null, w: 0, h: 0, cx: 0, cy: 0, q: q0, dpr: 1, name };

  function resize() {
    if (!canvas) return;
    env.dpr = Math.min(window.devicePixelRatio || 1, q0 < 1 ? 1 : 1.5);
    env.w = window.innerWidth; env.h = window.innerHeight; env.cx = env.w / 2; env.cy = env.h / 2;
    canvas.width = Math.round(env.w * env.dpr); canvas.height = Math.round(env.h * env.dpr);
    env.ctx.setTransform(env.dpr, 0, 0, env.dpr, 0, 0);
  }
  if (canvas) { env.ctx = canvas.getContext('2d'); resize(); window.addEventListener('resize', resize); }

  if (prefs.sound && def.sound) { try { audio = makeAudio(); if (audio) def.sound(audio, still); } catch (_) { audio = null; } }
  if (canvas && def.setup) state = def.setup(env);

  const t0 = performance.now(); let last = t0, slow = 0, frames = 0;
  function frame(now) {
    if (ended) return;
    const t = now - t0, dt = Math.min(50, now - last); last = now;
    // adaptação de desempenho: se o aparelho não acompanha, reduz a quantidade de partículas
    frames++; if (dt > 30) slow++;
    if (frames % 20 === 0) { if (slow > 8 && env.q > 0.3) env.q *= 0.7; slow = 0; }
    if (canvas) {
      env.ctx.clearRect(0, 0, env.w, env.h);
      try { def.draw(env, state, t, dt / 1000); } catch (e) { console.warn(e); }
    }
    const k = t / duration;
    root.style.setProperty('--p', String(Math.min(1, k)));
    if (t >= duration + 700) return end();
    if (t >= duration) root.classList.add('out');
    raf = requestAnimationFrame(frame);
  }
  function end() {
    if (ended) return; ended = true;
    cancelAnimationFrame(raf); window.removeEventListener('resize', resize); document.removeEventListener('keydown', onKey);
    if (audio) audio.stop();
    root.remove(); if (current && current.root === root) current = null;
    if (onEnd) { try { onEnd(); } catch (_) { /* ok */ } }
  }
  const onKey = (e) => { if (e.key === 'Escape') end(); };
  document.addEventListener('keydown', onKey);
  closeBtn.addEventListener('click', end);
  if (still) setTimeout(() => root.classList.add('out'), duration), setTimeout(end, duration + 600);
  else raf = requestAnimationFrame(frame);
  current = { root, end };
  return { end };
}
