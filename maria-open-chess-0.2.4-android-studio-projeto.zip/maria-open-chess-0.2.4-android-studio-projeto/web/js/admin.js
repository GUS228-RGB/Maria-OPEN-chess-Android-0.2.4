// Painel do organizador. Todas as ações são revalidadas pelo servidor (a interface não é fonte de confiança).
import { h, LABELS, idLabel, fmtPts, fmtDate, toast, openForm, openDialog, confirmDialog, copyText } from './dom.js';
import { S, api, refresh } from './net.js';
import { playersTable, standingsTable, statsView, roundsView, emptyState, gameRows, pname } from './views.js';
import { infoChips, slotsBlock } from './public.js';
import { animView, accessView, loadAnim, loadAccess } from './admin-anim.js';

const TABS = [['visao', 'Visão geral'], ['participantes', 'Participantes'], ['rodadas', 'Rodadas e partidas'], ['classificacao', 'Classificação'], ['estatisticas', 'Estatísticas'], ['animacoes', 'Animações'], ['acesso', 'Convites e acesso'], ['config', 'Configurações'], ['exportar', 'Exportações e backup'], ['registro', 'Registro']];
let selectedRound = null;
S.adminData = {};

export async function initAdmin() {
  const m = /[#&]k=([^&]+)/.exec(location.hash);
  if (m) {
    try { await api('POST', '/api/admin/login', { key: decodeURIComponent(m[1]) }); S.admin = true; S.loginError = null; }
    catch (e) { S.admin = false; S.loginError = e.message; }
    history.replaceState(null, '', location.pathname + '#/visao'); // remove a chave da barra de endereço
  } else {
    try { await api('GET', '/api/admin/session'); S.admin = true; } catch (_) { S.admin = false; }
  }
}

async function act(fn, okMsg) {
  try { const r = await fn(); await refresh(); if (okMsg) toast(okMsg, 'ok'); return r; }
  catch (e) { toast(e.message, 'error'); if (e.status === 401) { S.admin = false; refresh(); } }
}

// ------------------------------------------------------------ login
function loginView() {
  return h('div', { class: 'card loginbox stack' },
    h('h1', { style: 'font-size:1.4rem' }, 'Painel do organizador'),
    S.loginError ? h('div', { class: 'err', role: 'alert' }, S.loginError) : null,
    h('p', { class: 'muted', style: 'margin:0' }, 'Digite a chave do organizador exibida no terminal (ou na tela de hospedagem do aplicativo).'),
    h('button', { class: 'btn primary', onclick: () => openForm({ title: 'Entrar como organizador', submitLabel: 'Entrar', fields: [{ name: 'key', label: 'Chave do organizador', type: 'password' }],
      async submit(v) { await api('POST', '/api/admin/login', { key: v.key }); S.admin = true; S.loginError = null; await refresh(); window.dispatchEvent(new Event('oc-rerender')); } }) }, 'Informar a chave'));
}

// ------------------------------------------------------------ ações de rodada / torneio
function curRound() { return S.rounds.find((r) => r.number === S.t.current_round) || null; }

function tournamentControls() {
  const t = S.t, cur = curRound();
  const btns = [];
  if (t.status === 'setup') {
    btns.push(h('button', { class: 'btn primary', onclick: async () => {
      if (S.players.length < 2) { toast('São necessários pelo menos 2 participantes.', 'error'); return; }
      if (await confirmDialog({ title: 'Iniciar o torneio?', message: `${S.players.length} participantes. As inscrições serão encerradas e a rodada 1 será gerada.`, confirmLabel: 'Iniciar torneio' })) act(() => api('POST', '/api/admin/start'), 'Torneio iniciado. Rodada 1 gerada.');
    } }, '▶ Iniciar torneio'));
  }
  if (t.status === 'running' && cur) {
    if (cur.status === 'pending') btns.push(h('button', { class: 'btn primary', onclick: () => act(() => api('POST', '/api/admin/round/start', { number: cur.number }), `Rodada ${cur.number} iniciada.`) }, `▶ Iniciar rodada ${cur.number}`));
    if (cur.status === 'running') btns.push(h('button', { class: 'btn primary', onclick: () => act(() => api('POST', '/api/admin/round/finish', { number: cur.number }), `Rodada ${cur.number} finalizada.`) }, `✔ Finalizar rodada ${cur.number}`));
    if (cur.status === 'finished') btns.push(h('button', { class: 'btn primary', onclick: () => act(() => api('POST', '/api/admin/next-round'), 'Nova rodada gerada.') }, '＋ Gerar próxima rodada'));
    btns.push(h('button', { class: 'btn danger', onclick: async () => { if (await confirmDialog({ title: 'Encerrar o torneio agora?', message: 'Partidas ainda abertas serão canceladas e a classificação atual vira a final. Não é possível desfazer.', confirmLabel: 'Encerrar torneio', danger: true })) act(() => api('POST', '/api/admin/finish'), 'Torneio encerrado.'); } }, 'Encerrar torneio'));
  }
  if (t.status === 'finished') btns.push(h('a', { class: 'btn primary', href: '/api/results.txt', download: '' }, '⬇ Baixar resultados (TXT)'));
  return h('div', { class: 'row' }, btns);
}

function registrationControls() {
  const t = S.t;
  if (t.status !== 'setup') return null;
  const set = (state, msg) => act(() => api('POST', '/api/admin/registration', { state }), msg);
  return h('div', { class: 'row' },
    h('span', { class: 'muted' }, 'Inscrições:'),
    h('button', { class: 'btn small' + (t.registration === 'open' ? ' primary' : ''), onclick: () => set('open', 'Inscrições abertas.') }, 'Abertas'),
    h('button', { class: 'btn small' + (t.registration === 'paused' ? ' primary' : ''), onclick: () => set('paused', 'Inscrições pausadas.') }, 'Pausar'),
    h('button', { class: 'btn small' + (t.registration === 'closed' ? ' primary' : ''), onclick: () => set('closed', 'Inscrições encerradas.') }, 'Encerrar'));
}

function addPlayerDialog() {
  openForm({ title: 'Adicionar participante', submitLabel: 'Adicionar', fields: [
    { name: 'name', label: 'Nome de exibição', maxlength: 40 }, { name: 'elo', label: 'Rating Elo (opcional)', type: 'number', min: 0, max: 4000 },
    { name: 'force', type: 'checkbox', label: 'Ignorar inscrições pausadas/encerradas', hint: 'O limite de vagas continua valendo.', value: true }],
  async submit(v) { await api('POST', '/api/admin/players', { name: v.name, elo: v.elo, force: v.force }); await refresh(); toast('Participante adicionado.', 'ok'); } });
}

// ------------------------------------------------------------ visão geral
function shareCard() {
  const st = S.adminStatus, inv = S.adminData.invite;
  const lan = st && st.urls && st.urls.lan.length ? st.urls.lan.map((a) => a.url) : [location.origin + '/'];
  const pub = st && st.public_url;
  const urls = inv ? inv.links.map((l) => l.url) : pub ? [pub, ...lan] : lan; // com o convite, todo link já leva o código de acesso (?c=)
  const main = urls[0];
  return h('div', { class: 'card' }, h('h2', null, 'Convidar participantes'),
    h('div', { class: 'share' },
      h('img', { src: '/api/qr.svg?text=' + encodeURIComponent(main), alt: 'QR Code do endereço de acesso: ' + main, width: 168, height: 168 }),
      h('div', { class: 'stack' },
        pub ? h('span', { class: 'chip ok' }, '● Acesso de qualquer rede ativo (primeiro endereço)') : null,
        inv ? h('div', { class: 'row' }, h('span', { class: 'chip ' + (inv.visibility === 'private' ? 'warn' : '') }, inv.visibility === 'private' ? 'Torneio privado' : 'Torneio público'), h('span', null, 'Código de acesso: ', h('b', { class: 'mono' }, inv.access_code_display)), h('a', { class: 'btn small', href: '#/acesso' }, 'Gerenciar convites')) : null,
        urls.map((u) => h('div', { class: 'row' }, h('div', { class: 'urlbox', style: 'flex:1' }, u), h('button', { class: 'btn small', onclick: async () => toast((await copyText(u)) ? 'Endereço copiado.' : 'Não foi possível copiar.', 'ok') }, 'Copiar'))),
        navigator.share ? h('button', { class: 'btn small', onclick: () => navigator.share({ title: S.t.name, text: 'Participe do torneio de xadrez: ' + S.t.name, url: main }).catch(() => {}) }, 'Compartilhar…') : null,
        h('p', { class: 'note', style: 'margin:0' }, pub ? 'O primeiro endereço (https) funciona de qualquer rede e é o que está no QR Code. Os demais só funcionam na mesma rede Wi-Fi/Ethernet. O túnel só fica de pé enquanto o computador do organizador estiver ligado com o programa aberto.' : 'Esse é um endereço de rede LOCAL: funciona para quem estiver na mesma rede Wi-Fi/Ethernet e não abre pela internet. Para jogadores em outras redes, reinicie com: open-chess host --tunnel.'))));
}

function hostCard() {
  const st = S.adminStatus; if (!st) return null;
  const up = st.uptime_s; const upTxt = up >= 3600 ? `${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}min` : up >= 60 ? `${Math.floor(up / 60)} min` : `${up}s`;
  return h('div', { class: 'card' }, h('h2', null, 'Estado da hospedagem'),
    h('dl', { class: 'kv', style: 'margin:0' },
      h('dt', null, 'Servidor'), h('dd', null, h('span', { class: 'chip ok' }, '● ativo'), ` há ${upTxt}`),
      h('dt', null, 'Porta'), h('dd', null, String(st.port)),
      h('dt', null, 'Conectados agora'), h('dd', null, `${st.connected} participante(s), ${st.viewers} conexão(ões)`),
      h('dt', null, 'Dados salvos em'), h('dd', { class: 'mono', style: 'word-break:break-all;font-weight:500' }, st.dir)));
}

function overview() {
  const t = S.t, st = S.adminStatus;
  const playing = S.games.filter((g) => g.state === 'playing' && g.black_id != null).length, done = S.games.filter((g) => g.state === 'finished' && g.black_id != null).length;
  return h('div', { class: 'stack' },
    h('section', { class: 'card hero stack' }, h('h1', null, t.name), t.description && h('p', null, t.description), infoChips(t), slotsBlock(t), tournamentControls(), registrationControls(),
      t.status === 'setup' && t.modality === 'hibrido' ? h('p', { class: 'note', style: 'margin:0' }, 'Torneio híbrido: as partidas são criadas como online. Antes de iniciar cada rodada, use "Editar confronto" para marcar quais serão presenciais.') : null),
    h('div', { class: 'stats' },
      h('div', { class: 'stat' }, h('b', null, `${t.players_count}/${t.max_players}`), h('span', null, 'participantes')),
      h('div', { class: 'stat' }, h('b', null, t.full ? 0 : t.slots_left), h('span', null, 'vagas restantes')),
      h('div', { class: 'stat' }, h('b', null, t.current_round ? `${t.current_round}${t.rounds_total ? '/' + t.rounds_total : ''}` : '—'), h('span', null, 'rodada atual')),
      h('div', { class: 'stat' }, h('b', null, playing), h('span', null, 'partidas em andamento')),
      h('div', { class: 'stat' }, h('b', null, done), h('span', null, 'resultados registrados')),
      h('div', { class: 'stat' }, h('b', null, st ? st.connected : '—'), h('span', null, 'conectados agora'))),
    h('div', { class: 'grid cols-2' }, shareCard(), hostCard()));
}

// ------------------------------------------------------------ participantes
function playersAdmin() {
  const t = S.t;
  const tbl = S.players.length ? h('div', { class: 'tablewrap' }, h('table', null,
    h('thead', null, h('tr', null, h('th', { class: 'num' }, 'ID'), h('th', null, 'Nome'), h('th', { class: 'num' }, 'Elo'), h('th', null, 'Situação'), h('th', null, ''))),
    h('tbody', null, S.players.map((p) => h('tr', { class: p.status === 'withdrawn' ? 'out' : '' },
      h('td', { class: 'num mono' }, String(p.number).padStart(3, '0')), h('td', null, p.name), h('td', { class: 'num' }, p.elo || '—'),
      h('td', null, p.status === 'withdrawn' ? h('span', { class: 'chip danger' }, 'desistiu') : p.connected ? h('span', { class: 'chip ok' }, 'conectado') : h('span', { class: 'chip' }, 'inscrito')),
      h('td', null, p.status === 'active' && t.status !== 'finished' ? h('button', { class: 'btn small danger', onclick: async () => {
        if (await confirmDialog({ title: t.status === 'setup' ? 'Remover participante?' : 'Marcar como desistente?', message: `${p.name} (ID ${idLabel(p.number)})`, confirmLabel: t.status === 'setup' ? 'Remover' : 'Marcar desistência', danger: true })) act(() => api('DELETE', '/api/admin/players/' + p.id), 'Feito.');
      } }, t.status === 'setup' ? 'Remover' : 'Desistência') : null)))))) : emptyState('Nenhum participante', 'Compartilhe o QR Code ou adicione manualmente.');
  return h('div', { class: 'stack' }, h('div', { class: 'row between' }, h('h2', { style: 'margin:0' }, `Participantes (${S.players.length}/${t.max_players})`), t.status !== 'finished' && h('button', { class: 'btn primary', onclick: addPlayerDialog }, '＋ Adicionar')), h('div', { class: 'card pad0' }, tbl));
}

// ------------------------------------------------------------ partidas
const activePlayers = () => S.players.filter((p) => p.status === 'active');

function pairingDialog(g) {
  const opts = activePlayers().map((p) => ({ value: p.id, label: `${p.name} ${idLabel(p.number)}` }));
  const fields = [{ name: 'white_id', label: 'Brancas', type: 'select', options: opts, value: g.white_id }, { name: 'black_id', label: 'Pretas', type: 'select', options: opts, value: g.black_id }];
  if (S.t.modality === 'hibrido') fields.push({ name: 'kind', label: 'Tipo de partida', type: 'select', value: g.kind, options: [{ value: 'online', label: 'Online (no navegador)' }, { value: 'presencial', label: 'Presencial (tabuleiro real)' }] });
  openForm({ title: `Editar confronto — tabuleiro ${g.board}`, intro: 'Só é possível antes de a rodada começar. Se o jogador escolhido já estiver em outro confronto da rodada, troque os dois confrontos em sequência.', fields, submitLabel: 'Salvar confronto',
    async submit(v) { await api('POST', '/api/admin/pairings', { edits: [{ id: g.id, white_id: Number(v.white_id), black_id: Number(v.black_id), kind: v.kind || g.kind }] }); await refresh(); toast('Confronto atualizado.', 'ok'); } });
}

function swapDialog(g, others) {
  // troca simples: permite trocar os adversários entre dois tabuleiros da mesma rodada
  openForm({ title: 'Trocar com outro tabuleiro', intro: 'Troca as Pretas deste confronto com as Pretas do tabuleiro escolhido (ambos precisam estar sem início).',
    fields: [{ name: 'other', label: 'Outro tabuleiro', type: 'select', options: others.map((o) => ({ value: o.id, label: `Tab. ${o.board}: ${o.white.name} × ${o.black.name}` })) }],
    async submit(v) { const o = others.find((x) => x.id === Number(v.other)); await api('POST', '/api/admin/pairings', { edits: [{ id: g.id, black_id: o.black_id }, { id: o.id, black_id: g.black_id }] }); await refresh(); toast('Confrontos trocados.', 'ok'); } });
}

function correctionDialog(g) {
  openForm({ title: 'Corrigir resultado', danger: true, submitLabel: 'Registrar correção',
    intro: `${g.white.name} × ${g.black.name} — resultado atual: ${g.result}. A correção fica registrada no histórico com a sua justificativa.`,
    fields: [{ name: 'result', label: 'Novo resultado', type: 'select', value: g.result, options: [{ value: '1-0', label: '1-0 (brancas vencem)' }, { value: '1/2-1/2', label: '½-½ (empate)' }, { value: '0-1', label: '0-1 (pretas vencem)' }] },
      { name: 'reason', label: 'Justificativa (obrigatória)', type: 'text', placeholder: 'Ex.: erro de digitação no lançamento' }],
    async submit(v) { await api('POST', `/api/admin/games/${g.id}/result`, { result: v.result, correction: true, reason: v.reason }); await refresh(); toast('Resultado corrigido.', 'ok'); } });
}

function parseMoveText(txt) {
  return txt.replace(/\[[^\]]*\]/g, ' ').replace(/\{[^}]*\}/g, ' ').replace(/;[^\n]*/g, ' ').replace(/\([^)]*\)/g, ' ').replace(/\$\d+/g, ' ')
    .replace(/\d+\s*\.(\.\.)?/g, ' ').replace(/(1-0|0-1|1\/2-1\/2|\*)/g, ' ').split(/\s+/).filter(Boolean);
}
function movesDialog(g) {
  openForm({ title: `Anexar lances — ${g.white.name} × ${g.black.name}`, submitLabel: 'Validar e salvar', intro: 'Cole os lances em notação SAN (ex.: 1. e4 e5 2. Nf3 Nc6) ou um PGN. O servidor confere cada lance; lances ilegais são recusados e nada é salvo. Esses lances são os únicos registrados: o sistema nunca inventa histórico.',
    fields: [{ name: 'txt', label: 'Lances / PGN', type: 'textarea', rows: 8, placeholder: '1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 ...' }],
    async submit(v) { const sans = parseMoveText(v.txt); if (!sans.length) throw new Error('Cole ao menos um lance.'); const r = await api('POST', `/api/admin/games/${g.id}/moves`, { moves: sans }); await refresh(); toast(`${r.plies} lances salvos.`, 'ok'); } });
}

function gameActions(g) {
  if (g.black_id == null) return null;
  const out = [];
  const rd = S.rounds.find((r) => r.number === g.round);
  const rec = (result) => act(() => api('POST', `/api/admin/games/${g.id}/result`, { result }), 'Resultado registrado.');
  if (g.state === 'finished') {
    out.push(h('button', { class: 'btn small', onclick: () => correctionDialog(g) }, 'Corrigir'));
  } else if (rd && rd.status === 'running' && ['waiting', 'playing'].includes(g.state)) {
    if (g.kind === 'online' && g.state === 'playing') out.push(h('span', { class: 'chip accent' }, 'jogo ao vivo'));
    else out.push(h('button', { class: 'btn small', 'aria-label': 'Brancas vencem', onclick: () => rec('1-0') }, '1-0'), h('button', { class: 'btn small', 'aria-label': 'Empate', onclick: () => rec('1/2-1/2') }, '½-½'), h('button', { class: 'btn small', 'aria-label': 'Pretas vencem', onclick: () => rec('0-1') }, '0-1'));
  }
  if (g.state !== 'finished') {
    if (['waiting', 'playing'].includes(g.state) && rd && rd.status === 'running' && !(g.kind === 'online' && g.state === 'playing')) {
      out.push(h('button', { class: 'btn small', onclick: () => act(() => api('POST', `/api/admin/games/${g.id}/state`, { state: 'postponed' }), 'Partida adiada.') }, 'Adiar'));
    }
    if (['postponed', 'cancelled'].includes(g.state)) out.push(h('button', { class: 'btn small', onclick: () => act(() => api('POST', `/api/admin/games/${g.id}/state`, { state: 'waiting' }), 'Partida reativada.') }, 'Reativar'));
    else if (!(g.kind === 'online' && g.state === 'playing')) out.push(h('button', { class: 'btn small danger', onclick: async () => { if (await confirmDialog({ title: 'Cancelar partida?', message: `${g.white.name} × ${g.black.name}`, confirmLabel: 'Cancelar partida', danger: true })) act(() => api('POST', `/api/admin/games/${g.id}/state`, { state: 'cancelled' }), 'Partida cancelada.'); } }, 'Cancelar'));
  }
  if (rd && rd.status === 'pending') {
    out.push(h('button', { class: 'btn small', onclick: () => pairingDialog(g) }, 'Editar confronto'));
    const others = S.games.filter((x) => x.round === g.round && x.id !== g.id && x.black_id != null);
    if (others.length) out.push(h('button', { class: 'btn small', onclick: () => swapDialog(g, others) }, 'Trocar'));
  }
  if (g.kind === 'presencial' && g.state !== 'cancelled') out.push(h('button', { class: 'btn small ghost', onclick: () => movesDialog(g) }, 'Lances'));
  return out;
}

function gamesAdmin() {
  const cur = curRound();
  return h('div', { class: 'stack' },
    h('div', { class: 'row between' }, h('h2', { style: 'margin:0' }, 'Gerenciar rodadas'), tournamentControls()),
    cur && cur.status === 'pending' ? h('div', { class: 'banner warn' }, `A rodada ${cur.number} ainda não começou: você pode editar ou trocar confrontos antes de iniciar.`) : null,
    roundsView({ selected: selectedRound, onSelect: (n) => { selectedRound = n; window.dispatchEvent(new Event('oc-rerender')); }, actions: gameActions }));
}

// ------------------------------------------------------------ configurações
function configView() {
  const t = S.t;
  const edit = () => {
    const tbOpts = [{ value: '', label: '— nenhum —' }, ...Object.entries(LABELS.tiebreak).map(([k, v]) => ({ value: k, label: v }))];
    const fields = [
      { name: 'name', label: 'Nome do torneio', value: t.name }, { name: 'description', label: 'Descrição', type: 'textarea', rows: 3, value: t.description },
      { name: 'max_players', label: 'Máximo de participantes', type: 'range', min: Math.max(2, t.players_count), max: 256, value: t.max_players },
      { name: 'modality', label: 'Modalidade', type: 'select', value: t.modality, options: Object.entries(LABELS.modality).map(([value, label]) => ({ value, label })) },
      { name: 'system', label: 'Sistema de disputa', type: 'select', value: t.system, options: Object.entries(LABELS.system).map(([value, label]) => ({ value, label })) },
      { name: 'rounds_total', label: 'Rodadas (vazio = automático; só Suíço)', type: 'number', min: 1, max: 99, value: t.rounds_total ?? '' },
      { name: 'rr_double', type: 'checkbox', label: 'Round Robin com turno e returno', value: t.rr_double },
      { name: 'time_min', label: 'Tempo por jogador (minutos)', type: 'number', min: 1, max: 1440, step: 'any', value: t.time_base_s / 60 }, { name: 'time_inc_s', label: 'Incremento por lance (segundos)', type: 'number', min: 0, max: 3600, value: t.time_inc_s },
      { name: 'pts_win', label: 'Pontos por vitória', type: 'number', step: 'any', value: t.pts_win }, { name: 'pts_draw', label: 'Pontos por empate', type: 'number', step: 'any', value: t.pts_draw }, { name: 'pts_loss', label: 'Pontos por derrota', type: 'number', step: 'any', value: t.pts_loss },
      { name: 'tables_count', label: 'Mesas físicas (0 = sem limite)', type: 'number', min: 0, max: 500, value: t.tables_count },
    ];
    for (let i = 0; i < 3; i++) fields.push({ name: 'tb' + i, label: `${i + 1}º critério de desempate`, type: 'select', options: tbOpts, value: t.tiebreaks[i] || '' });
    openForm({ title: 'Editar configurações', fields, submitLabel: 'Salvar',
      async submit(v) {
        const tb = [0, 1, 2].map((i) => v['tb' + i]).filter(Boolean);
        if (new Set(tb).size !== tb.length) throw new Error('Não repita critérios de desempate.');
        await api('POST', '/api/admin/config', { name: v.name, description: v.description, max_players: v.max_players, modality: v.modality, system: v.system, rounds_total: v.rounds_total, rr_double: v.rr_double,
          time_base_s: Math.round((v.time_min || 10) * 60), time_inc_s: v.time_inc_s ?? 0, pts_win: v.pts_win, pts_draw: v.pts_draw, pts_loss: v.pts_loss, tables_count: v.tables_count, tiebreaks: tb });
        await refresh(); toast('Configurações salvas.', 'ok');
      } });
  };
  return h('div', { class: 'card stack' }, h('div', { class: 'row between' }, h('h2', { style: 'margin:0' }, 'Configurações do torneio'), t.status === 'setup' ? h('button', { class: 'btn primary', onclick: edit }, 'Editar') : h('span', { class: 'chip' }, 'bloqueadas após o início')),
    h('dl', { class: 'kv' },
      h('dt', null, 'Nome'), h('dd', null, t.name), h('dt', null, 'Modalidade'), h('dd', null, LABELS.modality[t.modality]), h('dt', null, 'Sistema'), h('dd', null, LABELS.system[t.system] + (t.rr_double ? ' (turno e returno)' : '')),
      h('dt', null, 'Rodadas'), h('dd', null, t.rounds_total ?? 'automático'), h('dt', null, 'Máx. participantes'), h('dd', null, t.max_players),
      t.modality !== 'presencial' && [h('dt', null, 'Controle de tempo'), h('dd', null, `${t.time_base_s / 60} min + ${t.time_inc_s}s por lance`)],
      t.modality !== 'online' && [h('dt', null, 'Mesas físicas'), h('dd', null, t.tables_count || 'sem limite')],
      h('dt', null, 'Pontuação'), h('dd', null, `vitória ${fmtPts(t.pts_win)} · empate ${fmtPts(t.pts_draw)} · derrota ${fmtPts(t.pts_loss)}`),
      h('dt', null, 'Desempate'), h('dd', null, t.tiebreaks.map((k) => LABELS.tiebreak[k]).join(' → ') || '—')));
}

// ------------------------------------------------------------ exportações e backup
function importPgnDialog() {
  let ta;
  openDialog({ title: 'Importar PGN', build(body) {
    ta = h('textarea', { placeholder: '[Event "..."]\n1. e4 e5 ...', 'aria-label': 'Texto do PGN' });
    const file = h('input', { type: 'file', accept: '.pgn,.txt,text/plain', 'aria-label': 'Arquivo PGN', onchange: async (e) => { const f = e.target.files[0]; if (f) ta.value = await f.text(); } });
    body.append(h('p', { class: 'muted', style: 'margin-top:0' }, 'Escolha um arquivo .pgn ou cole o texto. Partidas com lances ilegais são recusadas individualmente, com o motivo.'), h('div', { class: 'field' }, file), h('div', { class: 'field' }, ta));
  }, actions: [{ label: 'Importar', class: 'primary', onClick: async (close) => {
    try { const r = await api('POST', '/api/admin/import-pgn', { pgn: ta.value }); close(); await refresh(); toast(`${r.imported.length} partida(s) importada(s)${r.errors.length ? `; ${r.errors.length} recusada(s): ${r.errors.map((x) => `#${x.index} ${x.error}`).join('; ')}` : ''}.`, r.errors.length ? 'info' : 'ok', 9000); }
    catch (e) { toast(e.message, 'error'); } } }] });
}

function exportView() {
  const d = S.adminData;
  const row = (label, desc, ...btns) => h('div', { class: 'award' }, h('div', { style: 'flex:1' }, h('b', null, label), h('small', null, desc)), h('div', { class: 'row' }, btns));
  return h('div', { class: 'stack' },
    h('div', { class: 'card stack' }, h('h2', null, 'Resultados e PGN'),
      row('Resultados (TXT)', S.t.status === 'finished' ? 'O arquivo foi gerado automaticamente ao finalizar e fica na pasta do torneio.' : 'Gerado automaticamente ao finalizar. Você também pode salvar agora uma versão parcial.',
        h('button', { class: 'btn small', onclick: async () => { const r = await act(() => api('POST', '/api/admin/export/txt')); if (r) toast('Salvo em: ' + r.file, 'ok', 8000); } }, 'Salvar na pasta'), h('a', { class: 'btn small', href: '/api/results.txt', download: '' }, 'Baixar')),
      row('PGN do torneio', 'Partidas com lances registrados.', h('button', { class: 'btn small', onclick: async () => { try { const tx = await (await fetch('/api/pgn')).text(); toast((await copyText(tx)) ? 'PGN copiado.' : 'Não foi possível copiar.', 'ok'); } catch (e) { toast(e.message, 'error'); } } }, 'Copiar'), h('a', { class: 'btn small', href: '/api/pgn?download=1', download: '' }, 'Baixar')),
      row('PGN completo', 'Inclui presenciais só com resultado (sem lances inventados).', h('a', { class: 'btn small', href: '/api/pgn?todas=1&download=1', download: '' }, 'Baixar')),
      row('Importar PGN', 'Carregue partidas de arquivo para reproduzir e consultar.', h('button', { class: 'btn small primary', onclick: importPgnDialog }, 'Importar'))),
    S.imported.length ? h('div', { class: 'card' }, h('h3', null, 'Partidas importadas'), S.imported.map((g) => h('div', { class: 'row between', style: 'padding:6px 0' }, h('span', null, `${g.white} × ${g.black} `, h('span', { class: 'muted' }, `${g.event} ${g.date} · ${g.plies} lances · ${g.result}`)), h('a', { class: 'btn small', href: `#/pgn/${g.id}` }, 'Reproduzir')))) : null,
    h('div', { class: 'card stack' }, h('h2', null, 'Backup e integridade'),
      h('p', { class: 'note', style: 'margin:0' }, 'O servidor faz backups automáticos a cada rodada, a cada 10 minutos e ao encerrar (mantém os 20 mais recentes). Para restaurar, encerre a hospedagem e use: open-chess restore <arquivo.db>.'),
      h('div', { class: 'row' },
        h('button', { class: 'btn primary', onclick: async () => { const r = await act(() => api('POST', '/api/admin/backup')); if (r) { toast('Backup criado: ' + r.name, 'ok'); window.dispatchEvent(new Event('oc-rerender')); } } }, 'Criar backup agora'),
        h('button', { class: 'btn', onclick: async () => { try { const r = await api('GET', '/api/admin/integrity'); toast(r.ok ? 'Banco de dados íntegro ✔' : 'Problema de integridade: ' + r.integrity, r.ok ? 'ok' : 'error'); } catch (e) { toast(e.message, 'error'); } } }, 'Verificar integridade')),
      d.backups && d.backups.length ? h('div', { class: 'tablewrap' }, h('table', null, h('tbody', null, d.backups.slice(0, 12).map((b) => h('tr', null, h('td', { class: 'mono' }, b.name), h('td', { class: 'num' }, Math.max(1, Math.round(b.size / 1024)) + ' KB'), h('td', null, h('a', { class: 'btn small', href: '/api/admin/backups/' + encodeURIComponent(b.name), download: '' }, 'Baixar'))))))) : h('p', { class: 'muted', style: 'margin:0' }, 'Nenhum backup ainda.'),
      d.dir ? h('p', { class: 'note', style: 'margin:0' }, 'Pasta: ' + d.dir) : null));
}

function auditView() {
  const a = S.adminData.audit || [];
  if (!a.length) return emptyState('Sem registros', 'Cada ação do organizador e do sistema fica registrada aqui.');
  return h('div', { class: 'card pad0' }, h('div', { class: 'tablewrap' }, h('table', null,
    h('thead', null, h('tr', null, h('th', null, 'Quando'), h('th', null, 'Quem'), h('th', null, 'Ação'), h('th', null, 'Detalhes'))),
    h('tbody', null, a.map((x) => h('tr', null, h('td', null, fmtDate(x.ts)), h('td', null, x.actor), h('td', null, x.action.replace(/_/g, ' ') + (x.entity_id ? ` (${x.entity} ${x.entity_id})` : '')), h('td', { class: 'mono', style: 'font-size:.78rem;white-space:normal;max-width:360px' }, x.details ? JSON.stringify(x.details) : '')))))));
}

// ------------------------------------------------------------ entrada
export async function renderAdmin(root, tab) {
  if (!S.admin) { root.append(loginView()); return; }
  if (!S.t) { root.append(h('div', { class: 'empty-state' }, 'Carregando…')); return; }
  tab = TABS.some(([k]) => k === tab) ? tab : 'visao';
  S.statsWanted = tab === 'estatisticas'; S.importedWanted = tab === 'exportar';
  try {
    if (tab === 'registro') S.adminData.audit = (await api('GET', '/api/admin/audit?limit=300')).audit;
    if (tab === 'exportar') { const b = await api('GET', '/api/admin/backups'); S.adminData.backups = b.backups; S.adminData.dir = b.dir; if (!S.imported.length) S.imported = (await api('GET', '/api/imported')).games; }
    if (tab === 'estatisticas') S.stats = await api('GET', '/api/stats');
    if (tab === 'animacoes') await loadAnim();
    if (tab === 'acesso' || tab === 'visao') await loadAccess();
  } catch (e) { if (e.status === 401) { S.admin = false; root.append(loginView()); return; } }
  root.append(
    h('nav', { class: 'tabs', role: 'tablist', 'aria-label': 'Painel do organizador' }, TABS.map(([k, label]) => h('a', { class: 'tab', role: 'tab', href: '#/' + k, 'aria-selected': String(tab === k) }, label))),
    tab === 'visao' ? overview() : tab === 'participantes' ? playersAdmin() : tab === 'rodadas' ? gamesAdmin()
      : tab === 'classificacao' ? h('div', { class: 'card pad0' }, standingsTable()) : tab === 'estatisticas' ? statsView()
        : tab === 'animacoes' ? animView() : tab === 'acesso' ? accessView() : tab === 'config' ? configView() : tab === 'exportar' ? exportView() : auditView(),
    h('p', { class: 'note', style: 'margin-top:24px' }, h('button', { class: 'btn small ghost', onclick: async () => { await api('POST', '/api/admin/logout', {}); S.admin = false; refresh(); } }, 'Sair do painel')));
}
