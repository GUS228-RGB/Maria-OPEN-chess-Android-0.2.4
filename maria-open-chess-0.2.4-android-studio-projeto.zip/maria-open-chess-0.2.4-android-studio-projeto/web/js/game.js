// Tela de partida: ao vivo (online) ou reprodução (lances salvos / PGN importado).
import { h, fmtClock, idLabel, LABELS, resultText, toast, copyText, confirmDialog } from './dom.js';
import { S, api, text, wsSend, watchGame, unwatchGame, onGameMessage } from './net.js';
import { createBoard, fenToMap, turnOfFen } from './board.js';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

function resultLine(white, black, result, reason) {
  const why = reason && LABELS.reason[reason] ? ` por ${LABELS.reason[reason]}` : '';
  if (result === '1-0') return `Brancas vencem${why} — ${white}`;
  if (result === '0-1') return `Pretas vencem${why} — ${black}`;
  if (result === '1/2-1/2') return `Empate${why}`;
  return '';
}

function movesList(sans, cur, onPick) {
  const box = h('div', { class: 'moves', role: 'list', 'aria-label': 'Lances' });
  if (!sans.length) { box.append(h('div', { class: 'empty' }, 'Nenhum lance ainda.')); return box; }
  for (let i = 0; i < sans.length; i += 2) {
    box.append(h('div', { class: 'n' }, String(i / 2 + 1)));
    for (const k of [i, i + 1]) {
      if (k < sans.length) box.append(h('button', { class: 'm' + (cur === k + 1 ? ' cur' : ''), type: 'button', 'aria-current': cur === k + 1 ? 'true' : null, onclick: onPick ? () => onPick(k + 1) : null, disabled: !onPick }, sans[k]));
      else box.append(h('div'));
    }
  }
  return box;
}

/** Monta a tela. Retorna função de limpeza. */
export function mountGame(root, kind, id) {
  let disposed = false, cleanup = [];
  const dispose = () => { disposed = true; cleanup.forEach((f) => { try { f(); } catch (_) { /* ok */ } }); };
  root.textContent = '';
  root.append(h('div', { class: 'empty-state' }, 'Carregando partida…'));
  (kind === 'pgn' ? loadImported(id) : loadGame(id)).catch((e) => { if (!disposed) { root.textContent = ''; root.append(h('div', { class: 'card' }, h('div', { class: 'err' }, e.message), h('a', { class: 'btn', href: '#/' }, '← Voltar'))); } });

  async function loadImported(pid) {
    const d = await api('GET', '/api/imported/' + pid);
    if (disposed) return;
    const t = d.tags || {};
    build({
      title: `${t.White || '?'} × ${t.Black || '?'}`, white: { name: t.White || '?' }, black: { name: t.Black || '?' }, subtitle: [t.Event, t.Date].filter(Boolean).join(' · '),
      result: d.result, reason: null, moves: d.moves, fens: d.fens, uci: [], live: null, pgnUrl: null, noMovesMsg: null,
    });
  }

  async function loadGame(gid) {
    const d = await api('GET', '/api/games/' + gid);
    if (disposed) return;
    const g = d.game;
    const live = d.live && ['waiting', 'playing'].includes(g.state) ? d.live : null;
    build({
      title: `Rodada ${g.round} · Tabuleiro ${g.board}`, white: g.white, black: g.black, subtitle: `${g.kind === 'online' ? 'Partida online' : 'Partida presencial'}${g.table_no ? ' · Mesa ' + g.table_no : ''}`,
      result: g.state === 'finished' ? g.result : null, reason: g.reason, moves: d.replay.moves, fens: d.replay.fens, uci: d.replay.uci, live, gameId: gid,
      pgnUrl: d.replay.hasMoves || live ? `/api/games/${gid}/pgn` : null, state: g.state,
      noMovesMsg: !live && !d.replay.hasMoves ? (g.kind === 'presencial' ? 'Partida presencial: somente o resultado foi registrado, sem lances.' : 'Esta partida não tem lances registrados.') : null,
    });
  }

  function build(d) {
    root.textContent = '';
    let orientation = 'w';
    const board = createBoard({ onMove: (mv) => wsSend({ type: 'move', game: d.gameId, move: mv }) });
    let snap = null, snapAt = 0, ply = d.moves.length;
    const live = !!d.live;
    if (live) { snap = d.live; snapAt = performance.now(); if (snap.you === 'b') orientation = 'b'; }

    const topName = h('span', { class: 'nm' }), botName = h('span', { class: 'nm' });
    const topClock = h('span', { class: 'clock', 'aria-label': 'Relógio' }), botClock = h('span', { class: 'clock', 'aria-label': 'Relógio' });
    const topPres = h('span', { class: 'presence', title: 'Conexão' }), botPres = h('span', { class: 'presence', title: 'Conexão' });
    const topBar = h('div', { class: 'pbar' }, topPres, topName, live && topClock);
    const botBar = h('div', { class: 'pbar' }, botPres, botName, live && botClock);
    const status = h('div', { 'aria-live': 'polite' });
    const movesBox = h('div');
    const controls = h('div', { class: 'stack' });
    const navRow = h('div', { class: 'navbtns' });
    const hasBoard = live || d.moves.length > 0 || (d.fens && d.fens.length > 0 && d.moves.length > 0);

    const sideOf = (c) => (c === 'w' ? d.white : d.black);
    const clockOf = (c) => {
      if (!snap) return 0;
      let ms = c === 'w' ? snap.whiteMs : snap.blackMs;
      if (snap.state === 'playing' && snap.turn === c) ms -= performance.now() - snapAt;
      return ms;
    };
    function paintClocks() {
      if (!live || !snap) return;
      for (const [c, el, bar] of [[orientation === 'w' ? 'b' : 'w', topClock, topBar], [orientation === 'w' ? 'w' : 'b', botClock, botBar]]) {
        const ms = clockOf(c);
        el.textContent = fmtClock(ms);
        el.classList.toggle('low', snap.state === 'playing' && ms < 20000 && snap.turn === c);
        bar.classList.toggle('turn', snap.state === 'playing' && snap.turn === c);
      }
    }

    function paint() {
      const topC = orientation === 'w' ? 'b' : 'w', botC = orientation;
      const label = (c) => { const p = sideOf(c); return [h('span', { class: 'cdot ' + c }), p ? p.name : '—', p && p.number ? h('span', { class: 'pid' }, idLabel(p.number)) : null, snap && snap.you === c ? h('span', { class: 'chip accent', style: 'margin-left:8px' }, 'você') : null]; };
      topName.textContent = ''; botName.textContent = '';
      topName.append(...label(topC).filter(Boolean)); botName.append(...label(botC).filter(Boolean));
      if (live && snap) { topPres.classList.toggle('on', snap.presence[topC]); botPres.classList.toggle('on', snap.presence[botC]); }
      else { topPres.classList.add('hidden'); botPres.classList.add('hidden'); }

      status.textContent = ''; controls.textContent = '';
      if (live && snap) {
        board.update({ map: snap.board, orientation, last: snap.lastMove, checkColor: snap.inCheck ? snap.turn : null, legal: snap.legal || [], you: snap.you });
        movesBox.replaceChildren(movesList(snap.moves, snap.moves.length, null));
        const over = snap.state === 'finished';
        if (snap.state === 'waiting') status.append(h('div', { class: 'banner warn' }, h('span', null, snap.you ? 'Aguardando o adversário conectar para começar a partida e o relógio.' : 'Partida ainda não começou: aguardando os dois jogadores.')));
        else if (over) status.append(h('div', { class: 'banner' }, h('b', null, resultLine(d.white.name, d.black.name, snap.result, snap.reason))));
        else if (snap.you) {
          status.append(h('div', { class: 'banner' + (snap.turn === snap.you ? '' : ' warn') }, h('b', null, snap.turn === snap.you ? 'Sua vez de jogar' : 'Vez do adversário'), snap.inCheck ? h('span', { class: 'chip danger' }, 'xeque') : null));
        } else status.append(h('div', { class: 'banner' }, h('span', null, 'Você está assistindo.'), snap.inCheck ? h('span', { class: 'chip danger' }, 'xeque') : null));
        if (snap.you && snap.state === 'playing') {
          if (snap.drawOffer && snap.drawOffer !== snap.you) {
            controls.append(h('div', { class: 'banner warn' }, h('b', null, 'O adversário propôs empate.'), h('span', { class: 'row' }, h('button', { class: 'btn small primary', onclick: () => wsSend({ type: 'draw_response', game: d.gameId, accept: true }) }, 'Aceitar'), h('button', { class: 'btn small', onclick: () => wsSend({ type: 'draw_response', game: d.gameId, accept: false }) }, 'Recusar'))));
          }
          controls.append(h('div', { class: 'row' },
            h('button', { class: 'btn', disabled: snap.drawOffer === snap.you, onclick: () => { wsSend({ type: 'draw_offer', game: d.gameId }); toast('Proposta de empate enviada.'); } }, snap.drawOffer === snap.you ? 'Empate proposto…' : 'Propor empate'),
            h('button', { class: 'btn danger', onclick: async () => { if (await confirmDialog({ title: 'Abandonar a partida?', message: 'Você perderá a partida. Esta ação não pode ser desfeita.', confirmLabel: 'Abandonar', danger: true })) wsSend({ type: 'resign', game: d.gameId }); } }, 'Abandonar')));
        }
        paintClocks();
      } else {
        // reprodução
        const fens = d.fens && d.fens.length ? d.fens : [START];
        const maxPly = fens.length - 1;
        ply = Math.max(0, Math.min(ply, maxPly));
        if (hasBoard) {
          const check = ply > 0 && /[+#]$/.test(d.moves[ply - 1] || '') ? turnOfFen(fens[ply]) : null;
          board.update({ map: fenToMap(fens[ply]), orientation, last: ply > 0 && d.uci[ply - 1] ? d.uci[ply - 1] : null, checkColor: check, legal: [], you: null });
        }
        movesBox.replaceChildren(movesList(d.moves, ply, (p) => { ply = p; paint(); }));
        if (d.result) status.append(h('div', { class: 'banner' }, h('b', null, resultLine(d.white.name, d.black.name, d.result, d.reason) || ('Resultado: ' + resultText(d.result)))));
        navRow.replaceChildren(
          h('button', { class: 'btn iconbtn', 'aria-label': 'Início', disabled: ply === 0, onclick: () => { ply = 0; paint(); } }, '⏮'),
          h('button', { class: 'btn iconbtn', 'aria-label': 'Lance anterior', disabled: ply === 0, onclick: () => { ply--; paint(); } }, '◀'),
          h('button', { class: 'btn iconbtn', 'aria-label': 'Próximo lance', disabled: ply === maxPly, onclick: () => { ply++; paint(); } }, '▶'),
          h('button', { class: 'btn iconbtn', 'aria-label': 'Final', disabled: ply === maxPly, onclick: () => { ply = maxPly; paint(); } }, '⏭'));
      }
    }

    const flip = h('button', { class: 'btn small', type: 'button', onclick: () => { orientation = orientation === 'w' ? 'b' : 'w'; paint(); } }, '⇅ Virar tabuleiro');
    const pgnRow = d.pgnUrl ? h('div', { class: 'row' },
      h('button', { class: 'btn small', onclick: async () => { try { toast((await copyText(await text(d.pgnUrl))) ? 'PGN copiado.' : 'Não foi possível copiar.', 'ok'); } catch (e) { toast(e.message, 'error'); } } }, 'Copiar PGN'),
      h('a', { class: 'btn small', href: d.pgnUrl + '?download=1', download: '' }, 'Baixar PGN')) : null;

    root.append(h('div', { class: 'stack' },
      h('div', { class: 'row between' }, h('div', null, h('h1', { style: 'font-size:1.4rem' }, d.title), h('div', { class: 'muted' }, d.subtitle)), h('a', { class: 'btn small', href: '#/rodadas' }, '← Rodadas')),
      h('div', { class: 'gamewrap' },
        hasBoard ? h('div', { class: 'boardcol' }, topBar, board.el, botBar, !live && navRow, h('div', { class: 'row', style: 'justify-content:center' }, flip)) : h('div', { class: 'card' }, h('div', { class: 'empty-state' }, h('b', null, d.noMovesMsg || 'Sem tabuleiro'), d.result ? resultLine(d.white.name, d.black.name, d.result, d.reason) : '')),
        h('div', { class: 'stack' }, status, controls, hasBoard && h('div', null, h('h3', null, 'Lances'), movesBox), pgnRow, live ? null : null))));

    paint();
    if (!live && hasBoard) {
      const key = (e) => {
        if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement && document.activeElement.tagName)) return;
        const max = (d.fens ? d.fens.length : 1) - 1;
        if (e.key === 'ArrowLeft' && !document.activeElement.dataset.sq) { ply = Math.max(0, ply - 1); paint(); }
        else if (e.key === 'ArrowRight' && !document.activeElement.dataset.sq) { ply = Math.min(max, ply + 1); paint(); }
        else if (e.key === 'Home') { ply = 0; paint(); } else if (e.key === 'End') { ply = max; paint(); }
      };
      document.addEventListener('keydown', key); cleanup.push(() => document.removeEventListener('keydown', key));
    }
    if (live) {
      watchGame(d.gameId);
      cleanup.push(() => unwatchGame(d.gameId));
      const off = onGameMessage((m) => {
        if (m.type === 'error' && (m.game === d.gameId || m.game === undefined)) { toast(m.message, 'error'); return; }
        if (m.type !== 'game' || m.snapshot.id !== d.gameId) return;
        const prevState = snap && snap.state;
        snap = m.snapshot; snapAt = performance.now();
        if (snap.you === 'b' && !snap.moves.length && prevState !== 'playing') orientation = 'b';
        paint();
        if (snap.state === 'finished' && prevState !== 'finished') setTimeout(() => { if (disposed) return; const old = cleanup; cleanup = []; old.forEach((f) => { try { f(); } catch (_) { /* ok */ } }); cleanup.push(mountGame(root, 'game', d.gameId)); }, 600);
      });
      cleanup.push(off);
      const tick = setInterval(paintClocks, 100);
      cleanup.push(() => clearInterval(tick));
    }
  }
  return dispose;
}
