package br.com.mariaopenchess

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Collections

/**
 * O Node não consegue listar as interfaces de rede no Android 11+ (acesso bloqueado), então o lado nativo
 * grava os IPv4 do aparelho (Wi-Fi e ponto de acesso/hotspot) em lan.json, que o servidor lê.
 */
object LanAddresses {
    @Volatile private var last = ""

    fun write(ctx: Context) {
        val arr = JSONArray()
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return
            for (ni in Collections.list(all)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in Collections.list(ni.inetAddresses)) {
                    if (ia is Inet4Address && !ia.isLoopbackAddress && !ia.isLinkLocalAddress) {
                        arr.put(JSONObject().put("name", ni.name).put("address", ia.hostAddress))
                    }
                }
            }
        } catch (_: Exception) {
            return
        }
        val text = arr.toString()
        if (text == last) return
        val f = NodeRuntime.lanFile(ctx)
        val tmp = File(f.parentFile, "lan.json.tmp")
        tmp.writeText(text)
        tmp.renameTo(f)
        last = text
    }
}
