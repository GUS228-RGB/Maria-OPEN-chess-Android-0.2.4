package br.com.mariaopenchess

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.URLUtil
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Salva arquivos na pasta Downloads (TXT/PGN baixados pela interface e cópia dos torneios). */
object Downloads {
    private val LOCAL_HOSTS = setOf("localhost", "127.0.0.1")

    /** Descrição do local salvo, para mostrar ao usuário. */
    private fun saveToDownloads(ctx: Context, name: String, mime: String, write: (OutputStream) -> Unit): String {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safe)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Não foi possível criar o arquivo em Downloads")
            try {
                (resolver.openOutputStream(uri) ?: throw IllegalStateException("Sem acesso ao arquivo")).use(write)
                resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return ctx.getString(R.string.download_saved, safe)
        }
        // Android 8 a 9: pasta de Downloads do próprio aplicativo (não exige permissão de armazenamento)
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        dir.mkdirs()
        File(dir, safe).outputStream().use(write)
        return ctx.getString(R.string.download_saved_app, File(dir, safe).absolutePath)
    }

    /** Baixa [url] (somente do servidor local), usando os cookies da sessão do WebView. */
    fun saveFromUrl(ctx: Context, url: String, contentDisposition: String?, mime: String?): String {
        val u = URL(url)
        require(u.host in LOCAL_HOSTS) { "Endereço não permitido" }
        val name = URLUtil.guessFileName(url, contentDisposition, mime)
        val c = u.openConnection() as HttpURLConnection
        try {
            CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
            c.connectTimeout = 5000
            c.readTimeout = 30000
            if (c.responseCode != 200) throw IllegalStateException("HTTP ${c.responseCode}")
            val type = (mime?.takeIf { it.isNotBlank() } ?: c.contentType ?: "application/octet-stream").substringBefore(';')
            return saveToDownloads(ctx, name, type) { out -> c.inputStream.use { it.copyTo(out) } }
        } finally {
            c.disconnect()
        }
    }

    /** Zip com todos os torneios (bancos, backups, resultados) em Downloads. */
    fun exportAll(ctx: Context): String {
        val root = File(NodeRuntime.homeDir(ctx), "torneios")
        if (!root.exists() || root.listFiles().isNullOrEmpty()) throw IllegalStateException("Ainda não há torneios salvos.")
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        return saveToDownloads(ctx, "maria-open-chess-torneios-$stamp.zip", "application/zip") { out ->
            ZipOutputStream(out.buffered()).use { zip ->
                root.walkTopDown().filter { it.isFile && !it.name.endsWith(".tmp") }.forEach { f ->
                    zip.putNextEntry(ZipEntry("torneios/" + f.relativeTo(root).path.replace(File.separatorChar, '/')))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }
}
