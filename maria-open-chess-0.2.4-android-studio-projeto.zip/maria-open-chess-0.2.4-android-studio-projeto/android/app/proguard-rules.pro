# Sem minificação nesta versão (isMinifyEnabled = false). Mantém os métodos nativos, caso seja ativada.
-keepclasseswithmembernames class * { native <methods>; }
-keepclassmembers class br.com.mariaopenchess.MainActivity$AndroidBridge { @android.webkit.JavascriptInterface <methods>; }
