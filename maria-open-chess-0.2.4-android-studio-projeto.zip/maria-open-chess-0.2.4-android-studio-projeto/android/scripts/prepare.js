#!/usr/bin/env node
'use strict';
/**
 * Baixa o que o aplicativo Android precisa e que não vem junto do código (precisa de internet e de npm):
 *   1. libnode.so + cabeçalhos do nodejs-mobile (Node.js 18 para Android)  -> android/app/libnode/
 *   2. sql.js (SQLite em WebAssembly, pois o Node 18 não tem node:sqlite)  -> android/vendor/sql.js/
 *
 * Uso:  node android/scripts/prepare.js [--libnode-zip ARQUIVO.zip] [--skip-libnode] [--skip-sqljs]
 *   --libnode-zip  usa um zip do nodejs-mobile já baixado (nodejs-mobile-v18.20.4-android.zip), sem baixar.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const https = require('node:https');
const { spawnSync } = require('node:child_process');

const NODEJS_MOBILE = '18.20.4';
const SQLJS = '1.12.0';
const ABIS = ['arm64-v8a', 'armeabi-v7a', 'x86_64'];
const ROOT = path.join(__dirname, '..');
const LIBNODE = path.join(ROOT, 'app', 'libnode');
const VENDOR = path.join(ROOT, 'vendor', 'sql.js');
const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(n); return i >= 0 ? args[i + 1] : null; };

const say = (m) => console.log('• ' + m);
const die = (m) => { console.error('\nERRO: ' + m); process.exit(1); };

function download(url, dest, redirects = 6) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'maria-open-chess-prepare' } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); return resolve(download(new URL(res.headers.location, url).href, dest, redirects - 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`HTTP ${res.statusCode} em ${url}`)); }
      const out = fs.createWriteStream(dest);
      res.pipe(out); out.on('finish', () => out.close(resolve)); out.on('error', reject);
    }).on('error', reject);
  });
}

function extract(archive, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const attempts = archive.endsWith('.zip')
    ? [['unzip', ['-q', '-o', archive, '-d', dest]], ['tar', ['-xf', archive, '-C', dest]]]
    : [['tar', ['-xzf', archive, '-C', dest]]];
  for (const [cmd, a] of attempts) { const r = spawnSync(cmd, a, { stdio: 'ignore' }); if (!r.error && r.status === 0) return; }
  die(`Não consegui extrair ${archive}. Instale "unzip" (ou use um tar que abra .zip).`);
}

function walk(dir, fn) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, fn); else fn(p);
  }
}

async function libnode() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'libnode-'));
  try {
    let zip = opt('--libnode-zip');
    if (!zip) {
      zip = path.join(tmp, 'nodejs-mobile.zip');
      const name = `nodejs-mobile-v${NODEJS_MOBILE}-android.zip`;
      const urls = [`https://github.com/nodejs-mobile/nodejs-mobile/releases/download/v${NODEJS_MOBILE}/${name}`, `https://github.com/nodejs-mobile/nodejs-mobile/releases/download/nodejs-mobile-v${NODEJS_MOBILE}/${name}`];
      let ok = false;
      for (const u of urls) { say('Baixando ' + u); try { await download(u, zip); ok = true; break; } catch (e) { console.log('  falhou: ' + e.message); } }
      if (!ok) die(`Não foi possível baixar o nodejs-mobile.\nBaixe manualmente ${name} em https://github.com/nodejs-mobile/nodejs-mobile/releases e rode de novo com:\n  node android/scripts/prepare.js --libnode-zip CAMINHO/${name}`);
    }
    const x = path.join(tmp, 'x');
    extract(zip, x);
    fs.rmSync(LIBNODE, { recursive: true, force: true });
    let headers = null; const found = new Set();
    walk(x, (f) => {
      const abi = path.basename(path.dirname(f));
      if (path.basename(f) === 'libnode.so' && ABIS.includes(abi)) {
        fs.mkdirSync(path.join(LIBNODE, 'bin', abi), { recursive: true });
        fs.copyFileSync(f, path.join(LIBNODE, 'bin', abi, 'libnode.so')); found.add(abi);
      }
      if (path.basename(f) === 'node.h' && !headers) headers = path.dirname(f);
    });
    if (!headers) die('O zip não contém os cabeçalhos (node.h).');
    fs.cpSync(headers, path.join(LIBNODE, 'include', 'node'), { recursive: true });
    const missing = ABIS.filter((a) => !found.has(a));
    if (missing.length) die('O zip não contém libnode.so para: ' + missing.join(', '));
    say('libnode pronto em android/app/libnode (' + [...found].join(', ') + ')');
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

function sqljs() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sqljs-'));
  try {
    say(`Obtendo sql.js@${SQLJS} com npm`);
    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    const r = spawnSync(npm, ['pack', `sql.js@${SQLJS}`, '--silent', '--pack-destination', tmp], { encoding: 'utf8', shell: process.platform === 'win32' });
    if (r.status !== 0) die('npm pack falhou (sem internet ou sem npm?):\n' + (r.stderr || r.error));
    const tgz = fs.readdirSync(tmp).find((f) => f.endsWith('.tgz'));
    if (!tgz) die('npm pack não gerou o arquivo esperado.');
    extract(path.join(tmp, tgz), path.join(tmp, 'x'));
    const dist = path.join(tmp, 'x', 'package', 'dist');
    fs.rmSync(VENDOR, { recursive: true, force: true });
    fs.mkdirSync(VENDOR, { recursive: true });
    for (const f of ['sql-wasm.js', 'sql-wasm.wasm']) {
      if (!fs.existsSync(path.join(dist, f))) die(`sql.js@${SQLJS} não contém dist/${f}.`);
      fs.copyFileSync(path.join(dist, f), path.join(VENDOR, f));
    }
    const lic = path.join(tmp, 'x', 'package', 'LICENSE');
    if (fs.existsSync(lic)) fs.copyFileSync(lic, path.join(VENDOR, 'LICENSE'));
    say('sql.js pronto em android/vendor/sql.js');
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

(async () => {
  if (!args.includes('--skip-libnode')) await libnode();
  if (!args.includes('--skip-sqljs')) sqljs();
  console.log('\nPronto. Agora abra a pasta "android" no Android Studio (ou rode ./gradlew assembleDebug dentro dela).');
})().catch((e) => die(e.message));
