'use strict';
/**
 * Classificação, desempates e estatísticas. Funções puras: recebem dados simples.
 *  players: [{id, number, name, elo, status, seed}]
 *  games:   [{id, round, white_id, black_id, state, result, ...}]  (apenas state 'finished' conta)
 *  cfg:     {pts_win, pts_draw, pts_loss, bye_points, tiebreaks:[...], system}
 */

const TIEBREAK_KEYS = ['buchholz', 'buchholz_cut1', 'sonneborn_berger', 'wins', 'progressive', 'rating'];

function perPlayerRecords(players, games, cfg) {
  const rec = new Map();
  for (const p of players) {
    rec.set(p.id, { id: p.id, wins: 0, draws: 0, losses: 0, byes: 0, points: 0, played: 0, opps: [], progress: [], lastRound: 0, eliminatedRound: null });
  }
  const finished = games.filter((g) => g.state === 'finished' && g.result).sort((a, b) => a.round - b.round || a.id - b.id);
  for (const g of finished) {
    const w = rec.get(g.white_id);
    if (!w) continue;
    if (g.result === 'bye' || g.black_id == null) {
      w.byes++; w.points += cfg.bye_points; w.progress.push({ round: g.round, pts: cfg.bye_points });
      continue;
    }
    const b = rec.get(g.black_id);
    if (!b) continue;
    let rw, rb;
    if (g.result === '1-0') { rw = 1; rb = 0; w.wins++; b.losses++; w.points += cfg.pts_win; b.points += cfg.pts_loss; w.progress.push({ round: g.round, pts: cfg.pts_win }); b.progress.push({ round: g.round, pts: cfg.pts_loss }); }
    else if (g.result === '0-1') { rw = 0; rb = 1; b.wins++; w.losses++; b.points += cfg.pts_win; w.points += cfg.pts_loss; b.progress.push({ round: g.round, pts: cfg.pts_win }); w.progress.push({ round: g.round, pts: cfg.pts_loss }); }
    else { rw = 0.5; rb = 0.5; w.draws++; b.draws++; w.points += cfg.pts_draw; b.points += cfg.pts_draw; w.progress.push({ round: g.round, pts: cfg.pts_draw }); b.progress.push({ round: g.round, pts: cfg.pts_draw }); }
    w.played++; b.played++;
    w.opps.push({ id: b.id, r: rw, round: g.round });
    b.opps.push({ id: w.id, r: rb, round: g.round });
    w.lastRound = Math.max(w.lastRound, g.round); b.lastRound = Math.max(b.lastRound, g.round);
  }
  return rec;
}

function computeStandings(players, games, cfg) {
  const rec = perPlayerRecords(players, games, cfg);
  const byId = new Map(players.map((p) => [p.id, p]));

  for (const r of rec.values()) {
    const oppPoints = r.opps.map((o) => rec.get(o.id).points);
    r.buchholz = oppPoints.reduce((a, b) => a + b, 0);
    r.buchholz_cut1 = oppPoints.length > 1 ? r.buchholz - Math.min(...oppPoints) : r.buchholz;
    r.sonneborn_berger = r.opps.reduce((a, o) => a + (rec.get(o.id).points * o.r), 0);
    let cum = 0, prog = 0;
    for (const x of r.progress.sort((a, b) => a.round - b.round)) { cum += x.pts; prog += cum; }
    r.progressive = prog;
  }

  const keys = (cfg.tiebreaks || []).filter((k) => TIEBREAK_KEYS.includes(k));
  const val = (r, k) => (k === 'rating' ? (byId.get(r.id).elo || 0) : k === 'wins' ? r.wins : r[k]);

  let rows = players.map((p) => ({ player: p, ...rec.get(p.id) }));

  if (cfg.system === 'eliminatoria_simples' || cfg.system === 'eliminatoria_dupla') {
    markEliminations(rows, players, games, cfg);
    rows.sort((a, b) => {
      if (a.alive !== b.alive) return a.alive ? -1 : 1;
      if (a.champion !== b.champion) return a.champion ? -1 : 1;
      if (a.runnerUp !== b.runnerUp) return a.runnerUp ? -1 : 1;
      if (a.eliminatedRound !== b.eliminatedRound) return (b.eliminatedRound || 0) - (a.eliminatedRound || 0);
      return cmp(a, b);
    });
  } else rows.sort(cmp);

  function cmp(a, b) {
    if (b.points !== a.points) return b.points - a.points;
    for (const k of keys) {
      const d = val(b, k) - val(a, k);
      if (Math.abs(d) > 1e-9) return d;
    }
    return a.player.number - b.player.number; // ordem estável e determinística
  }

  // posição com empates reais compartilhando a mesma colocação visual
  rows.forEach((r, i) => {
    r.position = i + 1;
    r.score = r.points;
    r.tied = false;
  });
  if (!(cfg.system === 'eliminatoria_simples' || cfg.system === 'eliminatoria_dupla')) {
    for (let i = 1; i < rows.length; i++) {
      const a = rows[i - 1], b = rows[i];
      const same = a.points === b.points && keys.every((k) => Math.abs(val(a, k) - val(b, k)) < 1e-9);
      if (same) { b.tied = true; a.tied = true; }
    }
  }
  return rows;
}

/** Em eliminatórias, descobre quem continua vivo, campeão e vice. */
function markEliminations(rows, players, games, cfg) {
  const losses = new Map(players.map((p) => [p.id, 0]));
  const elimRound = new Map();
  const limit = cfg.system === 'eliminatoria_dupla' ? 2 : 1;
  const fin = games.filter((g) => g.state === 'finished' && g.result && g.result !== 'bye').sort((a, b) => a.round - b.round || a.id - b.id);
  for (const g of fin) {
    const loser = g.result === '1-0' ? g.black_id : g.result === '0-1' ? g.white_id : null;
    if (loser == null) continue;
    losses.set(loser, losses.get(loser) + 1);
    if (losses.get(loser) >= limit && !elimRound.has(loser)) elimRound.set(loser, g.round);
  }
  for (const p of players) if (p.status === 'withdrawn' && !elimRound.has(p.id)) elimRound.set(p.id, 0);
  const alive = rows.filter((r) => !elimRound.has(r.id));
  const tournamentOver = games.length > 0 && alive.length === 1 && !games.some((g) => g.state !== 'finished' && g.state !== 'cancelled');
  for (const r of rows) {
    r.losses_total = losses.get(r.id);
    r.alive = !elimRound.has(r.id);
    r.eliminatedRound = elimRound.get(r.id) || null;
    r.champion = tournamentOver && r.alive;
    r.runnerUp = false;
  }
  if (tournamentOver) {
    // vice: quem foi eliminado na última rodada em que houve jogo decisivo
    const lastLoser = fin.length ? (fin[fin.length - 1].result === '1-0' ? fin[fin.length - 1].black_id : fin[fin.length - 1].white_id) : null;
    const ru = rows.find((r) => r.id === lastLoser);
    if (ru && !ru.alive) ru.runnerUp = true;
  }
}

/** Estatísticas: só inclui o que existe nos dados; nunca inventa. */
function computeStats(players, games, cfg, standings, finished) {
  const stats = {};
  const played = games.filter((g) => g.state === 'finished' && g.result && g.result !== 'bye');
  const label = (r) => ({ id: r.id, number: r.player.number, name: r.player.name });

  if (finished && standings.length >= 1) {
    stats.champion = { ...label(standings[0]), points: standings[0].points };
    if (standings.length >= 2) stats.runnerUp = { ...label(standings[1]), points: standings[1].points };
    if (standings.length >= 3) stats.third = { ...label(standings[2]), points: standings[2].points };
  }
  if (played.length) {
    const maxWins = Math.max(...standings.map((r) => r.wins));
    if (maxWins > 0) stats.mostWins = standings.filter((r) => r.wins === maxWins).map((r) => ({ ...label(r), wins: r.wins }));

    // melhor desempenho = aproveitamento (pontos de resultado / partidas), com mínimo de 2 partidas
    const eligible = standings.filter((r) => r.played >= 2);
    if (eligible.length) {
      const perf = (r) => (r.wins + r.draws * 0.5) / r.played;
      const best = Math.max(...eligible.map(perf));
      stats.bestPerformance = {
        criterion: 'aproveitamento (vitórias + ½ empates) / partidas, mínimo de 2 partidas',
        value: Math.round(best * 1000) / 10,
        players: eligible.filter((r) => perf(r) === best).map(label),
      };
    }

    // maior sequência de vitórias consecutivas
    const streak = new Map();
    const best = new Map();
    for (const g of played.slice().sort((a, b) => a.round - b.round || a.id - b.id)) {
      const w = g.result === '1-0' ? g.white_id : g.result === '0-1' ? g.black_id : null;
      const l = g.result === '1-0' ? g.black_id : g.result === '0-1' ? g.white_id : null;
      const touched = [g.white_id, g.black_id];
      for (const id of touched) {
        if (id === w) { streak.set(id, (streak.get(id) || 0) + 1); best.set(id, Math.max(best.get(id) || 0, streak.get(id))); }
        else streak.set(id, 0);
      }
      void l;
    }
    const top = Math.max(0, ...best.values());
    if (top > 0) {
      stats.longestWinStreak = {
        wins: top,
        players: standings.filter((r) => best.get(r.id) === top).map(label),
      };
    }
  }
  const rated = standings.filter((r) => r.player.elo);
  if (rated.length) {
    const maxElo = Math.max(...rated.map((r) => r.player.elo));
    stats.highestRating = { elo: maxElo, players: rated.filter((r) => r.player.elo === maxElo).map(label) };
  }
  return stats;
}

module.exports = { computeStandings, computeStats, TIEBREAK_KEYS };
