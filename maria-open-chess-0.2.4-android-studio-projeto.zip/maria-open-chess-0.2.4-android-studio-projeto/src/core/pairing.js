'use strict';
/**
 * Sistemas de emparelhamento (funções puras).
 * Todas retornam pares {white, black} (ids) e, quando aplicável, `bye` (id).
 */

// ---------------------------------------------------------------- Suíço
/**
 * players: [{id, points, rating, seed, colors:['w'|'b'|null,...], opponents:Set<id>, hadBye:boolean}]
 * Já ordenados por classificação (melhor primeiro).
 */
function swissPairings(players, roundNumber) {
  const list = players.slice();
  let bye = null;

  const attempt = (allowRepeats) => {
    let pool = list.slice();
    let byePlayer = null;
    if (pool.length % 2 === 1) {
      // bye: o pior colocado que ainda não recebeu; se todos já receberam, o pior colocado
      const order = pool.slice().reverse();
      const candidates = order.filter((p) => !p.hadBye).concat(order.filter((p) => p.hadBye));
      for (const c of candidates) {
        const rest = pool.filter((p) => p !== c);
        const sol = solve(rest, allowRepeats);
        if (sol) return { pairs: sol, bye: c };
      }
      return null;
    }
    const sol = solve(pool, allowRepeats);
    return sol ? { pairs: sol, bye: byePlayer } : null;
  };

  let nodes = 0;
  const NODE_LIMIT = 300000;
  function solve(pool, allowRepeats) {
    nodes = 0;
    return rec(pool, allowRepeats);
  }
  function rec(pool, allowRepeats) {
    if (pool.length === 0) return [];
    if (++nodes > NODE_LIMIT) return null;
    const p = pool[0];
    const rest = pool.slice(1);
    const same = rest.filter((q) => q.points === p.points);
    const ideal = Math.floor(same.length / 2);
    const ordered = rest.map((q, i) => {
      const sameGroup = q.points === p.points;
      const gi = sameGroup ? same.indexOf(q) : 0;
      return { q, key: [Math.abs(q.points - p.points), sameGroup ? Math.abs(gi - ideal) : i] };
    }).sort((a, b) => a.key[0] - b.key[0] || a.key[1] - b.key[1]).map((x) => x.q);
    for (const q of ordered) {
      if (!allowRepeats && p.opponents.has(q.id)) continue;
      const remaining = rest.filter((x) => x !== q);
      const sub = rec(remaining, allowRepeats);
      if (sub) return [[p, q]].concat(sub);
    }
    return null;
  }

  let res = attempt(false);
  let repeats = false;
  if (!res) { res = attempt(true); repeats = true; }
  if (!res) throw new Error('Não foi possível emparelhar os jogadores');
  bye = res.bye ? res.bye.id : null;
  const pairs = res.pairs.map(([a, b]) => assignColors(a, b, roundNumber));
  return { pairs, bye, repeats };
}

function colorPref(p) {
  const hist = p.colors.filter(Boolean);
  const w = hist.filter((c) => c === 'w').length, b = hist.length - w;
  const last = hist[hist.length - 1], last2 = hist[hist.length - 2];
  if (last && last === last2) return { want: last === 'w' ? 'b' : 'w', strength: 3 };
  if (w !== b) return { want: w > b ? 'b' : 'w', strength: Math.abs(w - b) };
  if (last) return { want: last === 'w' ? 'b' : 'w', strength: 1 };
  return { want: null, strength: 0 };
}

function assignColors(a, b, roundNumber) {
  const pa = colorPref(a), pb = colorPref(b);
  let whiteIsA;
  if (pa.want && pb.want && pa.want !== pb.want) whiteIsA = pa.want === 'w';
  else if (pa.want && (!pb.want || pa.strength > pb.strength)) whiteIsA = pa.want === 'w';
  else if (pb.want && (!pa.want || pb.strength > pa.strength)) whiteIsA = pb.want === 'b';
  else whiteIsA = (a.seed + roundNumber) % 2 === 0; // sem preferência: alterna de forma determinística
  return whiteIsA ? { white: a.id, black: b.id } : { white: b.id, black: a.id };
}

// ---------------------------------------------------------------- Round Robin (tabelas de Berger)
/**
 * Retorna array de rodadas; cada rodada = {pairs:[{white,black}], bye:id|null}.
 * Jogadores numerados 1..n (n par; com número ímpar entra um "fantasma" fixo = folga/bye).
 * Rodada r: o fixo (n) joga contra r; os demais jogam (r-k) x (r+k) módulo (n-1).
 * Cores: equilíbrio perfeito com número ímpar de jogadores e diferença máxima de 1 com número par.
 */
function roundRobinSchedule(ids, double = false) {
  const arr = ids.slice();
  if (arr.length % 2 === 1) arr.push(null);
  const n = arr.length;
  const at = (num) => arr[num - 1];
  const rounds = [];
  for (let r = 1; r <= n - 1; r++) {
    const raw = [];
    raw.push(r % 2 === 0 ? [n, r] : [r, n]); // [branco, preto]
    for (let k = 1; k < n / 2; k++) {
      let a = (((r - k) % (n - 1)) + (n - 1)) % (n - 1); if (a === 0) a = n - 1;
      const b = ((r + k) % (n - 1)) || (n - 1);
      raw.push(k % 2 === 1 ? [a, b] : [b, a]);
    }
    const pairs = [];
    let bye = null;
    for (const [w, b] of raw) {
      const wid = at(w), bid = at(b);
      if (wid == null) bye = bid;
      else if (bid == null) bye = wid;
      else pairs.push({ white: wid, black: bid });
    }
    rounds.push({ pairs, bye });
  }
  if (double) {
    const second = rounds.map((rd) => ({ pairs: rd.pairs.map((p) => ({ white: p.black, black: p.white })), bye: rd.bye }));
    return rounds.concat(second);
  }
  return rounds;
}

// ---------------------------------------------------------------- Eliminatória simples
function bracketOrder(size) {
  let order = [1];
  while (order.length < size) {
    const n = order.length * 2;
    const next = [];
    for (const s of order) next.push(s, n + 1 - s);
    order = next;
  }
  return order;
}

/** ids ordenados por seed (melhor primeiro). Retorna rodada 1: {pairs, byes:[ids]} em ordem de chave. */
function singleElimFirstRound(idsBySeed) {
  const m = idsBySeed.length;
  let size = 1;
  while (size < m) size *= 2;
  const order = bracketOrder(size);
  const slots = order.map((seed) => (seed <= m ? idsBySeed[seed - 1] : null));
  const pairs = [], byes = [];
  const sequence = []; // em ordem de chave: {type:'game'|'bye'}
  for (let i = 0; i < size; i += 2) {
    const a = slots[i], b = slots[i + 1];
    if (a != null && b != null) { pairs.push({ white: a, black: b }); sequence.push({ type: 'game', index: pairs.length - 1 }); }
    else { byes.push(a != null ? a : b); sequence.push({ type: 'bye', player: a != null ? a : b }); }
  }
  return { pairs, byes, sequence };
}

/** Próximas rodadas: recebe vencedores em ordem de chave e emparelha vizinhos. */
function pairAdjacent(winnersInOrder, roundNumber) {
  const pairs = [];
  for (let i = 0; i + 1 < winnersInOrder.length; i += 2) {
    const a = winnersInOrder[i], b = winnersInOrder[i + 1];
    pairs.push((i / 2 + roundNumber) % 2 === 0 ? { white: a, black: b } : { white: b, black: a });
  }
  return pairs;
}

// ---------------------------------------------------------------- Eliminatória dupla (por contagem de derrotas)
/**
 * poolW: ids com 0 derrotas; poolL: ids com 1 derrota (ordenados por seed).
 * Regras: cada grupo joga entre si; se houver ímpar, o melhor seed que ainda não recebeu bye avança sem jogar.
 * Final: quando restar 1 em W e 1 em L, eles se enfrentam. Se L vencer, ambos têm 1 derrota e jogam de novo (reset).
 * recentOpponents: Set de "a-b" para evitar revanche imediata quando possível.
 */
function doubleElimRound(poolW, poolL, hadBye, lastPairs, roundNumber) {
  const pairs = [];
  const byes = [];
  const rematch = (a, b) => lastPairs.has(`${a}-${b}`) || lastPairs.has(`${b}-${a}`);
  const pairPool = (pool, bracket) => {
    let p = pool.slice();
    if (p.length < 2) return;
    if (p.length % 2 === 1) {
      const cand = p.find((x) => !hadBye.has(x)) ?? p[0];
      byes.push({ id: cand, bracket });
      p = p.filter((x) => x !== cand);
    }
    // evita revanche imediata quando houver alternativa
    const half = p.length / 2;
    let top = p.slice(0, half), bottom = p.slice(half).reverse();
    for (let i = 0; i < top.length; i++) {
      if (rematch(top[i], bottom[i])) {
        const j = bottom.findIndex((b, k) => k !== i && !rematch(top[i], b) && !rematch(top[k], bottom[i]));
        if (j >= 0) [bottom[i], bottom[j]] = [bottom[j], bottom[i]];
      }
    }
    for (let i = 0; i < top.length; i++) {
      const a = top[i], b = bottom[i];
      pairs.push({ ...((i + roundNumber) % 2 === 0 ? { white: a, black: b } : { white: b, black: a }), bracket });
    }
  };
  if (poolW.length === 1 && poolL.length === 1) {
    pairs.push({ white: poolW[0], black: poolL[0], bracket: 'F' });
  } else {
    pairPool(poolW, 'W');
    pairPool(poolL, 'L');
  }
  return { pairs, byes };
}

module.exports = { swissPairings, roundRobinSchedule, singleElimFirstRound, pairAdjacent, doubleElimRound, bracketOrder };
