'use strict';
const crypto = require('node:crypto');
const { computeStandings, computeStats, TIEBREAK_KEYS } = require('./standings');
const pairing = require('./pairing');
const { Game, START_FEN } = require('../chess/game');
const { parsePgn } = require('../chess/pgn');

class TournamentError extends Error {
  constructor(code, message, status = 400) { super(message); this.code = code; this.status = status; }
}
const fail = (code, msg, status) => { throw new TournamentError(code, msg, status); };

const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const newToken = () => crypto.randomBytes(16).toString('hex');
const now = () => new Date().toISOString();
const RESULTS = ['1-0', '0-1', '1/2-1/2'];
const MODALITIES = ['presencial', 'online', 'hibrido'];
const { splitNameCode } = require('./animations');
const SYSTEMS = ['suico', 'round_robin', 'eliminatoria_simples', 'eliminatoria_dupla'];
const isElim = (s) => s === 'eliminatoria_simples' || s === 'eliminatoria_dupla';

function cleanName(raw) {
  const s = String(raw ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').replace(/\s+/g, ' ').trim();
  if (s.length < 1) fail('invalid_name', 'Informe um nome de exibição.');
  if (s.length > 40) fail('invalid_name', 'O nome deve ter no máximo 40 caracteres.');
  return s;
}

function num(v, def, { min = -Infinity, max = Infinity, name = 'valor' } = {}) {
  if (v === undefined || v === null || v === '') return def;
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) fail('invalid_config', `Valor inválido para ${name}.`);
  return n;
}

class TournamentService {
  constructor(store) {
    this.store = store;
    this.listeners = new Set();
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit(type, data = {}) { for (const fn of this.listeners) { try { fn(type, data); } catch (_) { /* ouvinte não pode quebrar o núcleo */ } } }

  // ------------------------------------------------------------ criação
  static create(store, cfg) {
    if (store.get('SELECT id FROM tournament WHERE id=1')) fail('exists', 'Já existe um torneio neste banco de dados.');
    const c = TournamentService.normalizeConfig(cfg);
    store.tx(() => {
      store.run(`INSERT INTO tournament(id,name,description,modality,system,rounds_total,rr_double,time_base_s,time_inc_s,
        pts_win,pts_draw,pts_loss,bye_points,max_players,tables_count,tiebreaks,created_at)
        VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [c.name, c.description, c.modality, c.system, c.rounds_total, c.rr_double ? 1 : 0, c.time_base_s, c.time_inc_s,
          c.pts_win, c.pts_draw, c.pts_loss, c.bye_points, c.max_players, c.tables_count, JSON.stringify(c.tiebreaks), now()]);
      store.audit('sistema', 'torneio_criado', 'torneio', 1, { name: c.name, visibility: c.visibility });
      const svc = new TournamentService(store);
      svc._setMeta('visibility', c.visibility);
      svc._setMeta('access_code', svc.generateAccessCode());
    });
    return new TournamentService(store);
  }

  static normalizeConfig(cfg = {}) {
    const name = String(cfg.name ?? '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim();
    if (!name) fail('invalid_config', 'Informe o nome do torneio.');
    if (name.length > 100) fail('invalid_config', 'Nome do torneio muito longo (máx. 100).');
    const modality = cfg.modality ?? 'presencial';
    if (!MODALITIES.includes(modality)) fail('invalid_config', 'Modalidade inválida.');
    const system = cfg.system ?? 'suico';
    if (!SYSTEMS.includes(system)) fail('invalid_config', 'Sistema de disputa inválido.');
    const tb = cfg.tiebreaks ?? ['buchholz', 'sonneborn_berger', 'wins'];
    if (!Array.isArray(tb) || tb.some((k) => !TIEBREAK_KEYS.includes(k))) fail('invalid_config', 'Critério de desempate inválido.');
    const rounds = cfg.rounds_total === undefined || cfg.rounds_total === null || cfg.rounds_total === '' ? null : num(cfg.rounds_total, null, { min: 1, max: 99, name: 'rodadas' });
    if (rounds !== null && !Number.isInteger(rounds)) fail('invalid_config', 'Número de rodadas deve ser inteiro.');
    const pw = num(cfg.pts_win, 1, { min: 0, max: 100, name: 'pontos por vitória' });
    const pd = num(cfg.pts_draw, 0.5, { min: 0, max: 100, name: 'pontos por empate' });
    const pl = num(cfg.pts_loss, 0, { min: 0, max: 100, name: 'pontos por derrota' });
    if (!(pw >= pd && pd >= pl)) fail('invalid_config', 'A pontuação deve respeitar vitória ≥ empate ≥ derrota.');
    const max = num(cfg.max_players, 16, { min: 2, max: 512, name: 'máximo de participantes' });
    if (!Number.isInteger(max)) fail('invalid_config', 'Máximo de participantes deve ser inteiro.');
    const tables = num(cfg.tables_count, 0, { min: 0, max: 500, name: 'mesas' });
    if (!Number.isInteger(tables)) fail('invalid_config', 'Quantidade de mesas deve ser inteira.');
    const base = num(cfg.time_base_s, 600, { min: 10, max: 86400, name: 'tempo base' });
    const inc = num(cfg.time_inc_s, 0, { min: 0, max: 3600, name: 'incremento' });
    return {
      name, description: String(cfg.description ?? '').replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, '').slice(0, 1000),
      modality, system, rounds_total: rounds, rr_double: !!cfg.rr_double,
      time_base_s: Math.round(base), time_inc_s: Math.round(inc), pts_win: pw, pts_draw: pd, pts_loss: pl,
      bye_points: num(cfg.bye_points, pw, { min: 0, max: 100, name: 'pontos do bye' }),
      max_players: max, tables_count: tables, tiebreaks: tb,
      visibility: cfg.visibility === 'private' ? 'private' : 'public',
    };
  }

  // ------------------------------------------------------------ leitura
  tournament() {
    const t = this.store.get('SELECT * FROM tournament WHERE id=1');
    if (!t) fail('not_found', 'Torneio não encontrado.', 404);
    t.tiebreaks = JSON.parse(t.tiebreaks);
    t.rr_double = !!t.rr_double;
    return t;
  }

  publicInfo() {
    const { admin_hash, ...t } = this.tournament();
    const count = this.activePlayers().length;
    const total = this.store.get('SELECT COUNT(*) c FROM players').c;
    return { ...t, ...this.accessInfo(), players_count: total, active_players: count, slots_left: Math.max(0, t.max_players - total), full: total >= t.max_players };
  }

  players() {
    return this.store.all('SELECT id, number, name, elo, status, seed, joined_at FROM players ORDER BY number');
  }
  activePlayers() { return this.players().filter((p) => p.status === 'active'); }
  player(id) { return this.store.get('SELECT id, number, name, elo, status, seed FROM players WHERE id=?', [id]); }

  authPlayer(token) {
    if (!token || typeof token !== 'string') return null;
    return this.store.get('SELECT id, number, name, elo, status FROM players WHERE token_hash=?', [sha256(token)]) || null;
  }

  game(id) { return this.store.get('SELECT * FROM games WHERE id=?', [id]); }

  games(round = null) {
    const rows = round == null
      ? this.store.all('SELECT * FROM games ORDER BY round, board, id')
      : this.store.all('SELECT * FROM games WHERE round=? ORDER BY board, id', [round]);
    const pl = new Map(this.players().map((p) => [p.id, p]));
    return rows.map((g) => ({
      ...g,
      white: pl.get(g.white_id) ? { id: g.white_id, number: pl.get(g.white_id).number, name: pl.get(g.white_id).name } : null,
      black: g.black_id && pl.get(g.black_id) ? { id: g.black_id, number: pl.get(g.black_id).number, name: pl.get(g.black_id).name } : null,
    }));
  }

  rounds() { return this.store.all('SELECT * FROM rounds ORDER BY number'); }
  moves(gameId) { return this.store.all('SELECT ply, san, uci, fen, spent_ms FROM moves WHERE game_id=? ORDER BY ply', [gameId]); }
  auditLog(limit = 200) { return this.store.all('SELECT * FROM audit ORDER BY id DESC LIMIT ?', [limit]).map((a) => ({ ...a, details: a.details ? JSON.parse(a.details) : null })); }

  standings() {
    const t = this.tournament();
    return computeStandings(this.players(), this.store.all('SELECT * FROM games'), { ...t });
  }

  stats() {
    const t = this.tournament();
    const st = this.standings();
    const games = this.store.all('SELECT * FROM games');
    const s = computeStats(this.players(), games, t, st, t.status === 'finished');
    const longest = this.store.get(`SELECT g.id, COUNT(m.ply) plies FROM games g JOIN moves m ON m.game_id=g.id
      WHERE g.state='finished' GROUP BY g.id ORDER BY plies DESC, g.id LIMIT 1`);
    if (longest && longest.plies > 0) {
      const g = this.games().find((x) => x.id === longest.id);
      s.longestGame = { game_id: g.id, round: g.round, plies: longest.plies, moves: Math.ceil(longest.plies / 2), white: g.white, black: g.black };
    }
    return s;
  }

  // ------------------------------------------------------------ inscrições
  addPlayer(name, elo = null, { force = false, actor = 'participante' } = {}) {
    const t = this.tournament();
    const { name: rawName, code } = splitNameCode(name, fail); // "Gustavo<001>" → "Gustavo" + código 001
    const clean = cleanName(rawName);
    let rating = null;
    if (elo !== null && elo !== undefined && elo !== '') {
      rating = Number(elo);
      if (!Number.isInteger(rating) || rating < 0 || rating > 4000) fail('invalid_elo', 'Elo inválido (0 a 4000).');
    }
    return this.store.tx(() => {
      if (!force) {
        if (t.status !== 'setup') fail('registration_closed', 'As inscrições não estão mais abertas: o torneio já começou.', 409);
        if (t.registration === 'paused') fail('registration_paused', 'As inscrições estão pausadas pelo organizador.', 409);
        if (t.registration === 'closed') fail('registration_closed', 'As inscrições estão encerradas.', 409);
      }
      const count = this.store.get('SELECT COUNT(*) c FROM players').c;
      if (count >= t.max_players) fail('full', 'O torneio está lotado.', 409);
      const number = (this.store.get('SELECT COALESCE(MAX(number),0)+1 n FROM players').n);
      const token = newToken();
      const r = this.store.run('INSERT INTO players(number,name,elo,token_hash,joined_at) VALUES (?,?,?,?,?)', [number, clean, rating, sha256(token), now()]);
      const id = Number(r.lastInsertRowid);
      this.store.audit(actor, 'participante_inscrito', 'participante', id, { number, name: clean });
      const anim = code ? this._claimCode(id, code, clean, { organizer: actor === 'organizador' }) : null;
      const player = this.player(id);
      this.emit('players', {});
      return { player, token, anim };
    });
  }

  removePlayer(id, actor = 'organizador') {
    const t = this.tournament();
    return this.store.tx(() => {
      const p = this.player(id);
      if (!p) fail('not_found', 'Participante não encontrado.', 404);
      if (t.status === 'setup') {
        // o código de animação não fica "solto": passa a ser reservado para o nome de quem saiu
        this.store.run('UPDATE anim_codes SET reserved_name=?, player_id=NULL, claimed_at=NULL WHERE player_id=?', [p.name, id]);
        this.store.run('DELETE FROM players WHERE id=?', [id]);
        this.store.audit(actor, 'participante_removido', 'participante', id, { name: p.name });
      } else {
        this.store.run("UPDATE players SET status='withdrawn' WHERE id=?", [id]);
        this.store.audit(actor, 'participante_desistiu', 'participante', id, { name: p.name });
      }
      this.emit('players', {});
      return true;
    });
  }

  setRegistration(state, actor = 'organizador') {
    if (!['open', 'paused', 'closed'].includes(state)) fail('invalid', 'Estado de inscrição inválido.');
    const t = this.tournament();
    if (t.status !== 'setup' && state === 'open') fail('invalid', 'Não é possível reabrir inscrições depois do início.', 409);
    this.store.run('UPDATE tournament SET registration=? WHERE id=1', [state]);
    this.store.audit(actor, 'inscricoes_' + state, 'torneio', 1);
    this.emit('tournament', {});
  }

  updateConfig(patch, actor = 'organizador') {
    const t = this.tournament();
    if (t.status !== 'setup') fail('locked', 'As configurações só podem ser alteradas antes do início.', 409);
    const merged = TournamentService.normalizeConfig({ ...t, ...patch });
    this.store.tx(() => {
      this.store.run(`UPDATE tournament SET name=?,description=?,modality=?,system=?,rounds_total=?,rr_double=?,time_base_s=?,time_inc_s=?,
        pts_win=?,pts_draw=?,pts_loss=?,bye_points=?,max_players=?,tables_count=?,tiebreaks=? WHERE id=1`,
        [merged.name, merged.description, merged.modality, merged.system, merged.rounds_total, merged.rr_double ? 1 : 0, merged.time_base_s, merged.time_inc_s,
          merged.pts_win, merged.pts_draw, merged.pts_loss, merged.bye_points, merged.max_players, merged.tables_count, JSON.stringify(merged.tiebreaks)]);
      const count = this.store.get('SELECT COUNT(*) c FROM players').c;
      if (count > merged.max_players) fail('invalid_config', `Já existem ${count} participantes; o limite não pode ser menor.`);
      this.store.audit(actor, 'configuracao_alterada', 'torneio', 1, patch);
    });
    this.emit('tournament', {});
  }

  // ------------------------------------------------------------ início
  start(actor = 'organizador') {
    const t = this.tournament();
    if (t.status !== 'setup') fail('invalid_state', 'O torneio já foi iniciado.', 409);
    const players = this.activePlayers();
    const n = players.length;
    if (n < 2) fail('few_players', 'São necessários pelo menos 2 participantes para iniciar.', 409);
    let rounds = t.rounds_total;
    if (t.system === 'suico') {
      const maxR = n % 2 === 0 ? n - 1 : n;
      if (rounds == null) rounds = Math.max(1, Math.min(Math.ceil(Math.log2(n)), maxR));
      if (rounds > maxR) fail('invalid_config', `Com ${n} participantes, o sistema suíço permite no máximo ${maxR} rodadas sem repetir confrontos.`);
    } else if (t.system === 'round_robin') {
      rounds = (n % 2 === 0 ? n - 1 : n) * (t.rr_double ? 2 : 1);
    } else if (t.system === 'eliminatoria_simples') {
      rounds = Math.ceil(Math.log2(n));
    } else rounds = null; // eliminatória dupla: dinâmica
    this.store.tx(() => {
      const ordered = players.slice().sort((a, b) => (b.elo || 0) - (a.elo || 0) || a.number - b.number);
      ordered.forEach((p, i) => this.store.run('UPDATE players SET seed=? WHERE id=?', [i + 1, p.id]));
      this.store.run("UPDATE tournament SET status='running', registration='closed', rounds_total=?, started_at=? WHERE id=1", [rounds, now()]);
      this.store.audit(actor, 'torneio_iniciado', 'torneio', 1, { participantes: n, rodadas: rounds });
      this._createRound();
    });
    this.emit('tournament', {});
    return this.tournament();
  }

  // ------------------------------------------------------------ rodadas
  _defaultKind(t) { return t.modality === 'presencial' ? 'presencial' : 'online'; }

  _createRound() {
    const t = this.tournament();
    const number = (t.current_round || 0) + 1;
    const players = this.players();
    const active = players.filter((p) => p.status === 'active');
    const kind = this._defaultKind(t);
    const allGames = this.store.all('SELECT * FROM games');
    let pairs = [];       // {white,black,bracket?}
    let byes = [];        // {id, bracket?}
    let ordered = null;   // para eliminatória simples (ordem de chave)

    if (t.system === 'suico') {
      const st = computeStandings(players, allGames, t);
      const live = st.filter((r) => r.player.status === 'active');
      const sw = live.map((r) => {
        const mine = allGames.filter((g) => g.state === 'finished' && (g.white_id === r.id || g.black_id === r.id)).sort((a, b) => a.round - b.round);
        return {
          id: r.id, points: r.points, rating: r.player.elo || 0, seed: r.player.seed || r.player.number,
          colors: mine.map((g) => (g.black_id == null ? null : g.white_id === r.id ? 'w' : 'b')),
          opponents: new Set(mine.map((g) => (g.white_id === r.id ? g.black_id : g.white_id)).filter((x) => x != null)),
          hadBye: mine.some((g) => g.result === 'bye'),
        };
      });
      const res = pairing.swissPairings(sw, number);
      pairs = res.pairs; if (res.bye) byes = [{ id: res.bye }];
    } else if (t.system === 'round_robin') {
      const ids = players.slice().sort((a, b) => a.seed - b.seed).map((p) => p.id);
      const sched = pairing.roundRobinSchedule(ids, t.rr_double);
      const rd = sched[number - 1];
      if (!rd) fail('no_more_rounds', 'Todas as rodadas já foram geradas.', 409);
      pairs = rd.pairs; if (rd.bye != null) byes = [{ id: rd.bye }];
    } else if (t.system === 'eliminatoria_simples') {
      if (number === 1) {
        const seedOrder = active.slice().sort((a, b) => a.seed - b.seed).map((p) => p.id);
        const fr = pairing.singleElimFirstRound(seedOrder);
        ordered = fr.sequence.map((s) => (s.type === 'game' ? { game: fr.pairs[s.index] } : { bye: s.player }));
      } else {
        const winners = this._roundWinners(number - 1);
        const ps = pairing.pairAdjacent(winners, number);
        ordered = ps.map((p) => ({ game: p }));
      }
    } else { // eliminatória dupla
      const losses = new Map(players.map((p) => [p.id, 0]));
      const hadBye = new Set();
      for (const g of allGames) {
        if (g.state !== 'finished') continue;
        if (g.result === 'bye') hadBye.add(g.white_id);
        else if (g.result === '1-0') losses.set(g.black_id, losses.get(g.black_id) + 1);
        else if (g.result === '0-1') losses.set(g.white_id, losses.get(g.white_id) + 1);
      }
      const bySeed = active.slice().sort((a, b) => a.seed - b.seed);
      const poolW = bySeed.filter((p) => losses.get(p.id) === 0).map((p) => p.id);
      const poolL = bySeed.filter((p) => losses.get(p.id) === 1).map((p) => p.id);
      const last = new Set(allGames.filter((g) => g.round === number - 1 && g.black_id != null).map((g) => `${g.white_id}-${g.black_id}`));
      const res = pairing.doubleElimRound(poolW, poolL, hadBye, last, number);
      pairs = res.pairs; byes = res.byes;
    }

    this.store.run('INSERT INTO rounds(number,status,created_at) VALUES (?,?,?)', [number, 'pending', now()]);
    this.store.run('UPDATE tournament SET current_round=? WHERE id=1', [number]);
    let board = 1;
    const insertGame = (white, black, bracket = null, extra = {}) => {
      // jogador de desistente: partida cancelada automaticamente
      const wp = players.find((p) => p.id === white), bp = black ? players.find((p) => p.id === black) : null;
      const cancelled = (wp && wp.status === 'withdrawn') || (bp && bp.status === 'withdrawn');
      this.store.run(`INSERT INTO games(round,board,white_id,black_id,kind,state,result,reason,bracket,finished_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [number, extra.board ?? board++, white, black, kind, black == null ? 'finished' : cancelled ? 'cancelled' : 'waiting',
          black == null ? 'bye' : null, black == null ? 'bye' : cancelled ? 'desistência' : null, bracket, black == null ? now() : null]);
    };
    if (ordered) {
      ordered.forEach((o) => { if (o.game) insertGame(o.game.white, o.game.black); else insertGame(o.bye, null); });
    } else {
      pairs.forEach((p) => insertGame(p.white, p.black, p.bracket || null));
      byes.forEach((b) => insertGame(b.id, null, b.bracket || null));
    }
    this.store.audit('sistema', 'rodada_gerada', 'rodada', number, { jogos: pairs.length, byes: byes.length });
    return number;
  }

  /** Vencedores de cada confronto (por tabuleiro) da rodada, em ordem de chave. */
  _roundWinners(roundNumber) {
    const games = this.store.all('SELECT * FROM games WHERE round=? ORDER BY board, id', [roundNumber]);
    const byBoard = new Map();
    for (const g of games) { if (!byBoard.has(g.board)) byBoard.set(g.board, []); byBoard.get(g.board).push(g); }
    const winners = [];
    for (const [, list] of [...byBoard.entries()].sort((a, b) => a[0] - b[0])) {
      const decisive = list.filter((g) => g.state === 'finished' && (g.result === 'bye' || g.result === '1-0' || g.result === '0-1')).pop();
      if (!decisive) fail('round_incomplete', 'A rodada anterior ainda tem confrontos sem vencedor.', 409);
      winners.push(decisive.result === '0-1' ? decisive.black_id : decisive.white_id);
    }
    return winners;
  }

  nextRound(actor = 'organizador') {
    const t = this.tournament();
    if (t.status !== 'running') fail('invalid_state', 'O torneio não está em andamento.', 409);
    const rounds = this.rounds();
    const last = rounds[rounds.length - 1];
    if (last && last.status !== 'finished') fail('round_open', 'Finalize a rodada atual antes de gerar a próxima.', 409);
    if (t.rounds_total && t.current_round >= t.rounds_total) fail('no_more_rounds', 'Todas as rodadas já foram disputadas.', 409);
    const n = this.store.tx(() => { const r = this._createRound(); this.store.audit(actor, 'rodada_solicitada', 'rodada', r); return r; });
    this.emit('rounds', {});
    return n;
  }

  /** Edição manual de confrontos: somente antes de a rodada começar. */
  editPairing(gameId, patch, actor = 'organizador') {
    return this.editPairings([{ id: gameId, ...patch }], actor)[0];
  }

  /**
   * Edita vários confrontos de uma vez (permite trocar adversários entre mesas).
   * A consistência (ninguém em duas partidas na mesma rodada) é verificada ao final;
   * se falhar, nada é alterado.
   */
  editPairings(edits, actor = 'organizador') {
    if (!Array.isArray(edits) || !edits.length) fail('invalid', 'Nenhuma edição informada.');
    return this.store.tx(() => {
      const t = this.tournament();
      const rounds = new Set();
      const out = [];
      for (const e of edits) {
        const g = this.game(e.id);
        if (!g) fail('not_found', 'Partida não encontrada.', 404);
        const rd = this.store.get('SELECT * FROM rounds WHERE number=?', [g.round]);
        if (rd.status !== 'pending') fail('locked', 'Só é possível editar confrontos antes do início da rodada.', 409);
        if (g.black_id == null) fail('locked', 'Partidas com bye não podem ser editadas.', 409);
        const w = e.white_id ?? g.white_id, b = e.black_id ?? g.black_id;
        if (w === b) fail('invalid', 'Um jogador não pode enfrentar a si mesmo.');
        for (const id of [w, b]) {
          const p = this.player(id);
          if (!p || p.status !== 'active') fail('invalid', 'Participante inválido ou desistente.');
        }
        const k = e.kind ?? g.kind;
        if (!['presencial', 'online'].includes(k)) fail('invalid', 'Tipo de partida inválido.');
        if (t.modality === 'presencial' && k !== 'presencial') fail('invalid', 'Torneio presencial só aceita partidas presenciais.');
        if (t.modality === 'online' && k !== 'online') fail('invalid', 'Torneio online só aceita partidas online.');
        this.store.run("UPDATE games SET white_id=?, black_id=?, kind=?, state='waiting' WHERE id=?", [w, b, k, g.id]);
        this.store.audit(actor, 'confronto_editado', 'partida', g.id, { de: [g.white_id, g.black_id, g.kind], para: [w, b, k] });
        rounds.add(g.round);
        out.push(g.id);
      }
      for (const r of rounds) {
        const ids = this.store.all('SELECT white_id, black_id FROM games WHERE round=?', [r]).flatMap((x) => [x.white_id, x.black_id]).filter((x) => x != null);
        if (new Set(ids).size !== ids.length) fail('conflict', 'Esse jogador já está em outra partida desta rodada.', 409);
      }
      this.emit('rounds', {});
      return out.map((id) => this.game(id));
    });
  }

  startRound(number = null, actor = 'organizador') {
    return this.store.tx(() => {
      const t = this.tournament();
      const n = number ?? t.current_round;
      const rd = this.store.get('SELECT * FROM rounds WHERE number=?', [n]);
      if (!rd) fail('not_found', 'Rodada não encontrada.', 404);
      if (rd.status !== 'pending') fail('invalid_state', 'Esta rodada já foi iniciada.', 409);
      this.store.run("UPDATE rounds SET status='running', started_at=? WHERE number=?", [now(), n]);
      this._assignTables(n);
      this.store.audit(actor, 'rodada_iniciada', 'rodada', n);
      this.emit('rounds', {});
      return this.store.get('SELECT * FROM rounds WHERE number=?', [n]);
    });
  }

  /** Distribui mesas físicas. Partidas presenciais sem mesa livre ficam aguardando. */
  _assignTables(round) {
    const t = this.tournament();
    const phys = this.store.all("SELECT * FROM games WHERE round=? AND kind='presencial' AND black_id IS NOT NULL AND state IN ('waiting','playing') ORDER BY board", [round]);
    const used = new Set(phys.filter((g) => g.table_no != null).map((g) => g.table_no));
    for (const g of phys) {
      if (g.table_no != null) { if (g.state === 'waiting') this.store.run("UPDATE games SET state='playing', started_at=COALESCE(started_at,?) WHERE id=?", [now(), g.id]); continue; }
      if (t.tables_count > 0) {
        let free = null;
        for (let i = 1; i <= t.tables_count; i++) if (!used.has(i)) { free = i; break; }
        if (free == null) continue;
        used.add(free);
        this.store.run("UPDATE games SET table_no=?, state='playing', started_at=COALESCE(started_at,?) WHERE id=?", [free, now(), g.id]);
      } else {
        this.store.run("UPDATE games SET state='playing', started_at=COALESCE(started_at,?) WHERE id=?", [now(), g.id]);
      }
    }
  }

  setGameState(gameId, state, actor = 'organizador') {
    if (!['waiting', 'postponed', 'cancelled'].includes(state)) fail('invalid', 'Estado inválido.');
    return this.store.tx(() => {
      const g = this.game(gameId);
      if (!g) fail('not_found', 'Partida não encontrada.', 404);
      if (g.state === 'finished') fail('invalid_state', 'A partida já foi finalizada.', 409);
      if (g.black_id == null) fail('invalid_state', 'Partida com bye não pode ser alterada.', 409);
      this.store.run('UPDATE games SET state=?, table_no=NULL WHERE id=?', [state, gameId]);
      this.store.audit(actor, 'estado_partida_' + state, 'partida', gameId, { anterior: g.state });
      const rd = this.store.get('SELECT status FROM rounds WHERE number=?', [g.round]);
      if (rd.status === 'running') this._assignTables(g.round);
      this.emit('rounds', {});
      return this.game(gameId);
    });
  }

  // ------------------------------------------------------------ resultados
  /**
   * Registra resultado. Em partida finalizada, só com correction=true (e justificativa), sempre auditado.
   */
  recordResult(gameId, result, { actor = 'organizador', correction = false, reason = null, endReason = null } = {}) {
    if (!RESULTS.includes(result)) fail('invalid_result', 'Resultado inválido. Use 1-0, 0-1 ou 1/2-1/2.');
    return this.store.tx(() => {
      const t = this.tournament();
      const g = this.game(gameId);
      if (!g) fail('not_found', 'Partida não encontrada.', 404);
      if (g.black_id == null) fail('invalid_state', 'Partida com bye não tem resultado a registrar.', 409);
      if (g.state === 'cancelled') fail('invalid_state', 'A partida foi cancelada.', 409);
      const rd = this.store.get('SELECT * FROM rounds WHERE number=?', [g.round]);
      if (t.status === 'setup') fail('invalid_state', 'O torneio ainda não começou.', 409);
      if (g.state === 'finished') {
        if (g.result === result && !correction) fail('duplicate', 'Esse resultado já foi registrado para esta partida.', 409);
        if (!correction) fail('already_finished', 'A partida já tem resultado. Use a correção autorizada, com justificativa.', 409);
        if (!reason || !String(reason).trim()) fail('reason_required', 'Informe a justificativa da correção.');
        if (g.result === result) fail('duplicate', 'O resultado informado é igual ao atual.', 409);
        if (isElim(t.system)) {
          const later = this.store.get('SELECT 1 x FROM rounds WHERE number>? LIMIT 1', [g.round]);
          if (later) fail('locked', 'Em eliminatórias, só é possível corrigir resultados da rodada mais recente.', 409);
        }
      } else {
        if (correction) fail('invalid_state', 'A partida ainda não tem resultado para corrigir.', 409);
        if (rd.status !== 'running') fail('invalid_state', 'A rodada ainda não foi iniciada.', 409);
      }
      const prevResult = g.result;
      this.store.run("UPDATE games SET state='finished', result=?, reason=?, finished_at=?, turn_started_at=NULL WHERE id=?",
        [result, endReason || (correction ? 'correção' : 'registrado'), now(), gameId]);
      this.store.audit(actor, correction ? 'resultado_corrigido' : 'resultado_registrado', 'partida', gameId,
        { resultado: result, anterior: prevResult, justificativa: reason || null });

      // empate em mata-mata: gera partida de desempate com cores trocadas
      if (isElim(t.system) && result === '1/2-1/2') {
        const board = g.board;
        const pending = this.store.get("SELECT 1 x FROM games WHERE round=? AND board=? AND state IN ('waiting','playing') AND id>?", [g.round, board, g.id]);
        if (!pending) {
          this.store.run(`INSERT INTO games(round,board,white_id,black_id,kind,state,bracket,replay_of) VALUES (?,?,?,?,?,?,?,?)`,
            [g.round, board, g.black_id, g.white_id, g.kind, 'waiting', g.bracket, g.id]);
          this.store.audit('sistema', 'desempate_gerado', 'partida', gameId, { motivo: 'empate em eliminatória' });
        }
      }
      if (rd.status === 'running') this._assignTables(g.round);
      this.emit('result', { gameId });
      return this.game(gameId);
    });
  }

  finishRound(number = null, actor = 'organizador') {
    return this.store.tx(() => {
      const t = this.tournament();
      const n = number ?? t.current_round;
      const rd = this.store.get('SELECT * FROM rounds WHERE number=?', [n]);
      if (!rd) fail('not_found', 'Rodada não encontrada.', 404);
      if (rd.status === 'finished') fail('invalid_state', 'A rodada já foi finalizada.', 409);
      if (rd.status === 'pending') fail('invalid_state', 'A rodada ainda não foi iniciada.', 409);
      const open = this.store.all("SELECT id, state FROM games WHERE round=? AND state NOT IN ('finished','cancelled')", [n]);
      if (open.length) fail('open_games', `Existem ${open.length} partida(s) sem resultado nesta rodada.`, 409);
      if (isElim(t.system)) this._roundWinners(n); // valida que todo confronto tem vencedor
      this.store.run("UPDATE rounds SET status='finished', finished_at=? WHERE number=?", [now(), n]);
      this.store.audit(actor, 'rodada_finalizada', 'rodada', n);
      if (this._isComplete(t, n)) this._finish(actor);
      this.emit('rounds', {});
      return this.store.get('SELECT * FROM rounds WHERE number=?', [n]);
    });
  }

  _isComplete(t, lastRound) {
    if (t.system === 'suico' || t.system === 'round_robin') return lastRound >= t.rounds_total;
    if (t.system === 'eliminatoria_simples') return this._roundWinners(lastRound).length === 1;
    const st = this.standings();
    return st.filter((r) => r.alive).length === 1;
  }

  _finish(actor) {
    this.store.run("UPDATE tournament SET status='finished', finished_at=? WHERE id=1", [now()]);
    this.store.audit(actor, 'torneio_finalizado', 'torneio', 1);
    this.finishedAt = Date.now();
    this.emit('finished', {});
  }

  /** Encerramento antecipado pelo organizador. Partidas abertas viram canceladas. */
  finish(actor = 'organizador') {
    const t = this.tournament();
    if (t.status === 'finished') fail('invalid_state', 'O torneio já foi finalizado.', 409);
    if (t.status !== 'running') fail('invalid_state', 'O torneio ainda não foi iniciado.', 409);
    this.store.tx(() => {
      this.store.run("UPDATE games SET state='cancelled', reason='torneio encerrado', table_no=NULL WHERE state IN ('waiting','playing','postponed')");
      this.store.run("UPDATE rounds SET status='finished', finished_at=COALESCE(finished_at, ?) WHERE status!='finished'", [now()]);
      this._finish(actor);
    });
    return this.tournament();
  }

  // ------------------------------------------------------------ lances e PGN
  /** Anexa lances (SAN) a uma partida presencial já cadastrada. Valida tudo; nunca inventa lances. */
  attachMoves(gameId, sans, actor = 'organizador') {
    if (!Array.isArray(sans) || !sans.length) fail('invalid', 'Nenhum lance informado.');
    return this.store.tx(() => {
      const g = this.game(gameId);
      if (!g) fail('not_found', 'Partida não encontrada.', 404);
      if (g.black_id == null) fail('invalid_state', 'Partida com bye não tem lances.', 409);
      if (g.kind === 'online') fail('invalid_state', 'Partidas online registram os lances automaticamente.', 409);
      if (g.state === 'cancelled') fail('invalid_state', 'A partida foi cancelada.', 409);
      if (this.store.get('SELECT 1 x FROM moves WHERE game_id=? LIMIT 1', [gameId])) fail('has_moves', 'Esta partida já possui lances registrados.', 409);
      const game = new Game();
      const played = [];
      for (const s of sans) {
        const san = game.move(String(s));
        if (!san) fail('illegal_move', `Lance ilegal na posição: "${s}" (após ${played.length} lances).`);
        played.push(san);
      }
      if (game.over && g.state === 'finished' && g.result !== game.result) {
        fail('result_conflict', `Os lances terminam em ${game.result}, mas o resultado registrado é ${g.result}.`, 409);
      }
      const g2 = new Game();
      played.forEach((san, i) => {
        g2.move(san);
        this.store.run('INSERT INTO moves(game_id,ply,san,uci,fen,spent_ms) VALUES (?,?,?,?,?,NULL)', [gameId, i + 1, san, g2.uci[i], g2.fen]);
      });
      this.store.audit(actor, 'lances_anexados', 'partida', gameId, { lances: played.length });
      this.emit('result', { gameId });
      return { plies: played.length, ends: game.over ? game.result : null };
    });
  }

  importPgn(text, actor = 'organizador') {
    const parsed = parsePgn(text);
    if (!parsed.length) fail('invalid_pgn', 'Nenhuma partida encontrada no PGN.');
    const imported = [], errors = [];
    this.store.tx(() => {
      parsed.forEach((p, i) => {
        if (p.error) { errors.push({ index: i + 1, error: p.error }); return; }
        const r = this.store.run('INSERT INTO imported_games(tags,moves,result,start_fen,created_at) VALUES (?,?,?,?,?)',
          [JSON.stringify(p.tags), JSON.stringify(p.moves), p.result, p.fen === START_FEN ? null : p.fen, now()]);
        imported.push(Number(r.lastInsertRowid));
      });
      this.store.audit(actor, 'pgn_importado', 'pgn', null, { importadas: imported.length, erros: errors.length });
    });
    return { imported, errors };
  }

  importedList() {
    return this.store.all('SELECT * FROM imported_games ORDER BY id').map((r) => {
      const tags = JSON.parse(r.tags);
      return { id: r.id, white: tags.White || '?', black: tags.Black || '?', event: tags.Event || '', date: tags.Date || '', result: r.result, plies: JSON.parse(r.moves).length };
    });
  }

  importedGame(id) {
    const r = this.store.get('SELECT * FROM imported_games WHERE id=?', [id]);
    if (!r) fail('not_found', 'Partida importada não encontrada.', 404);
    const moves = JSON.parse(r.moves);
    const g = new Game(r.start_fen || START_FEN);
    const fens = [g.fen];
    for (const m of moves) { g.move(m); fens.push(g.fen); }
    return { id: r.id, tags: JSON.parse(r.tags), moves, fens, result: r.result };
  }

  /** Dados para reprodução de uma partida do torneio. */
  replay(gameId) {
    const g = this.games().find((x) => x.id === gameId);
    if (!g) fail('not_found', 'Partida não encontrada.', 404);
    const ms = this.moves(gameId);
    return { game: g, moves: ms.map((m) => m.san), fens: [START_FEN].concat(ms.map((m) => m.fen)), uci: ms.map((m) => m.uci), hasMoves: ms.length > 0 };
  }

  // ------------------------------------------------------------ partidas online (usado pelo módulo online)
  beginOnlineGame(gameId, whiteMs, blackMs, nowMs, fen) {
    this.store.run("UPDATE games SET state='playing', white_ms=?, black_ms=?, turn_started_at=?, fen=?, started_at=COALESCE(started_at,?) WHERE id=?",
      [whiteMs, blackMs, nowMs, fen, now(), gameId]);
  }

  saveMove(gameId, ply, san, uci, fen, spentMs, whiteMs, blackMs, nowMs) {
    this.store.tx(() => {
      this.store.run('INSERT INTO moves(game_id,ply,san,uci,fen,spent_ms) VALUES (?,?,?,?,?,?)', [gameId, ply, san, uci, fen, spentMs]);
      this.store.run('UPDATE games SET fen=?, white_ms=?, black_ms=?, turn_started_at=? WHERE id=?', [fen, whiteMs, blackMs, nowMs, gameId]);
    });
  }
}

require('./animcodes').install(TournamentService, fail);

module.exports = { TournamentService, TournamentError, sha256, newToken, RESULTS, MODALITIES, SYSTEMS, cleanName };
