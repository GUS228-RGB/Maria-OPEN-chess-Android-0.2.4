'use strict';
/** CLI do open CHESS: host, status, stop, restore, help. */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const readline = require('node:readline/promises');
const { Store, validateBackupFile } = require('../db/db');
const { TournamentService, TournamentError, MODALITIES, SYSTEMS } = require('../core/tournament');
const { OpenChessServer, lanAddresses } = require('../server/app');
const { qrTerminal } = require('../core/qr');
const { startTunnel } = require('./tunnel');
const { TIEBREAK_KEYS } = require('../core/standings');

const VERSION = require('../../package.json').version;
const WEB_DIR = path.join(__dirname, '..', '..', 'web');
const useColor = process.stdout.isTTY && !process.env.NO_COLOR;
const c = (code, s) => (useColor ? `\x1b[${code}m${s}\x1b[0m` : String(s));
const bold = (s) => c('1', s), dim = (s) => c('2', s), green = (s) => c('32', s), red = (s) => c('31', s), yellow = (s) => c('33', s), cyan = (s) => c('36', s);

const MOD_LABEL = { presencial: 'Presencial', online: 'Online', hibrido: 'Híbrido' };
const SYS_LABEL = { suico: 'Sistema Suíço', round_robin: 'Round Robin (todos contra todos)', eliminatoria_simples: 'Eliminatória simples', eliminatoria_dupla: 'Eliminatória dupla' };
const REG_LABEL = { open: 'inscrições abertas', paused: 'inscrições pausadas', closed: 'inscrições encerradas' };
const ST_LABEL = { setup: 'aguardando início', running: 'em andamento', finished: 'finalizado' };
const TB_LABEL = { buchholz: 'Buchholz', buchholz_cut1: 'Buchholz Cut-1', sonneborn_berger: 'Sonneborn-Berger', wins: 'Vitórias', progressive: 'Progressivo', rating: 'Rating Elo' };

const { home, slug, pad, listSaved, newTournamentDir, isTermux } = require('../app/paths');
const stateFile = () => path.join(home(), 'servidor.json');

class CliError extends Error { constructor(msg, code = 1) { super(msg); this.exitCode = code; } }

// ------------------------------------------------------------------ ajuda
const HELP = `${bold('maria open CHESS')} ${dim('v' + VERSION)} — criação e hospedagem de torneios de xadrez

${bold('USO')}
  open-chess <comando> [opções]          ${dim('(no Windows: open-chess.cmd <comando>)')}

${bold('COMANDOS')}
  ${cyan('host')}      Configura (perguntas interativas) e inicia a hospedagem de um torneio.
  ${cyan('status')}    Mostra o estado do torneio que está sendo hospedado neste computador.
  ${cyan('stop')}      Encerra a hospedagem com segurança (salva tudo e gera o TXT, se finalizado).
  ${cyan('app')}       Abre a tela gráfica CRIAR TORNEIO / INICIAR HOSPEDAGEM no navegador deste aparelho
             (é o modo usado no celular/Termux e pelos atalhos de duplo clique).
  ${cyan('restore')}   Restaura um backup do torneio: open-chess restore <arquivo.db> [--pasta <torneio>].
  ${cyan('help')}      Mostra esta ajuda.

${bold('OPÇÕES DO host')}
  --port <n>            Usa exatamente esta porta (erro claro se estiver ocupada).
                        Sem esta opção: usa 8787 ou a próxima porta livre.
  --local               Aceita conexões só deste computador (não abre para a rede).
  --resume [pasta]      Retoma um torneio já salvo (sem perguntas). Sem pasta: escolhe de uma lista.
  --config <arquivo>    Lê a configuração de um arquivo JSON (modo não interativo).
  --name, --description, --max, --modality, --system, --rounds, --time, --inc,
  --win, --draw, --loss, --tables, --tiebreaks    Respondem às perguntas pela linha de comando.
  --yes                 Aceita os padrões nas perguntas que não foram respondidas por opção.

${bold('ACESSO DE OUTRAS REDES (INTERNET)')}
  --tunnel [auto|cloudflared|ssh]   Abre um túnel seguro (HTTPS) e gera uma URL pública que
                        funciona de qualquer rede. Gratuito e sem conta. Usa o programa que
                        existir no computador: cloudflared, ou o ssh (localhost.run).
  --private             Torneio PRIVADO: só entra quem tem o código de acesso (que vai no link/QR de convite).
                        Sem esta opção o torneio é público: quem tem o link entra. (ou --visibility private|public)
  --public-url <url>    Informa o endereço público fixo, quando o servidor está atrás de um proxy/túnel seu
                        (ex.: servidor na nuvem ou túnel nomeado do Cloudflare). Usado nos links de convite.
  --remote-admin        Libera o painel do organizador também pela URL pública
                        (padrão: o painel só abre pelo endereço local do computador).

${bold('PASTA DOS DADOS')}
  ${home()}
  Cada torneio fica em sua própria pasta (banco SQLite, backups, logs e o TXT de resultados).
  Use a variável OPEN_CHESS_HOME para mudar o local.

${bold('REDE')}
  O endereço de IP (ex.: http://192.168.0.10:8787/) é LOCAL: só funciona para quem estiver na
  MESMA rede Wi-Fi/Ethernet. Para jogadores em OUTRAS redes, use --tunnel (ou responda "sim" à
  pergunta de acesso pela internet): será mostrada uma URL pública https://... e o QR Code dela.
  Se um dispositivo da mesma rede não abrir o endereço local, libere a porta no firewall.
`;

// ------------------------------------------------------------------ argumentos
function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const eq = a.indexOf('=');
      const key = (eq > 0 ? a.slice(2, eq) : a.slice(2));
      if (eq > 0) out[key] = a.slice(eq + 1);
      else if (argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) out[key] = argv[++i];
      else out[key] = true;
    } else out._.push(a);
  }
  return out;
}

const num = (s) => Number(String(s).trim().replace(',', '.'));

// ------------------------------------------------------------------ perguntas interativas
class Prompter {
  constructor(auto) {
    this.auto = auto;
    this.rl = auto ? null : readline.createInterface({ input: process.stdin, output: process.stdout });
  }
  async ask(question, def = '') {
    if (this.auto) return def === undefined ? '' : String(def);
    const suffix = def !== '' && def !== undefined ? dim(` [${def}]`) : '';
    const ans = (await this.rl.question(`${question}${suffix}: `)).trim();
    return ans === '' ? String(def ?? '') : ans;
  }
  async required(question, validate = null) {
    for (;;) {
      const v = await this.ask(question, '');
      if (v && (!validate || validate(v))) return v;
      if (this.auto) throw new CliError(`Informe ${question.toLowerCase()} (use as opções ou --config).`);
      console.log(red('  Valor obrigatório ou inválido, tente de novo.'));
    }
  }
  async number(question, def, { min, max, integer = false } = {}) {
    for (;;) {
      const v = num(await this.ask(question, def === null ? '' : String(def).replace('.', ',')));
      if (Number.isFinite(v) && (min === undefined || v >= min) && (max === undefined || v <= max) && (!integer || Number.isInteger(v))) return v;
      if (this.auto) throw new CliError(`Valor inválido para: ${question}`);
      console.log(red(`  Digite um número${integer ? ' inteiro' : ''}${min !== undefined ? ` entre ${min} e ${max}` : ''}.`));
    }
  }
  async choice(question, options, defIdx = 0) {
    if (!this.auto) {
      console.log(question);
      options.forEach((o, i) => console.log(`  ${cyan(i + 1)}) ${o.label}`));
    }
    for (;;) {
      const v = await this.ask('Escolha', String(defIdx + 1));
      const i = Number(v) - 1;
      if (Number.isInteger(i) && options[i]) return options[i].value;
      if (this.auto) throw new CliError('Opção inválida.');
      console.log(red('  Opção inválida.'));
    }
  }
  close() { if (this.rl) this.rl.close(); }
}

/** Monta a configuração do torneio a partir de --config, opções e perguntas. */
async function gatherConfig(args) {
  let base = {};
  if (args.config) {
    try { base = JSON.parse(fs.readFileSync(args.config, 'utf8')); }
    catch (e) { throw new CliError(`Não foi possível ler o arquivo de configuração: ${e.message}`); }
  }
  const noAsk = !!(args.config || args.yes) || !process.stdin.isTTY;
  const pr = new Prompter(noAsk);
  const pick = (k, alt) => (args[alt ?? k] !== undefined && args[alt ?? k] !== true ? args[alt ?? k] : base[k]);
  try {
    if (!noAsk) console.log(`\n${bold('Novo torneio')} ${dim('— responda às perguntas (Enter aceita o valor entre colchetes)')}\n`);
    const cfg = {};
    cfg.name = pick('name') ?? await pr.required('1. Nome do torneio');
    cfg.description = pick('description') ?? await pr.ask('2. Descrição (opcional)', '');
    cfg.max_players = pick('max_players', 'max') !== undefined ? num(pick('max_players', 'max')) : await pr.number('3. Quantidade máxima de participantes', 16, { min: 2, max: 512, integer: true });
    cfg.modality = pick('modality') ?? await pr.choice('4. Modalidade:', [
      { label: 'Presencial — partidas em tabuleiros reais, resultados lançados pelo organizador', value: 'presencial' },
      { label: 'Online — partidas jogadas no navegador, com relógio', value: 'online' },
      { label: 'Híbrida — presencial e online no mesmo torneio', value: 'hibrido' }], 0);
    if (!MODALITIES.includes(cfg.modality)) throw new CliError(`Modalidade inválida: ${cfg.modality}. Use: ${MODALITIES.join(', ')}.`);
    cfg.system = pick('system') ?? await pr.choice('5. Sistema de disputa:', SYSTEMS.map((s) => ({ label: SYS_LABEL[s], value: s })), 0);
    if (!SYSTEMS.includes(cfg.system)) throw new CliError(`Sistema inválido: ${cfg.system}. Use: ${SYSTEMS.join(', ')}.`);
    if (cfg.system === 'suico') {
      const r = pick('rounds_total', 'rounds');
      cfg.rounds_total = r !== undefined ? num(r) : await pr.number('6. Quantidade de rodadas (0 = automático pelo nº de jogadores)', 0, { min: 0, max: 99, integer: true }) || null;
    } else if (cfg.system === 'round_robin') {
      if (base.rr_double !== undefined) cfg.rr_double = !!base.rr_double;
      else cfg.rr_double = (await pr.choice('6. Turnos:', [{ label: 'Turno único (cada par se enfrenta 1 vez)', value: false }, { label: 'Turno e returno (2 vezes)', value: true }], 0));
    } else if (!noAsk) console.log(dim('6. Rodadas: definidas automaticamente pelo sistema de eliminatória.'));
    if (cfg.modality !== 'presencial') {
      cfg.time_base_s = pick('time_base_s', 'time') !== undefined ? Math.round(num(pick('time_base_s', 'time')) * (args.time !== undefined ? 60 : 1)) : Math.round(await pr.number('7. Controle de tempo — minutos por jogador', 10, { min: 1, max: 1440 }) * 60);
      cfg.time_inc_s = pick('time_inc_s', 'inc') !== undefined ? num(pick('time_inc_s', 'inc')) : await pr.number('   Incremento por lance, em segundos', 0, { min: 0, max: 3600, integer: true });
    } else if (!noAsk) console.log(dim('7. Controle de tempo: não se aplica a torneios presenciais.'));
    cfg.pts_win = pick('pts_win', 'win') !== undefined ? num(pick('pts_win', 'win')) : await pr.number('8. Pontos por vitória', 1, { min: 0, max: 100 });
    cfg.pts_draw = pick('pts_draw', 'draw') !== undefined ? num(pick('pts_draw', 'draw')) : await pr.number('   Pontos por empate', 0.5, { min: 0, max: 100 });
    cfg.pts_loss = pick('pts_loss', 'loss') !== undefined ? num(pick('pts_loss', 'loss')) : await pr.number('   Pontos por derrota', 0, { min: 0, max: 100 });
    if (cfg.modality !== 'online') {
      cfg.tables_count = pick('tables_count', 'tables') !== undefined ? num(pick('tables_count', 'tables')) : await pr.number('9. Quantidade de mesas físicas (0 = sem limite)', 0, { min: 0, max: 500, integer: true });
    } else if (!noAsk) console.log(dim('9. Mesas físicas: não se aplica a torneios online.'));
    const vis = args.private === true || args.private === 'true' ? 'private' : pick('visibility');
    if (vis !== undefined) {
      if (!['public', 'private'].includes(vis)) throw new CliError('Visibilidade inválida. Use --visibility public ou --visibility private.');
      cfg.visibility = vis;
    }
    const tb = pick('tiebreaks');
    if (tb !== undefined) cfg.tiebreaks = Array.isArray(tb) ? tb : String(tb).split(',').map((x) => x.trim()).filter(Boolean);
    else if (!noAsk) {
      console.log(`10. Configurações adicionais — critérios de desempate, em ordem: ${TIEBREAK_KEYS.map((k) => TB_LABEL[k] || k).join(', ')}`);
      const a = await pr.ask('    Ordem desejada (nomes separados por vírgula) ou Enter para o padrão (Buchholz, Sonneborn-Berger, Vitórias)', '');
      if (a) {
        const map = Object.fromEntries(TIEBREAK_KEYS.map((k) => [(TB_LABEL[k] || k).toLowerCase(), k]));
        cfg.tiebreaks = a.split(',').map((x) => x.trim().toLowerCase()).map((x) => map[x] || x);
      }
    }
    const port = args.port !== undefined && args.port !== true ? Number(args.port) : (base.port || (noAsk ? 8787 : await pr.number('    Porta do servidor', 8787, { min: 1, max: 65535, integer: true })));
    TournamentService.normalizeConfig(cfg); // valida cedo, com mensagens em português
    return { cfg, port };
  } finally { pr.close(); }
}

// ------------------------------------------------------------------ torneios salvos
// ------------------------------------------------------------------ estado do servidor em execução
function readState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), 'utf8')); } catch (_) { return null; }
}
function alive(pid) { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } }
function liveState() {
  const st = readState();
  if (!st) return null;
  if (!alive(st.pid)) { try { fs.rmSync(stateFile(), { force: true }); } catch (_) { /* ok */ } return null; }
  return st;
}
async function control(st, route, method = 'GET') {
  const r = await fetch(`http://127.0.0.1:${st.port}/api/control/${route}`, { method, headers: { 'X-Control-Token': st.controlToken }, signal: AbortSignal.timeout(4000) });
  if (!r.ok) throw new CliError(`O servidor respondeu com erro ${r.status}.`);
  return r.json();
}

// ------------------------------------------------------------------ exibição
function statusLines(s, { qr = false, adminUrl = null, adminKey = null, firewall = false, tunnelError = null } = {}) {
  const L = [];
  const primary = s.public_url || (s.urls.lan[0] ? s.urls.lan[0].url : s.urls.local);
  L.push(`${bold('maria open CHESS')}  ${dim('v' + VERSION)}`);
  L.push('');
  L.push(`${bold('Torneio:')} ${s.name}`);
  L.push(`${bold('Modalidade:')} ${MOD_LABEL[s.modality]}   ${bold('Sistema:')} ${SYS_LABEL[s.system]}`);
  L.push(`${bold('Estado do servidor:')} ${s.state === 'ativo' ? green('● ATIVO') : red('● PARADO')}   ${dim('(há ' + fmtUp(s.uptime_s) + ')')}   ${bold('Torneio:')} ${ST_LABEL[s.status]}, ${REG_LABEL[s.registration]}`);
  L.push('');
  L.push(`${bold('Porta:')} ${s.port}`);
  if (s.public_url) {
    L.push(`${bold('URL pública (qualquer rede):')} ${cyan(s.public_url)}  ${green('● túnel ativo')}`);
    L.push(dim('  Quem tiver este link pode abrir a página e se inscrever enquanto houver vagas. O painel do organizador '
      + (s.remote_admin ? 'ESTÁ' : 'não está') + ' liberado pela internet.'));
  } else if (tunnelError) L.push(`${bold('URL pública:')} ${red('indisponível')} ${dim('— ' + tunnelError.split('\n')[0])}`);
  if (s.urls.lan.length) {
    s.urls.lan.forEach((a, i) => L.push(`${i === 0 ? bold(s.public_url ? 'URL na rede local:' : 'URL de acesso:') : '              '} ${cyan(a.url)}  ${dim('IP ' + a.address + ' (' + a.interface + ')')}`));
  } else {
    L.push(`${bold('URL de acesso:')} ${cyan(s.urls.local)}  ${yellow('— nenhuma rede detectada; conecte-se a um Wi-Fi/Ethernet para outros dispositivos entrarem')}`);
  }
  if (s.invite && s.invite.visibility === 'private') L.push(`${bold('Torneio PRIVADO.')} Código de acesso: ${yellow(s.invite.access_code_display)}  ${dim('(já vai dentro do link e do QR Code de convite)')}`);
  else if (s.invite) L.push(`${bold('Torneio público.')} ${dim('Quem tiver o link entra. Para exigir código de acesso, use o painel (Convites e acesso) ou --private ao criar.')}`);
  if (qr) { L.push(''); L.push(...qrTerminal(s.invite && s.invite.links[0] && s.invite.visibility === 'private' ? s.invite.links[0].url : primary).split('\n').map((l) => '  ' + l)); L.push(dim('  Aponte a câmera do celular para o QR Code (mesma rede Wi-Fi).')); }
  L.push('');
  if (adminUrl) {
    L.push(`${bold('Painel do organizador:')} ${cyan(adminUrl)}`);
    L.push(`${bold('Chave do organizador:')} ${yellow(adminKey)}  ${dim('(não compartilhe; use apenas você)')}`);
    L.push('');
  }
  L.push(`${bold('Participantes:')} ${s.players}/${s.max_players}  ${dim('vagas ocupadas')}   ${bold('Vagas restantes:')} ${s.full ? red('0 (lotado)') : green(s.slots_left)}   ${bold('Conectados agora:')} ${s.connected}`);
  L.push(`${bold('Rodada atual:')} ${s.current_round ? `${s.current_round}${s.rounds_total ? '/' + s.rounds_total : ''}` : '—'}   ${bold('Partidas em andamento:')} ${s.games_playing}   ${bold('Aguardando:')} ${s.games_waiting}   ${bold('Resultados registrados:')} ${s.results_recorded}`);
  L.push(`${bold('Pasta do torneio:')} ${s.dir}`);
  if (firewall) {
    L.push('');
    L.push(dim('IP local só funciona na mesma rede. Se outro dispositivo não conseguir abrir o endereço, libere a porta no firewall:'));
    L.push(dim(process.platform === 'win32'
      ? `  netsh advfirewall firewall add rule name="maria open CHESS" dir=in action=allow protocol=TCP localport=${s.port}   (como administrador)`
      : `  sudo ufw allow ${s.port}/tcp     ${dim('(Ubuntu/Mint com ufw ativo)')}`));
  }
  return L;
}
function fmtUp(s) { const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return h ? `${h}h${pad(m)}min` : m ? `${m}min` : `${s}s`; }

// ------------------------------------------------------------------ comandos
async function cmdHost(args) {
  const running = liveState();
  if (running) throw new CliError(`Já existe um torneio sendo hospedado (porta ${running.port}). Use "open-chess status" para ver ou "open-chess stop" para encerrar.`);
  fs.mkdirSync(home(), { recursive: true });
  let dir, port, resumed = false;

  const saved = listSaved();
  let resume = args.resume;
  if (resume === undefined && saved.length && process.stdin.isTTY && !args.config && !args.name && !args.yes) {
    const open = saved.filter((t) => t.status !== 'finished');
    if (open.length) {
      const pr = new Prompter(false);
      try {
        const choice = await pr.choice(`${bold('Há torneios salvos.')} O que deseja fazer?`, [
          { label: 'Criar um novo torneio', value: null },
          ...open.slice(0, 8).map((t) => ({ label: `Retomar "${t.name}" (${ST_LABEL[t.status]}, ${t.players} participantes)`, value: t.dir })),
        ], 0);
        if (choice) resume = choice;
      } finally { pr.close(); }
    }
  }
  if (resume !== undefined) {
    if (resume === true) {
      if (!saved.length) throw new CliError('Não há torneios salvos para retomar.');
      resume = saved[0].dir;
      console.log(`Retomando o torneio mais recente: ${saved[0].name}`);
    }
    dir = fs.existsSync(path.join(String(resume), 'torneio.db')) ? path.resolve(String(resume)) : (saved.find((t) => path.basename(t.dir) === resume || t.name === resume) || {}).dir;
    if (!dir) throw new CliError(`Torneio não encontrado: ${resume}`);
    resumed = true;
    port = args.port ? Number(args.port) : 8787;
  } else {
    const g = await gatherConfig(args);
    port = g.port;
    dir = newTournamentDir(g.cfg.name);
    const store = new Store(path.join(dir, 'torneio.db'));
    try { TournamentService.create(store, g.cfg); } finally { store.close(); }
  }
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new CliError('Porta inválida (use um número de 1 a 65535).');

  // Acesso de outras redes (túnel)
  let tunnelMode = args.tunnel === true ? 'auto' : (typeof args.tunnel === 'string' ? args.tunnel : null);
  if (tunnelMode === null && args.tunnel === undefined && process.stdin.isTTY && !args.config && !args.yes && !args.name) {
    const pr = new Prompter(false);
    try {
      tunnelMode = await pr.choice('\nQuem vai participar?', [
        { label: 'Somente quem está na mesma rede Wi-Fi/Ethernet (rede local)', value: null },
        { label: 'Também pessoas em OUTRAS redes, pela internet (abre um túnel seguro gratuito)', value: 'auto' }], 0);
    } finally { pr.close(); }
  }

  const recent = [];
  const srv = new OpenChessServer({ dir, webDir: WEB_DIR, log: (l) => { recent.push(l); if (recent.length > 6) recent.shift(); if (!process.stdout.isTTY) console.log(l); } });
  srv.controlToken = crypto.randomBytes(16).toString('hex');
  try {
    await srv.listen({ port, host: args.local ? '127.0.0.1' : '0.0.0.0', autoPort: args.port === undefined });
  } catch (e) {
    srv.store.close();
    throw new CliError(`${e.message}`);
  }
  if (args.port !== undefined && srv.port !== port) console.log(yellow(`Porta ${port} indisponível; usando ${srv.port}.`));

  srv.remoteAdmin = !!args['remote-admin'];
  if (typeof args['public-url'] === 'string') {
    if (!/^https?:\/\/[^\s/]+/i.test(args['public-url'])) throw new CliError('--public-url deve começar com http:// ou https://');
    srv.publicUrl = args['public-url'].replace(/\/+$/, '') + '/';
  }
  let tunnel = null, tunnelError = null, tunnelTries = 0;
  const openTunnel = async () => {
    try {
      tunnel = await startTunnel({ port: srv.port, provider: tunnelMode, log: (l) => { if (l) srv.log('tunel', l.slice(0, 160)); } });
      srv.publicUrl = tunnel.url; tunnelError = null;
      srv.log('info', `Túnel ativo (${tunnel.label}): ${tunnel.url}`);
      tunnel.onDown(async () => {
        srv.publicUrl = null; tunnel = null;
        srv.log('aviso', 'O túnel caiu.');
        if (!stopping && tunnelTries++ < 3) { await new Promise((r) => setTimeout(r, 3000)); if (!stopping) await openTunnel(); if (srv.publicUrl) srv.log('aviso', 'Túnel reaberto: a URL pública MUDOU, compartilhe o novo endereço/QR.'); }
        else if (!stopping) tunnelError = 'O túnel caiu e não pôde ser reaberto.';
      });
    } catch (e) { tunnelError = e.message; srv.log('erro', 'Túnel: ' + e.message.split('\n')[0]); }
  };
  if (tunnelMode) {
    console.log(dim(`Abrindo túnel para acesso de outras redes (até 45 s)...`));
    await openTunnel();
    if (tunnelError) console.log(yellow('\nNão foi possível abrir o acesso pela internet:\n') + tunnelError + yellow('\nO torneio continua disponível na rede local.\n'));
  }

  fs.writeFileSync(stateFile(), JSON.stringify({ pid: process.pid, port: srv.port, controlToken: srv.controlToken, dir, startedAt: new Date().toISOString() }), { mode: 0o600 });
  const adminUrl = `http://localhost:${srv.port}/admin#k=${srv.adminKey}`;
  let stopping = false;
  const stop = async (why = '') => {
    if (stopping) return; stopping = true;
    clearInterval(timer);
    if (process.stdin.isTTY) { try { process.stdin.setRawMode(false); } catch (_) { /* ok */ } }
    console.log(`\n${yellow('Encerrando o servidor e salvando os dados...')}${why ? ' ' + dim(why) : ''}`);
    if (tunnel) tunnel.stop();
    try { await srv.close(); } catch (e) { console.error(red('Erro ao encerrar: ' + e.message)); }
    try { fs.rmSync(stateFile(), { force: true }); } catch (_) { /* ok */ }
    console.log(green('Servidor encerrado. Todos os dados foram salvos em:'), dir);
    process.exit(0);
  };
  srv.requestStop = () => stop('(pedido pelo comando stop)');
  process.on('SIGINT', () => stop()); process.on('SIGTERM', () => stop());
  if (process.platform === 'win32') process.on('SIGBREAK', () => stop());

  const draw = (first = false) => {
    const lines = statusLines(srv.getStatus(), { qr: true, adminUrl, adminKey: srv.adminKey, firewall: !srv.publicUrl, tunnelError });
    if (resumed && first) lines.splice(2, 0, green('Torneio retomado a partir dos dados salvos.'));
    lines.push('', dim('Pressione q ou Ctrl+C para encerrar.'));
    if (recent.length && process.stdout.isTTY) { lines.push('', bold('Registro de atividade:'), ...recent.slice(-5).map((l) => dim('  ' + l.replace(/^\S+\s/, '')))); }
    if (process.stdout.isTTY) process.stdout.write('\x1b[H' + lines.map((l) => l + '\x1b[K').join('\n') + '\n\x1b[J');
    else if (first) console.log(lines.join('\n'));
  };
  if (process.stdout.isTTY) process.stdout.write('\x1b[2J');
  draw(true);
  const timer = setInterval(() => draw(false), 2000);
  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true); process.stdin.resume();
    process.stdin.on('data', (b) => { const k = b.toString(); if (k === 'q' || k === 'Q' || k === '\x03') stop(); });
  }
}

async function cmdApp(args) {
  const { Launcher } = require('../app/launcher');
  const running = liveState();
  if (running) throw new CliError(`Já existe um torneio sendo hospedado (porta ${running.port}). Use "open-chess stop" antes.`);
  fs.mkdirSync(home(), { recursive: true });
  const L = new Launcher({ webDir: WEB_DIR, log: (l) => { if (!process.stdout.isTTY) console.log(l); } });
  const port = await L.listen(args.port ? Number(args.port) : 8780);
  const url = L.url();
  console.log(`${bold('maria open CHESS')} ${dim('v' + VERSION)}\n`);
  console.log(`Tela do aplicativo: ${cyan(url)}`);
  console.log(dim('Abra o endereço acima no navegador DESTE aparelho para criar e hospedar o torneio.'));
  console.log(dim('Mantenha esta janela aberta durante o torneio. Ctrl+C encerra tudo e salva os dados.\n'));
  // Android/Termux: evita que o sistema suspenda o servidor com a tela apagada
  if (isTermux()) {
    const { spawn } = require('node:child_process');
    for (const [cmd, a] of [['termux-wake-lock', []], ['termux-notification', ['--id', 'open-chess', '--ongoing', '--title', 'maria open CHESS', '--content', 'Servidor do torneio ativo — toque para abrir', '--action', `termux-open-url ${url}`]]]) {
      try { spawn(cmd, a, { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch (_) { /* Termux:API opcional */ }
    }
  }
  if (!args['no-open']) {
    const { spawn } = require('node:child_process');
    const opener = isTermux() ? ['termux-open-url', [url]] : process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
    try { spawn(opener[0], opener[1], { stdio: 'ignore', detached: true }).on('error', () => {}).unref(); } catch (_) { /* abre manualmente */ }
  }
  let closing = false;
  const bye = async () => {
    if (closing) return; closing = true;
    console.log(yellow('\nEncerrando e salvando os dados...'));
    if (isTermux()) { const { spawn } = require('node:child_process'); for (const [c, a] of [['termux-wake-unlock', []], ['termux-notification-remove', ['open-chess']]]) { try { spawn(c, a, { stdio: 'ignore' }).on('error', () => {}); } catch (_) { /* ok */ } } }
    try { await L.close(); } catch (_) { /* ok */ }
    process.exit(0);
  };
  process.on('SIGINT', bye); process.on('SIGTERM', bye);
  void port;
}

async function cmdStatus() {
  const st = liveState();
  if (!st) { console.log('Nenhum torneio está sendo hospedado neste computador.'); console.log(dim('Use "open-chess host" para criar e iniciar um.')); return 1; }
  let s;
  try { s = await control(st, 'status'); }
  catch (e) { throw new CliError(`O processo ${st.pid} existe, mas não respondeu na porta ${st.port}: ${e.message}`); }
  console.log(statusLines(s, { firewall: false }).join('\n'));
  return 0;
}

async function cmdStop() {
  const st = liveState();
  if (!st) { console.log('Nenhum torneio está sendo hospedado neste computador.'); return 1; }
  try { await control(st, 'stop', 'POST'); } catch (_) { try { process.kill(st.pid, 'SIGTERM'); } catch (e) { throw new CliError('Não foi possível encerrar o processo: ' + e.message); } }
  for (let i = 0; i < 60; i++) { if (!alive(st.pid)) break; await new Promise((r) => setTimeout(r, 200)); }
  if (alive(st.pid)) throw new CliError(`O servidor (PID ${st.pid}) ainda não encerrou. Tente novamente em instantes.`);
  try { fs.rmSync(stateFile(), { force: true }); } catch (_) { /* ok */ }
  console.log(green('Torneio encerrado. Os dados continuam salvos em:'), st.dir);
  return 0;
}

async function cmdRestore(args) {
  if (liveState()) throw new CliError('Encerre a hospedagem (open-chess stop) antes de restaurar um backup.');
  const file = args._[1];
  if (!file) throw new CliError('Informe o arquivo de backup: open-chess restore <arquivo.db> [--pasta <torneio>]');
  if (!fs.existsSync(file)) throw new CliError(`Arquivo não encontrado: ${file}`);
  try { validateBackupFile(file); } catch (e) { throw new CliError('Backup inválido: ' + e.message); }
  let dir = args.pasta ? path.resolve(String(args.pasta)) : null;
  if (!dir) {
    const bk = path.dirname(path.resolve(file));
    dir = path.basename(bk) === 'backups' ? path.dirname(bk) : null;
  }
  if (!dir) throw new CliError('Informe a pasta do torneio com --pasta <caminho>.');
  const db = path.join(dir, 'torneio.db');
  fs.mkdirSync(dir, { recursive: true });
  if (fs.existsSync(db)) {
    const keep = path.join(dir, 'backups', `torneio-antes-da-restauracao-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);
    fs.mkdirSync(path.dirname(keep), { recursive: true });
    const s = new Store(db);
    try { await s.backupTo(keep); } finally { s.close(); }
    console.log(dim('Cópia do estado atual guardada em ' + keep));
  }
  for (const ext of ['-wal', '-shm']) fs.rmSync(db + ext, { force: true });
  fs.copyFileSync(file, db);
  const s = new Store(db);
  try { const r = s.integrityCheck(); if (!r.ok) throw new CliError('Integridade do banco restaurado falhou: ' + r.integrity); const t = s.get('SELECT name FROM tournament WHERE id=1'); console.log(green(`Backup restaurado: "${t.name}".`)); }
  finally { s.close(); }
  console.log(`Para retomar: open-chess host --resume "${dir}"`);
  return 0;
}

async function main(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  const cmd = args._[0];
  try {
    if (!cmd || cmd === 'help' || args.help || args.h || cmd === '--help') { console.log(HELP); return cmd || args.help ? 0 : 0; }
    if (cmd === 'version' || args.version) { console.log(VERSION); return 0; }
    if (cmd === 'host') { await cmdHost(args); return null; } // segue rodando até parar
    if (cmd === 'app') { await cmdApp(args); return null; }
    if (cmd === 'status') return await cmdStatus();
    if (cmd === 'stop') return await cmdStop();
    if (cmd === 'restore') return await cmdRestore(args);
    console.error(red(`Comando desconhecido: "${cmd}".`));
    console.error('Comandos disponíveis: host, app, status, stop, restore, help.');
    return 2;
  } catch (e) {
    if (e instanceof CliError) { console.error(red('Erro: ') + e.message); return e.exitCode; }
    if (e instanceof TournamentError) { console.error(red('Erro: ') + e.message); return 1; }
    console.error(red('Erro inesperado: ') + (e && e.stack || e));
    return 1;
  }
}

module.exports = { main, parseArgs, statusLines, listSaved, HELP };
