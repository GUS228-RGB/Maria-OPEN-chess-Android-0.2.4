'use strict';
/** Uma sessão de hospedagem (servidor + túnel opcional), usada pelo modo app. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Store } = require('../db/db');
const { TournamentService } = require('../core/tournament');
const { OpenChessServer } = require('../server/app');
const { startTunnel } = require('../cli/tunnel');
const { home, newTournamentDir } = require('./paths');

class HostSession {
  constructor({ webDir, log = null }) {
    this.webDir = webDir;
    this.logSink = log;
    this.srv = null;
    this.tunnel = null;
    this.tunnelError = null;
    this.tunnelMode = null;
    this.tunnelTries = 0;
    this.stopping = false;
    this.starting = false;
    this.recent = [];
  }

  get active() { return !!this.srv; }

  /**
   * @param {{cfg?:object, resumeDir?:string, port?:number, tunnel?:string|null, remoteAdmin?:boolean, localOnly?:boolean}} o
   */
  async start({ cfg = null, resumeDir = null, port = 8787, tunnel = null, remoteAdmin = false, localOnly = false }) {
    if (this.srv || this.starting) throw new Error('Já existe um torneio sendo hospedado. Encerre a hospedagem antes de iniciar outro.');
    this.starting = true;
    let created = null;
    try {
      let dir = resumeDir;
      if (!dir) {
        dir = newTournamentDir(cfg.name);
        const store = new Store(path.join(dir, 'torneio.db'));
        try { TournamentService.create(store, cfg); } finally { store.close(); }
        created = dir;
      }
      const srv = new OpenChessServer({ dir, webDir: this.webDir, log: (l) => { this.recent.push(l); if (this.recent.length > 20) this.recent.shift(); if (this.logSink) this.logSink(l); } });
      srv.controlToken = crypto.randomBytes(16).toString('hex');
      try { await srv.listen({ port, host: localOnly ? '127.0.0.1' : '0.0.0.0', autoPort: true }); }
      catch (e) { srv.store.close(); throw e; }
      srv.remoteAdmin = !!remoteAdmin;
      srv.requestStop = () => { this.stop().catch(() => {}); };
      this.srv = srv; this.dir = dir; this.stopping = false; this.tunnelMode = tunnel; this.tunnelTries = 0; this.tunnelError = null;
      try { fs.writeFileSync(path.join(home(), 'servidor.json'), JSON.stringify({ pid: process.pid, port: srv.port, controlToken: srv.controlToken, dir, startedAt: new Date().toISOString() }), { mode: 0o600 }); } catch (_) { /* só afeta o comando status */ }
      if (tunnel) await this._openTunnel();
      return this.info();
    } catch (e) {
      if (created && !this.srv) { try { fs.rmSync(created, { recursive: true, force: true }); } catch (_) { /* ok */ } }
      throw e;
    } finally { this.starting = false; }
  }

  async _openTunnel() {
    const srv = this.srv;
    try {
      const t = await startTunnel({ port: srv.port, provider: this.tunnelMode === true ? 'auto' : this.tunnelMode, log: (l) => { if (l) srv.log('tunel', l.slice(0, 160)); } });
      if (this.stopping || this.srv !== srv) { t.stop(); return; }
      this.tunnel = t; srv.publicUrl = t.url; this.tunnelError = null;
      srv.log('info', `Túnel ativo (${t.label}): ${t.url}`);
      t.onDown(async () => {
        srv.publicUrl = null; this.tunnel = null;
        srv.log('aviso', 'O túnel caiu.');
        if (!this.stopping && this.tunnelTries++ < 3) {
          await new Promise((r) => setTimeout(r, 3000));
          if (!this.stopping) { await this._openTunnel(); if (srv.publicUrl) srv.log('aviso', 'Túnel reaberto: a URL pública MUDOU, compartilhe o novo endereço/QR.'); }
        } else if (!this.stopping) this.tunnelError = 'O túnel caiu e não pôde ser reaberto.';
      });
    } catch (e) { this.tunnelError = e.message; srv.log('erro', 'Túnel: ' + e.message.split('\n')[0]); }
  }

  info() {
    if (!this.srv) return null;
    const s = this.srv.getStatus();
    return { ...s, dir: this.dir, admin_url: `http://localhost:${this.srv.port}/admin#k=${this.srv.adminKey}`, admin_key: this.srv.adminKey, tunnel_error: this.tunnelError, tunnel_requested: !!this.tunnelMode, log: this.recent.slice(-6) };
  }

  async stop() {
    const srv = this.srv;
    if (!srv) return;
    this.stopping = true;
    if (this.tunnel) { this.tunnel.stop(); this.tunnel = null; }
    this.srv = null;
    try { await srv.close(); } finally {
      try { fs.rmSync(path.join(home(), 'servidor.json'), { force: true }); } catch (_) { /* ok */ }
    }
  }
}

module.exports = { HostSession };
