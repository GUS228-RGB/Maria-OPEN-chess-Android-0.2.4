'use strict';
/** Pastas e lista de torneios salvos, compartilhadas pelo CLI e pelo modo app. */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Store } = require('../db/db');

const home = () => process.env.OPEN_CHESS_HOME || path.join(os.homedir(), 'open-chess');
const ACCENTS = { á: 'a', à: 'a', â: 'a', ã: 'a', ä: 'a', é: 'e', è: 'e', ê: 'e', ë: 'e', í: 'i', ì: 'i', î: 'i', ï: 'i', ó: 'o', ò: 'o', ô: 'o', õ: 'o', ö: 'o', ú: 'u', ù: 'u', û: 'u', ü: 'u', ç: 'c', ñ: 'n' };
// Sem normalize(): o Node do Android é compilado sem ICU, onde normalize() não remove acentos.
const deaccent = (s) => String(s).replace(/[À-ÿ]/g, (c) => { const l = c.toLowerCase(); const b = ACCENTS[l] || c; return c === l ? b : b.toUpperCase(); });
const slug = (s) => deaccent(s).replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_').slice(0, 50) || 'torneio';
const pad = (n) => String(n).padStart(2, '0');

function listSaved() {
  const root = path.join(home(), 'torneios');
  if (!fs.existsSync(root)) return [];
  const out = [];
  for (const d of fs.readdirSync(root)) {
    const dir = path.join(root, d);
    const db = path.join(dir, 'torneio.db');
    if (!fs.existsSync(db)) continue;
    try {
      const s = new Store(db);
      try { const t = s.get('SELECT name,status,modality,created_at FROM tournament WHERE id=1'); const n = s.get('SELECT COUNT(*) c FROM players').c; if (t) out.push({ dir, ...t, players: n }); }
      finally { s.close(); }
    } catch (_) { /* pasta inválida: ignora */ }
  }
  return out.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
}

function newTournamentDir(name) {
  const d = new Date();
  const base = `${slug(name)}_${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}`;
  const root = path.join(home(), 'torneios');
  let dir = path.join(root, base), i = 2;
  while (fs.existsSync(dir)) dir = path.join(root, `${base}-${i++}`);
  return dir;
}

/** Rodando dentro do aplicativo Android (Node embutido)? */
const isAndroidApp = () => process.env.OPEN_CHESS_ANDROID === '1';

/** Estamos rodando dentro do Termux (Android)? */
const isTermux = () => !!process.env.TERMUX_VERSION || /com\.termux/.test(process.env.PREFIX || '');

module.exports = { home, slug, pad, listSaved, newTournamentDir, isTermux, isAndroidApp };
