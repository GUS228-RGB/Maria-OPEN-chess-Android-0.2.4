'use strict';
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_MESSAGE = 64 * 1024;

/** Conexão WebSocket (RFC 6455): texto, ping/pong, fechamento e mensagens fragmentadas. */
class WsConnection extends EventEmitter {
  constructor(socket) {
    super();
    this.socket = socket;
    this.buffer = Buffer.alloc(0);
    this.fragments = [];
    this.fragmentOpcode = 0;
    this.closed = false;
    this.alive = true;
    this.data = {};
    socket.setNoDelay(true);
    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('close', () => this._onClose());
    socket.on('error', () => this._onClose());
  }

  _onClose() {
    if (this.closed) return;
    this.closed = true;
    this.emit('close');
  }

  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    try {
      let frame;
      while ((frame = this._parse())) this._handle(frame);
    } catch (e) {
      this.close(1002, 'protocolo inválido');
    }
  }

  _parse() {
    const b = this.buffer;
    if (b.length < 2) return null;
    const fin = (b[0] & 0x80) !== 0;
    const opcode = b[0] & 0x0f;
    const masked = (b[1] & 0x80) !== 0;
    let len = b[1] & 0x7f;
    let off = 2;
    if (!masked) throw new Error('frame de cliente sem máscara');
    if (len === 126) { if (b.length < 4) return null; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) {
      if (b.length < 10) return null;
      const hi = b.readUInt32BE(2), lo = b.readUInt32BE(6);
      if (hi !== 0) throw new Error('frame grande demais');
      len = lo; off = 10;
    }
    if (len > MAX_MESSAGE) throw new Error('mensagem grande demais');
    if (b.length < off + 4 + len) return null;
    const mask = b.subarray(off, off + 4);
    const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
    this.buffer = b.subarray(off + 4 + len);
    return { fin, opcode, payload };
  }

  _handle({ fin, opcode, payload }) {
    if (opcode === 0x8) { this.close(1000); return; }
    if (opcode === 0x9) { this._write(0xA, payload); return; }
    if (opcode === 0xA) { this.alive = true; return; }
    if (opcode === 0x1 || opcode === 0x2) { this.fragments = [payload]; this.fragmentOpcode = opcode; }
    else if (opcode === 0x0) {
      if (!this.fragments.length) throw new Error('continuação inesperada');
      this.fragments.push(payload);
    } else throw new Error('opcode desconhecido');
    if (this.fragments.reduce((a, p) => a + p.length, 0) > MAX_MESSAGE) throw new Error('mensagem grande demais');
    if (fin) {
      const full = Buffer.concat(this.fragments);
      this.fragments = [];
      if (this.fragmentOpcode === 0x1) this.emit('message', full.toString('utf8'));
    }
  }

  _write(opcode, payload) {
    if (this.closed || this.socket.destroyed) return;
    const len = payload.length;
    let header;
    if (len < 126) header = Buffer.from([0x80 | opcode, len]);
    else if (len < 65536) { header = Buffer.alloc(4); header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2); }
    else { header = Buffer.alloc(10); header[0] = 0x80 | opcode; header[1] = 127; header.writeUInt32BE(0, 2); header.writeUInt32BE(len, 6); }
    this.socket.write(Buffer.concat([header, payload]));
  }

  send(obj) { this._write(0x1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj), 'utf8')); }
  ping() { this.alive = false; this._write(0x9, Buffer.alloc(0)); }

  close(code = 1000, reason = '') {
    if (this.closed) return;
    const r = Buffer.from(reason, 'utf8');
    const p = Buffer.alloc(2 + r.length);
    p.writeUInt16BE(code, 0); r.copy(p, 2);
    this._write(0x8, p);
    this.socket.end();
    this._onClose();
  }
}

/**
 * Registra o tratamento de upgrade para `path`. `verify(req)` pode recusar (retornar false).
 */
function attachWebSocket(server, path, onConnection, { verify = () => true, pingMs = 25000 } = {}) {
  const conns = new Set();
  server.on('upgrade', (req, socket) => {
    const url = new URL(req.url, 'http://localhost');
    const reject = (code, text) => { socket.write(`HTTP/1.1 ${code} ${text}\r\nConnection: close\r\n\r\n`); socket.destroy(); };
    if (url.pathname !== path) return reject(404, 'Not Found');
    const key = req.headers['sec-websocket-key'];
    if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket' || req.headers['sec-websocket-version'] !== '13') return reject(400, 'Bad Request');
    if (!verify(req)) return reject(403, 'Forbidden');
    const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
    const ws = new WsConnection(socket);
    conns.add(ws);
    ws.on('close', () => conns.delete(ws));
    onConnection(ws, req, url);
  });
  const timer = setInterval(() => {
    for (const c of conns) { if (!c.alive) { c.socket.destroy(); conns.delete(c); continue; } c.ping(); }
  }, pingMs);
  timer.unref();
  return {
    connections: conns,
    broadcast(obj, filter = () => true) { const text = JSON.stringify(obj); for (const c of conns) if (!c.closed && filter(c)) c.send(text); },
    closeAll() { clearInterval(timer); for (const c of conns) c.close(1001, 'servidor encerrando'); },
  };
}

module.exports = { attachWebSocket, WsConnection };
