'use strict';
/**
 * Ponto de entrada do aplicativo Android (Node.js embutido via nodejs-mobile, Node 18).
 * Variáveis de ambiente definidas pelo app Kotlin:
 *   OPEN_CHESS_HOME       pasta de dados (torneios, backups)
 *   OPEN_CHESS_ANDROID    "1"
 *   OPEN_CHESS_LAN_FILE   JSON com os IPs do aparelho (o Node não consegue listá-los no Android 11+)
 *   OPEN_CHESS_READY_FILE arquivo onde gravamos a porta da tela do app quando estiver pronto
 *   OPEN_CHESS_SQLJS_MODULE (opcional, usado em testes) caminho alternativo do módulo sql.js
 */
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..', '..');
const log = (...a) => console.log('[maria-open-chess]', ...a);

async function main() {
  process.env.OPEN_CHESS_ANDROID = '1';
  process.env.OPEN_CHESS_SQLITE = 'sqljs';
  const readyFile = process.env.OPEN_CHESS_READY_FILE;

  const vendor = path.join(ROOT, 'vendor', 'sql.js');
  const initSqlJs = require(process.env.OPEN_CHESS_SQLJS_MODULE || path.join(vendor, 'sql-wasm.js'));
  globalThis.__OPEN_CHESS_SQLJS = await initSqlJs({ locateFile: (f) => path.join(vendor, f) });
  log('sql.js pronto; node', process.version);

  const { Launcher } = require('../app/launcher');
  const launcher = new Launcher({ webDir: path.join(ROOT, 'web'), log });
  const port = await launcher.listen(Number(process.env.OPEN_CHESS_APP_PORT) || 8780);
  log('tela do aplicativo em http://localhost:' + port + '/');
  if (readyFile) {
    const tmp = readyFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({ port, pid: process.pid, node: process.version }));
    fs.renameSync(tmp, readyFile);
  }

  const shutdown = async () => { try { await launcher.close(); } finally { process.exit(0); } };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

process.on('uncaughtException', (e) => { console.error('[maria-open-chess] erro não tratado:', e && e.stack || e); });
process.on('unhandledRejection', (e) => { console.error('[maria-open-chess] promessa rejeitada:', e && e.stack || e); });

main().catch((e) => {
  console.error('[maria-open-chess] falha ao iniciar:', e && e.stack || e);
  if (process.env.OPEN_CHESS_READY_FILE) { try { fs.writeFileSync(process.env.OPEN_CHESS_READY_FILE + '.error', String(e && e.message || e)); } catch (_) { /* ok */ } }
  process.exitCode = 1;
});
