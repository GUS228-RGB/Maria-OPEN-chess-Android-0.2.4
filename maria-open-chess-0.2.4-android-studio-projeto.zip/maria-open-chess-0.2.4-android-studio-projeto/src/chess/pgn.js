'use strict';
const { Game, START_FEN } = require('./game');

const escTag = (v) => String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"');

/**
 * Gera PGN. `tags` aceita Event, Site, Date, Round, White, Black, Result etc.
 * Se não houver lances (partida presencial só com resultado), não inventa lances:
 * apenas as tags e o resultado.
 */
function toPgn(tags, sanMoves, result = '*', startFen = START_FEN) {
  const t = { Event: '?', Site: 'maria open CHESS', Date: '????.??.??', Round: '-', White: '?', Black: '?', ...tags, Result: result };
  const order = ['Event', 'Site', 'Date', 'Round', 'White', 'Black', 'Result'];
  let out = '';
  for (const k of order) out += `[${k} "${escTag(t[k])}"]\n`;
  for (const k of Object.keys(t)) if (!order.includes(k)) out += `[${k} "${escTag(t[k])}"]\n`;
  if (startFen && startFen !== START_FEN) out += `[SetUp "1"]\n[FEN "${startFen}"]\n`;
  out += '\n';
  let text = '';
  sanMoves.forEach((m, i) => {
    if (i % 2 === 0) text += `${Math.floor(i / 2) + 1}. `;
    text += m + ' ';
  });
  text += result;
  // quebra de linha a 80 colunas
  const words = text.split(' ');
  let line = '';
  for (const w of words) {
    if ((line + ' ' + w).trim().length > 80) { out += line.trim() + '\n'; line = w; }
    else line += ' ' + w;
  }
  out += line.trim() + '\n';
  return out;
}

/** Lê um ou vários jogos de um texto PGN. Retorna [{tags, moves, result, fen, error?}] */
function parsePgn(text) {
  const games = [];
  const src = String(text).replace(/\r/g, '');
  // separa jogos: um bloco de tags seguido pelos lances
  const re = /((?:^\s*\[[^\]]*\]\s*\n)+)([\s\S]*?)(?=^\s*\[Event\s|\s*$(?![\s\S]))/gm;
  let m;
  const chunks = [];
  while ((m = re.exec(src)) !== null) {
    if (m[0].trim()) chunks.push(m);
    if (m.index === re.lastIndex) re.lastIndex++;
  }
  for (const c of chunks) {
    const tags = {};
    for (const tm of c[1].matchAll(/\[(\w+)\s+"((?:[^"\\]|\\.)*)"\]/g)) tags[tm[1]] = tm[2].replace(/\\(["\\])/g, '$1');
    let body = c[2]
      .replace(/\{[^}]*\}/g, ' ')
      .replace(/;[^\n]*/g, ' ');
    // variantes (parênteses aninhados)
    let prev;
    do { prev = body; body = body.replace(/\([^()]*\)/g, ' '); } while (body !== prev);
    body = body.replace(/\$\d+/g, ' ');
    const tokens = body.split(/\s+/).filter(Boolean);
    let result = tags.Result || '*';
    const sans = [];
    for (let tok of tokens) {
      if (/^(1-0|0-1|1\/2-1\/2|\*)$/.test(tok)) { result = tok; continue; }
      tok = tok.replace(/^\d+\.(\.\.)?/, '');
      if (!tok) continue;
      sans.push(tok);
    }
    const fen = tags.FEN || START_FEN;
    const entry = { tags, moves: [], result, fen };
    try {
      const g = new Game(fen);
      for (const s of sans) {
        const played = g.move(s);
        if (!played) throw new Error(`Lance ilegal: ${s} (após ${g.moves.length} lances)`);
        entry.moves.push(played);
      }
    } catch (e) { entry.error = e.message; }
    games.push(entry);
  }
  return games;
}

module.exports = { toPgn, parsePgn };
