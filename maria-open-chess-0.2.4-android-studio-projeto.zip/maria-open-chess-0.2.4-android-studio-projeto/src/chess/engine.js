'use strict';
/**
 * Motor de regras de xadrez do open CHESS.
 * Tabuleiro: índice = rank*8 + file, rank 0 = linha 1, file 0 = coluna a.
 * Peças: maiúscula = brancas, minúscula = pretas ('P','N','B','R','Q','K').
 */

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const FILES = 'abcdefgh';

const KNIGHT = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
const KING = [[1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1]];
const BISHOP_DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
const ROOK_DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];

const C_WK = 1, C_WQ = 2, C_BK = 4, C_BQ = 8;

const sqName = (s) => FILES[s & 7] + ((s >> 3) + 1);
const sqFromName = (n) => {
  if (!/^[a-h][1-8]$/.test(n)) return -1;
  return (n.charCodeAt(1) - 49) * 8 + (n.charCodeAt(0) - 97);
};
const isWhite = (p) => p >= 'A' && p <= 'Z';
const colorOf = (p) => (isWhite(p) ? 'w' : 'b');

class Position {
  constructor() {
    this.board = new Array(64).fill(null);
    this.turn = 'w';
    this.castling = 0;
    this.ep = -1;
    this.halfmove = 0;
    this.fullmove = 1;
    this.kingSq = { w: -1, b: -1 };
  }

  static fromFen(fen = START_FEN) {
    const parts = String(fen).trim().split(/\s+/);
    if (parts.length < 4) throw new Error('FEN inválido: campos insuficientes');
    const pos = new Position();
    const rows = parts[0].split('/');
    if (rows.length !== 8) throw new Error('FEN inválido: deve ter 8 linhas');
    for (let i = 0; i < 8; i++) {
      const rank = 7 - i;
      let file = 0;
      for (const ch of rows[i]) {
        if (/[1-8]/.test(ch)) file += Number(ch);
        else if (/[pnbrqkPNBRQK]/.test(ch)) {
          if (file > 7) throw new Error('FEN inválido: linha longa demais');
          const sq = rank * 8 + file;
          pos.board[sq] = ch;
          if (ch === 'K') pos.kingSq.w = sq;
          if (ch === 'k') pos.kingSq.b = sq;
          file++;
        } else throw new Error('FEN inválido: caractere ' + ch);
      }
      if (file !== 8) throw new Error('FEN inválido: linha com tamanho incorreto');
    }
    if (pos.kingSq.w < 0 || pos.kingSq.b < 0) throw new Error('FEN inválido: falta um rei');
    if (parts[1] !== 'w' && parts[1] !== 'b') throw new Error('FEN inválido: turno');
    pos.turn = parts[1];
    let c = 0;
    if (parts[2].includes('K')) c |= C_WK;
    if (parts[2].includes('Q')) c |= C_WQ;
    if (parts[2].includes('k')) c |= C_BK;
    if (parts[2].includes('q')) c |= C_BQ;
    pos.castling = c;
    pos.ep = parts[3] === '-' ? -1 : sqFromName(parts[3]);
    pos.halfmove = parts[4] !== undefined ? parseInt(parts[4], 10) || 0 : 0;
    pos.fullmove = parts[5] !== undefined ? parseInt(parts[5], 10) || 1 : 1;
    // o lado que não joga não pode estar em xeque
    const other = pos.turn === 'w' ? 'b' : 'w';
    if (pos.isAttacked(pos.kingSq[other], pos.turn)) throw new Error('FEN inválido: rei adversário em xeque');
    return pos;
  }

  toFen() {
    let out = '';
    for (let rank = 7; rank >= 0; rank--) {
      let empty = 0;
      for (let file = 0; file < 8; file++) {
        const p = this.board[rank * 8 + file];
        if (!p) empty++;
        else { if (empty) { out += empty; empty = 0; } out += p; }
      }
      if (empty) out += empty;
      if (rank) out += '/';
    }
    let cs = '';
    if (this.castling & C_WK) cs += 'K';
    if (this.castling & C_WQ) cs += 'Q';
    if (this.castling & C_BK) cs += 'k';
    if (this.castling & C_BQ) cs += 'q';
    return `${out} ${this.turn} ${cs || '-'} ${this.ep >= 0 ? sqName(this.ep) : '-'} ${this.halfmove} ${this.fullmove}`;
  }

  /** O quadrado `sq` é atacado por peças da cor `by`? */
  isAttacked(sq, by) {
    const b = this.board;
    const r = sq >> 3, f = sq & 7;
    // peões
    const pr = by === 'w' ? r - 1 : r + 1;
    if (pr >= 0 && pr < 8) {
      const pp = by === 'w' ? 'P' : 'p';
      if (f > 0 && b[pr * 8 + f - 1] === pp) return true;
      if (f < 7 && b[pr * 8 + f + 1] === pp) return true;
    }
    const N = by === 'w' ? 'N' : 'n';
    for (const [dr, df] of KNIGHT) {
      const rr = r + dr, ff = f + df;
      if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b[rr * 8 + ff] === N) return true;
    }
    const K = by === 'w' ? 'K' : 'k';
    for (const [dr, df] of KING) {
      const rr = r + dr, ff = f + df;
      if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b[rr * 8 + ff] === K) return true;
    }
    const B = by === 'w' ? 'B' : 'b', R = by === 'w' ? 'R' : 'r', Q = by === 'w' ? 'Q' : 'q';
    for (const [dr, df] of BISHOP_DIRS) {
      let rr = r + dr, ff = f + df;
      while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
        const p = b[rr * 8 + ff];
        if (p) { if (p === B || p === Q) return true; break; }
        rr += dr; ff += df;
      }
    }
    for (const [dr, df] of ROOK_DIRS) {
      let rr = r + dr, ff = f + df;
      while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
        const p = b[rr * 8 + ff];
        if (p) { if (p === R || p === Q) return true; break; }
        rr += dr; ff += df;
      }
    }
    return false;
  }

  inCheck(color = this.turn) {
    return this.isAttacked(this.kingSq[color], color === 'w' ? 'b' : 'w');
  }

  /** Lances pseudo-legais (não verifica xeque do próprio rei). */
  pseudoMoves() {
    const moves = [];
    const b = this.board;
    const us = this.turn;
    const them = us === 'w' ? 'b' : 'w';
    const white = us === 'w';

    for (let sq = 0; sq < 64; sq++) {
      const p = b[sq];
      if (!p || colorOf(p) !== us) continue;
      const r = sq >> 3, f = sq & 7;
      const t = p.toUpperCase();
      if (t === 'P') {
        const dir = white ? 1 : -1;
        const startRank = white ? 1 : 6;
        const promoRank = white ? 7 : 0;
        const r1 = r + dir;
        if (r1 < 0 || r1 > 7) continue;
        const addPawn = (to, captured, flag) => {
          if ((to >> 3) === promoRank) {
            for (const pr of ['q', 'r', 'b', 'n']) moves.push({ from: sq, to, piece: p, captured, promotion: pr, flag });
          } else moves.push({ from: sq, to, piece: p, captured, promotion: null, flag });
        };
        if (!b[r1 * 8 + f]) {
          addPawn(r1 * 8 + f, null, null);
          if (r === startRank && !b[(r + 2 * dir) * 8 + f]) {
            moves.push({ from: sq, to: (r + 2 * dir) * 8 + f, piece: p, captured: null, promotion: null, flag: 'double' });
          }
        }
        for (const df of [-1, 1]) {
          const ff = f + df;
          if (ff < 0 || ff > 7) continue;
          const to = r1 * 8 + ff;
          const target = b[to];
          if (target && colorOf(target) === them) addPawn(to, target, null);
          else if (!target && to === this.ep) {
            moves.push({ from: sq, to, piece: p, captured: white ? 'p' : 'P', promotion: null, flag: 'ep' });
          }
        }
      } else if (t === 'N' || t === 'K') {
        const deltas = t === 'N' ? KNIGHT : KING;
        for (const [dr, df] of deltas) {
          const rr = r + dr, ff = f + df;
          if (rr < 0 || rr > 7 || ff < 0 || ff > 7) continue;
          const to = rr * 8 + ff;
          const target = b[to];
          if (!target || colorOf(target) === them) moves.push({ from: sq, to, piece: p, captured: target, promotion: null, flag: null });
        }
        if (t === 'K') this._castleMoves(moves, sq, p, white, them);
      } else {
        const dirs = t === 'B' ? BISHOP_DIRS : t === 'R' ? ROOK_DIRS : BISHOP_DIRS.concat(ROOK_DIRS);
        for (const [dr, df] of dirs) {
          let rr = r + dr, ff = f + df;
          while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
            const to = rr * 8 + ff;
            const target = b[to];
            if (!target) moves.push({ from: sq, to, piece: p, captured: null, promotion: null, flag: null });
            else {
              if (colorOf(target) === them) moves.push({ from: sq, to, piece: p, captured: target, promotion: null, flag: null });
              break;
            }
            rr += dr; ff += df;
          }
        }
      }
    }
    return moves;
  }

  _castleMoves(moves, sq, p, white, them) {
    const b = this.board;
    const home = white ? 4 : 60;
    if (sq !== home) return;
    const ks = white ? C_WK : C_BK, qs = white ? C_WQ : C_BQ;
    const rook = white ? 'R' : 'r';
    if (!(this.castling & (ks | qs))) return;
    if (this.isAttacked(home, them)) return;
    if ((this.castling & ks) && b[home + 3] === rook && !b[home + 1] && !b[home + 2] &&
        !this.isAttacked(home + 1, them) && !this.isAttacked(home + 2, them)) {
      moves.push({ from: home, to: home + 2, piece: p, captured: null, promotion: null, flag: 'castleK' });
    }
    if ((this.castling & qs) && b[home - 4] === rook && !b[home - 1] && !b[home - 2] && !b[home - 3] &&
        !this.isAttacked(home - 1, them) && !this.isAttacked(home - 2, them)) {
      moves.push({ from: home, to: home - 2, piece: p, captured: null, promotion: null, flag: 'castleQ' });
    }
  }

  make(m) {
    const b = this.board;
    const undo = { captured: m.captured, castling: this.castling, ep: this.ep, halfmove: this.halfmove, fullmove: this.fullmove };
    const us = this.turn;
    b[m.from] = null;
    if (m.flag === 'ep') {
      const capSq = m.to + (us === 'w' ? -8 : 8);
      b[capSq] = null;
    }
    b[m.to] = m.promotion ? (us === 'w' ? m.promotion.toUpperCase() : m.promotion) : m.piece;
    if (m.piece === 'K') this.kingSq.w = m.to;
    if (m.piece === 'k') this.kingSq.b = m.to;
    if (m.flag === 'castleK') { b[m.to - 1] = b[m.to + 1]; b[m.to + 1] = null; }
    else if (m.flag === 'castleQ') { b[m.to + 1] = b[m.to - 2]; b[m.to - 2] = null; }

    if (m.piece === 'K') this.castling &= ~(C_WK | C_WQ);
    if (m.piece === 'k') this.castling &= ~(C_BK | C_BQ);
    for (const s of [m.from, m.to]) {
      if (s === 0) this.castling &= ~C_WQ;
      else if (s === 7) this.castling &= ~C_WK;
      else if (s === 56) this.castling &= ~C_BQ;
      else if (s === 63) this.castling &= ~C_BK;
    }
    this.ep = m.flag === 'double' ? (m.from + m.to) >> 1 : -1;
    this.halfmove = (m.piece.toUpperCase() === 'P' || m.captured) ? 0 : this.halfmove + 1;
    if (us === 'b') this.fullmove++;
    this.turn = us === 'w' ? 'b' : 'w';
    return undo;
  }

  unmake(m, undo) {
    const b = this.board;
    this.turn = this.turn === 'w' ? 'b' : 'w';
    const us = this.turn;
    this.castling = undo.castling;
    this.ep = undo.ep;
    this.halfmove = undo.halfmove;
    this.fullmove = undo.fullmove;
    b[m.from] = m.piece;
    if (m.piece === 'K') this.kingSq.w = m.from;
    if (m.piece === 'k') this.kingSq.b = m.from;
    if (m.flag === 'ep') {
      b[m.to] = null;
      b[m.to + (us === 'w' ? -8 : 8)] = m.captured;
    } else b[m.to] = m.captured || null;
    if (m.flag === 'castleK') { b[m.to + 1] = b[m.to - 1]; b[m.to - 1] = null; }
    else if (m.flag === 'castleQ') { b[m.to - 2] = b[m.to + 1]; b[m.to + 1] = null; }
  }

  legalMoves() {
    const out = [];
    const us = this.turn, them = us === 'w' ? 'b' : 'w';
    for (const m of this.pseudoMoves()) {
      const u = this.make(m);
      if (!this.isAttacked(this.kingSq[us], them)) out.push(m);
      this.unmake(m, u);
    }
    return out;
  }

  /** Chave de posição para repetição (FEN sem contadores; en passant só se capturável). */
  positionKey() {
    let epPart = '-';
    if (this.ep >= 0) {
      const ml = this.legalMoves();
      if (ml.some((m) => m.flag === 'ep')) epPart = sqName(this.ep);
    }
    return this.toFen().split(' ').slice(0, 3).join(' ') + ' ' + epPart;
  }

  insufficientMaterial() {
    const minors = { w: [], b: [] };
    for (let sq = 0; sq < 64; sq++) {
      const p = this.board[sq];
      if (!p) continue;
      const t = p.toUpperCase();
      if (t === 'K') continue;
      if (t === 'P' || t === 'R' || t === 'Q') return false;
      minors[colorOf(p)].push({ t, sqColor: ((sq >> 3) + (sq & 7)) & 1 });
    }
    const nw = minors.w.length, nb = minors.b.length;
    if (nw + nb === 0) return true;
    if (nw + nb === 1) return true; // K+B ou K+N contra K
    if (nw === 1 && nb === 1 && minors.w[0].t === 'B' && minors.b[0].t === 'B' &&
        minors.w[0].sqColor === minors.b[0].sqColor) return true;
    return false;
  }
}

function perft(pos, depth) {
  if (depth === 0) return 1;
  let n = 0;
  const moves = pos.legalMoves();
  if (depth === 1) return moves.length;
  for (const m of moves) {
    const u = pos.make(m);
    n += perft(pos, depth - 1);
    pos.unmake(m, u);
  }
  return n;
}

module.exports = { Position, START_FEN, sqName, sqFromName, perft, colorOf, isWhite };
