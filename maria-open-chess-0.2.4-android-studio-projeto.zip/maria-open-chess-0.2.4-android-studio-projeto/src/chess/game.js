'use strict';
const { Position, START_FEN, sqName, sqFromName } = require('./engine');

/** Converte um lance em SAN na posição atual (pos não é alterada ao final). */
function toSan(pos, m, legal) {
  const t = m.piece.toUpperCase();
  let san;
  if (m.flag === 'castleK') san = 'O-O';
  else if (m.flag === 'castleQ') san = 'O-O-O';
  else {
    san = '';
    const isCapture = !!m.captured;
    if (t === 'P') {
      if (isCapture) san += sqName(m.from)[0] + 'x';
      san += sqName(m.to);
      if (m.promotion) san += '=' + m.promotion.toUpperCase();
    } else {
      san += t;
      const others = legal.filter((o) => o !== m && o.piece === m.piece && o.to === m.to);
      if (others.length) {
        const sameFile = others.some((o) => (o.from & 7) === (m.from & 7));
        const sameRank = others.some((o) => (o.from >> 3) === (m.from >> 3));
        if (!sameFile) san += sqName(m.from)[0];
        else if (!sameRank) san += sqName(m.from)[1];
        else san += sqName(m.from);
      }
      if (isCapture) san += 'x';
      san += sqName(m.to);
    }
  }
  const u = pos.make(m);
  if (pos.inCheck()) san += pos.legalMoves().length === 0 ? '#' : '+';
  pos.unmake(m, u);
  return san;
}

const normSan = (s) => s.replace(/[+#!?]/g, '').replace(/0/g, 'O').replace(/=/g, '').replace(/\s/g, '');

const RESULT = { WHITE: '1-0', BLACK: '0-1', DRAW: '1/2-1/2', ONGOING: '*' };

class Game {
  constructor(fen = START_FEN) {
    this.startFen = fen;
    this.pos = Position.fromFen(fen);
    this.moves = [];          // SAN
    this.uci = [];
    this.keys = [this.pos.positionKey()];
    this.result = RESULT.ONGOING;
    this.reason = null;       // checkmate, stalemate, repetition, fifty-move, insufficient, resign, timeout, agreement
    this._refresh();
  }

  static fromMoves(sanList, fen = START_FEN) {
    const g = new Game(fen);
    for (const s of sanList) {
      if (!g.move(s)) throw new Error('Lance ilegal no histórico: ' + s);
    }
    return g;
  }

  get turn() { return this.pos.turn; }
  get fen() { return this.pos.toFen(); }
  get over() { return this.result !== RESULT.ONGOING; }

  legalMoves() { return this.pos.legalMoves(); }

  /** Lista de lances legais em formato serializável. */
  legalList() {
    const legal = this.pos.legalMoves();
    return legal.map((m) => ({ from: sqName(m.from), to: sqName(m.to), promotion: m.promotion || undefined, san: toSan(this.pos, m, legal) }));
  }

  /** Aceita SAN ("Nf3"), UCI ("g1f3", "e7e8q") ou objeto {from,to,promotion}. Retorna o SAN jogado ou null. */
  move(input) {
    if (this.over) return null;
    const legal = this.pos.legalMoves();
    let found = null;
    if (input && typeof input === 'object') {
      const from = sqFromName(input.from), to = sqFromName(input.to);
      const promo = input.promotion ? String(input.promotion).toLowerCase() : null;
      const cands = legal.filter((m) => m.from === from && m.to === to);
      found = cands.find((m) => (m.promotion || null) === promo) || null;
      if (!found && cands.length && !promo && cands[0].promotion) found = null; // promoção exige escolha
    } else if (typeof input === 'string') {
      const s = input.trim();
      const uciM = /^([a-h][1-8])([a-h][1-8])([qrbn])?$/i.exec(s);
      if (uciM) {
        return this.move({ from: uciM[1].toLowerCase(), to: uciM[2].toLowerCase(), promotion: uciM[3] });
      }
      const n = normSan(s);
      found = legal.find((m) => normSan(toSan(this.pos, m, legal)) === n) || null;
    }
    if (!found) return null;
    const san = toSan(this.pos, found, legal);
    this.pos.make(found);
    this.moves.push(san);
    this.uci.push(sqName(found.from) + sqName(found.to) + (found.promotion || ''));
    this.keys.push(this.pos.positionKey());
    this._refresh();
    return san;
  }

  _refresh() {
    if (this.result !== RESULT.ONGOING && ['resign', 'timeout', 'agreement', 'abandon'].includes(this.reason)) return;
    const legal = this.pos.legalMoves();
    if (legal.length === 0) {
      if (this.pos.inCheck()) {
        this.result = this.pos.turn === 'w' ? RESULT.BLACK : RESULT.WHITE;
        this.reason = 'checkmate';
      } else { this.result = RESULT.DRAW; this.reason = 'stalemate'; }
      return;
    }
    if (this.pos.insufficientMaterial()) { this.result = RESULT.DRAW; this.reason = 'insufficient'; return; }
    if (this.pos.halfmove >= 100) { this.result = RESULT.DRAW; this.reason = 'fifty-move'; return; }
    const cur = this.keys[this.keys.length - 1];
    if (this.keys.filter((k) => k === cur).length >= 3) { this.result = RESULT.DRAW; this.reason = 'repetition'; return; }
    this.result = RESULT.ONGOING; this.reason = null;
  }

  resign(color) {
    if (this.over) return false;
    this.result = color === 'w' ? RESULT.BLACK : RESULT.WHITE;
    this.reason = 'resign';
    return true;
  }

  drawByAgreement() {
    if (this.over) return false;
    this.result = RESULT.DRAW; this.reason = 'agreement';
    return true;
  }

  /** Fim de tempo: quem perde por tempo; empate se o adversário não tem material para dar mate. */
  timeout(color) {
    if (this.over) return false;
    const opp = color === 'w' ? 'b' : 'w';
    if (this._hasMatingMaterial(opp)) this.result = color === 'w' ? RESULT.BLACK : RESULT.WHITE;
    else this.result = RESULT.DRAW;
    this.reason = 'timeout';
    return true;
  }

  _hasMatingMaterial(color) {
    let minors = 0;
    for (let sq = 0; sq < 64; sq++) {
      const p = this.pos.board[sq];
      if (!p || (p === p.toUpperCase() ? 'w' : 'b') !== color) continue;
      const t = p.toUpperCase();
      if (t === 'P' || t === 'R' || t === 'Q') return true;
      if (t === 'B' || t === 'N') minors++;
    }
    return minors >= 2;
  }

  /** Posição atual como matriz para a interface: { square: piece }. */
  boardMap() {
    const out = {};
    for (let sq = 0; sq < 64; sq++) if (this.pos.board[sq]) out[sqName(sq)] = this.pos.board[sq];
    return out;
  }

  inCheck() { return this.pos.inCheck(); }
}

module.exports = { Game, RESULT, toSan, START_FEN };
