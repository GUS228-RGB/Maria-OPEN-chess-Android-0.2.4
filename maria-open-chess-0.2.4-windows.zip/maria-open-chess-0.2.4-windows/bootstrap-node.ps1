# Baixa o Node.js oficial e verifica o SHA-256 publicado pelo nodejs.org.
$ErrorActionPreference = 'Stop'
$ver = '22.23.4'
$mirror = if ($env:OPEN_CHESS_NODE_MIRROR) { $env:OPEN_CHESS_NODE_MIRROR } else { 'https://nodejs.org/dist' }
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$file = "node-v$ver-win-$arch.zip"
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$runtime = Join-Path $dir 'runtime'
$tmp = Join-Path ([IO.Path]::GetTempPath()) ("openchess-" + [guid]::NewGuid())
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  Write-Host "Baixando Node.js v$ver ($arch)..."
  Invoke-WebRequest "$mirror/v$ver/SHASUMS256.txt" -OutFile "$tmp\SHASUMS256.txt" -UseBasicParsing
  Invoke-WebRequest "$mirror/v$ver/$file" -OutFile "$tmp\$file" -UseBasicParsing
  $line = Get-Content "$tmp\SHASUMS256.txt" | Where-Object { $_ -match "  $([regex]::Escape($file))$" } | Select-Object -First 1
  if (-not $line) { throw "Arquivo $file nao consta na lista de hashes." }
  $want = ($line -split '\s+')[0].ToLower()
  $got = (Get-FileHash "$tmp\$file" -Algorithm SHA256).Hash.ToLower()
  if ($want -ne $got) { throw 'O SHA-256 do arquivo baixado nao confere. Download descartado.' }
  Expand-Archive "$tmp\$file" -DestinationPath $tmp -Force
  New-Item -ItemType Directory -Path $runtime -Force | Out-Null
  if (Test-Path "$runtime\node") { Remove-Item "$runtime\node" -Recurse -Force }
  Move-Item "$tmp\node-v$ver-win-$arch" "$runtime\node"
  Write-Host "Node.js instalado em $runtime\node (SHA-256 verificado)."
} catch { Write-Host "ERRO: $($_.Exception.Message)"; exit 1 }
finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
