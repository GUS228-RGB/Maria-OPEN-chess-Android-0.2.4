@echo off
set "OPEN_CHESS_PAUSE=1"
call "%~dp0open-chess.cmd" app %*
