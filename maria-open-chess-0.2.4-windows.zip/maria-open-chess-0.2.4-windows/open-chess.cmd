@echo off
chcp 65001 >nul
setlocal
set "DIR=%~dp0"
set "NODE="
set "CHECK=const [a,b]=process.versions.node.split('.').map(Number); process.exit(a>22||(a===22&&b>=5)?0:1)"

if exist "%DIR%runtime\node\node.exe" (
  "%DIR%runtime\node\node.exe" -e "%CHECK%" >nul 2>&1 && set "NODE=%DIR%runtime\node\node.exe"
)
if not defined NODE (
  where node >nul 2>&1 && (node -e "%CHECK%" >nul 2>&1 && set "NODE=node")
)
if not defined NODE (
  echo O maria open CHESS precisa do Node.js 22.5 ou superior, que nao foi encontrado.
  set /p R="Baixar o Node.js oficial (~30 MB) para dentro desta pasta? [S/n] "
  if /i "%R%"=="n" ( echo Cancelado. & pause & exit /b 1 )
  powershell -NoProfile -ExecutionPolicy Bypass -File "%DIR%bootstrap-node.ps1"
  if errorlevel 1 ( echo Nao foi possivel instalar o Node.js. & pause & exit /b 1 )
  set "NODE=%DIR%runtime\node\node.exe"
)
"%NODE%" --no-warnings "%DIR%app\bin\open-chess.js" %*
set "RC=%errorlevel%"
if "%OPEN_CHESS_PAUSE%"=="1" pause
exit /b %RC%
