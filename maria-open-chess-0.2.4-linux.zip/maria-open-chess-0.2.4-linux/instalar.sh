#!/bin/sh
# Instala para o usuário atual (sem sudo): ~/.local/share/maria-open-chess, comando open-chess e atalho no menu.
set -e
SRC="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/maria-open-chess"
BIN="$HOME/.local/bin"
APPS="${XDG_DATA_HOME:-$HOME/.local/share}/applications"
mkdir -p "$DEST" "$BIN" "$APPS"
rm -rf "$DEST/app"; cp -r "$SRC/app" "$DEST/app"
cp "$SRC/open-chess" "$SRC/abrir-maria-open-chess.sh" "$DEST/"; [ -d "$SRC/runtime" ] && cp -r "$SRC/runtime" "$DEST/"
chmod +x "$DEST/open-chess" "$DEST/abrir-maria-open-chess.sh"
ln -sf "$DEST/open-chess" "$BIN/open-chess"
cp "$DEST/app/web/logo.svg" "$DEST/logo.svg"
cat > "$APPS/maria-open-chess.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=maria open CHESS
Comment=Hospede torneios de xadrez
Exec=$DEST/abrir-maria-open-chess.sh
Icon=$DEST/logo.svg
Terminal=true
Categories=Game;BoardGame;
DESK
echo "Instalado em $DEST"
echo "Comando: open-chess host | app | status | stop   (garanta que $BIN está no PATH)"
echo "Também há o atalho 'maria open CHESS' no menu de aplicativos."
