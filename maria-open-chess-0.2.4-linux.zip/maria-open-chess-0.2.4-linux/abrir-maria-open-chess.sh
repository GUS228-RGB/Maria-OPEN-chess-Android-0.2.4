#!/bin/sh
# Abre a tela "CRIAR TORNEIO / INICIAR HOSPEDAGEM" no navegador.
DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
exec "$DIR/open-chess" app "$@"
